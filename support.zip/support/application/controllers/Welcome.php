<?php
defined('BASEPATH') || exit('No direct script access allowed');

class Welcome extends CI_Controller {
	 public function __construct()
	{
		parent::__construct();
		$this->load->model('User_model');
		$customer;
	} 


	public function index()
	{ $this->session->set_flashdata('success','');
	
	 $this->load->model('User_model');
	 $data['image1'] = $this->User_model->getImage1();
	 $data['image2'] = $this->User_model->getImage2();
	   $data['image3'] = $this->User_model->getImage3();
	    $data['image4'] = $this->User_model->getImage4();
	  $data['a'] = $this->User_model->gettxt();
	   $data['b'] = $this->User_model->gettxt2();
	    $data['c'] = $this->User_model->gettxt3();
		$this->load->view('clinic',$data);
	}
	
	
	
	 public function selectpro(){
      
      
      $this->load->view('selectpro');
  } 
  
  
  public function spage1(){
      
      
      $this->load->model('User_model');
 $data['image7'] = $this->User_model->getImage7();
 $data['dg'] = $this->User_model->gettxt14();

      
         $data['p'] = $this->User_model->getproducts();
      $this->load->view('spage1',$data);
  } 
  
  
  
   public function spage2(){
      
      
      $this->load->model('User_model');
 $data['image8'] = $this->User_model->getImage8();
 $data['db'] = $this->User_model->gettxt15();

      
      
      $this->load->view('spage2',$data);
  } 
  
  
   public function upage1(){
      
      
      $this->load->model('User_model');
 $data['image9'] = $this->User_model->getImage9();
 $data['dc'] = $this->User_model->gettxt16();

      
        $data['p'] = $this->User_model->getproducts();
      $this->load->view('upage1',$data);
  } 
  
  
   public function hpage1(){
      
      
      $this->load->model('User_model');
 $data['image10'] = $this->User_model->getImage10();
 $data['dd'] = $this->User_model->gettxt17();

      
    $data['p'] = $this->User_model->getproducts();
      $this->load->view('hpage1',$data);
  } 
  
  
   public function page2(){
       
       
        $this->load->model('User_model');
	 $data['image6'] = $this->User_model->getImage6();
$data['f'] = $this->User_model->gettxt6();
      
      
      $this->load->view('page2',$data);
  } 
	
	
	
	 public function services(){
      
       $this->load->model('User_model');
        $data['b'] = $this->User_model->gettxt2();
       $data['image2'] = $this->User_model->getImage2();
        $data['image3'] = $this->User_model->getImage3();

$data['c'] = $this->User_model->gettxt3();
      $this->load->view('services',$data);
  } 
	

    public function addHhomeSlider(){
      
       $this->load->model('User_model');
        
       $data['image1'] = $this->User_model->getImage1();
      $this->load->view('slider',$data);
  }   
  
  
  
   public function addHhomeSlider2(){
      
       $this->load->model('User_model');
        
       $data['image2'] = $this->User_model->getImage2();
      $this->load->view('servicesadd',$data);
  }
  
  
  public function addHhomeSlider3(){
      
       $this->load->model('User_model');
        
       $data['image3'] = $this->User_model->getImage3();
      $this->load->view('aboutusadd',$data);
  }
  
  
  
   public function addHhomeSlider4(){
      
       $this->load->model('User_model');
        
       $data['image4'] = $this->User_model->getImage4();
      $this->load->view('addtestimonial',$data);
  }
  
  
   public function addHhomeSlider5(){
      
       $this->load->model('User_model');
        
       $data['image5'] = $this->User_model->getImage5();
      $this->load->view('addbpage1',$data);
  }
  
  
  public function addHhomeSlider6(){
      
       $this->load->model('User_model');
        
       $data['image6'] = $this->User_model->getImage6();
      $this->load->view('addbpage2',$data);
  }
  
  
   public function addHhomeSlider7(){
      
       $this->load->model('User_model');
        
       $data['image7'] = $this->User_model->getImage7();
      $this->load->view('addspage1',$data);
  }
  
  
   public function addHhomeSlider8(){
      
       $this->load->model('User_model');
         $data['db'] = $this->User_model->gettxt15();
       $data['image8'] = $this->User_model->getImage8();
      $this->load->view('addspage2',$data);
  }
  
  
   public function addHhomeSlider9(){
      
       $this->load->model('User_model');
         $data['dc'] = $this->User_model->gettxt16();
       $data['image9'] = $this->User_model->getImage9();
      $this->load->view('addupage1',$data);
  }
  
   public function addHhomeSlider10(){
      
       $this->load->model('User_model');
         $data['dd'] = $this->User_model->gettxt17();
       $data['image10'] = $this->User_model->getImage10();
      $this->load->view('addhpage1',$data);
  }
    
    
    
    function addimage(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image1'] = $this->User_model->getImage1();
    redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
               function addimage2(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit2')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image2']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image2']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image2')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage2($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image1'] = $this->User_model->getImage1();
    redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
                function addimage3(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit3')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image3']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image3']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image3')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage3($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image1'] = $this->User_model->getImage1();
     redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
               
               function addimage4(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit4')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image4']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image4']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image4')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage4($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image2'] = $this->User_model->getImage2();
    redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
               
               
               
               function addimage5(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit5')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image5']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image5']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image5')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage5($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image2'] = $this->User_model->getImage2();
   redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
               
               function addimage6(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit6')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image6']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image6']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image6')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage6($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image2'] = $this->User_model->getImage2();
    redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
               
               
               
               
               
                function addimage7(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit7')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image7']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image7']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image7')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage7($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image3'] = $this->User_model->getImage3();
    redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
                function addimage8(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit8')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image8']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image8']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image8')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage8($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image5'] = $this->User_model->getImage5();
   redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
               
               
                function addimage9(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit9')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image9']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image9']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image9')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage9($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image5'] = $this->User_model->getImage5();
    redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
               
               
               
                function addimage10(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit10')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image10']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image10']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image10')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage10($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image5'] = $this->User_model->getImage5();
    redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
               
               
                function addimage11(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit11')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image11']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image11']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image11')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage11($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image5'] = $this->User_model->getImage5();
    redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
               
                function addimage12(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit12')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image12']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image12']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image12')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage12($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image5'] = $this->User_model->getImage5();
    redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
                function addimage13(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit13')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image13']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image13']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image13')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage13($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image5'] = $this->User_model->getImage5();
   redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
               
                function addimage14(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit14')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image14']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image14']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image14')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage14($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image5'] = $this->User_model->getImage5();
      redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
               
                function addimage15(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit15')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image15']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image15']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image15')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage15($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image5'] = $this->User_model->getImage5();
      redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
                function addimage16(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit16')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image16']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image16']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image16')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage16($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image5'] = $this->User_model->getImage5();
      redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
               
               
                function addimage17(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit17')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image17']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image17']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image17')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage17($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image5'] = $this->User_model->getImage5();
      redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
               
                function addimage18(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit18')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image18']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image18']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image18')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage18($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image5'] = $this->User_model->getImage5();
      redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
               
                function addimage19(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit19')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image19']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image19']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image19')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage19($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image5'] = $this->User_model->getImage5();
      redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
               
               function addimage20(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit20')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image20']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image20']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image20')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage20($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image6'] = $this->User_model->getImage6();
      redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
                function addimage21(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit21')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image21']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image21']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image21')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage21($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image6'] = $this->User_model->getImage6();
      redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
               
                function addimage22(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit22')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image22']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image22']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image22')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage22($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image6'] = $this->User_model->getImage6();
      redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
               
                function addimage23(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit23')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image23']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image23']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image23')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage23($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image6'] = $this->User_model->getImage6();
      redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
               
               function addimage24(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit24')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image24']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image24']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image24')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage24($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image7'] = $this->User_model->getImage7();
      redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
               
               
               
               function addimage25(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit25')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image25']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image25']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image25')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage25($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image7'] = $this->User_model->getImage7();
      redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
               
               function addimage26(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit26')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image26']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image26']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image26')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage26($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image7'] = $this->User_model->getImage7();
      redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
               
               function addimage27(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit27')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image27']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image27']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image27')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage27($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image7'] = $this->User_model->getImage7();
      redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
               
               function addimage28(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit28')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image28']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image28']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image28')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage28($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image7'] = $this->User_model->getImage7();
      redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
               function addimage29(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit29')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image29']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image29']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image29')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage29($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image7'] = $this->User_model->getImage7();
      redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
               function addimage30(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit30')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image30']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image30']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image30')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage30($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image7'] = $this->User_model->getImage7();
      redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
               
                function addimage31(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit31')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image31']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image31']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image31')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage31($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image7'] = $this->User_model->getImage7();
      redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
                function addimage32(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit32')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image32']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image32']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image32')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage32($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image7'] = $this->User_model->getImage7();
      redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
                function addimage33(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit33')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image33']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image33']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image33')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage33($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image7'] = $this->User_model->getImage7();
      redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
               
               function addimage34(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit34')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image34']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image34']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image34')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage34($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image8'] = $this->User_model->getImage8();
      redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
               
               function addimage35(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit35')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image35']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image35']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image35')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage35($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image8'] = $this->User_model->getImage8();
      redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
               
               function addimage36(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit36')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image36']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image36']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image36')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage36($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image8'] = $this->User_model->getImage8();
      redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
               
               
               function addimage37(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit37')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image37']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image37']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image37')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage37($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image9'] = $this->User_model->getImage9();
      redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
               function addimage38(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit38')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image38']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image38']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image38')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage38($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image9'] = $this->User_model->getImage9();
      redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
               function addimage39(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit39')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image39']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image39']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image39')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage39($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image9'] = $this->User_model->getImage9();
      redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
               function addimage40(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit40')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image40']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image40']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image40')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage40($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image9'] = $this->User_model->getImage9();
      redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
               
               
               function addimage41(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit41')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image41']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image41']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image41')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage41($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image9'] = $this->User_model->getImage9();
      redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
               function addimage42(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit42')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image42']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image42']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image42')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage42($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image9'] = $this->User_model->getImage9();
      redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               function addimage43(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit43')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image43']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image43']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image43')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage43($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image9'] = $this->User_model->getImage9();
      redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
               function addimage44(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit44')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image44']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image44']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image44')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage44($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image9'] = $this->User_model->getImage9();
      redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
               function addimage45(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit45')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image45']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image45']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image45')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage45($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image9'] = $this->User_model->getImage9();
      redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               function addimage46(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit46')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image46']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image46']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image46')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage46($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image9'] = $this->User_model->getImage9();
      redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               function addimage47(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit47')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image47']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image47']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image47')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage47($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image10'] = $this->User_model->getImage10();
      redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
               
               function addimage48(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit48')){
           	$old = $this->input->post('old');
   
            //Check whether Member upload profile_img
             if(!empty($_FILES['image48']['name'])){
        if($old){
      	    		    $imgpath = 'images/'.$old;
       
        unlink( $imgpath ); 
      	    		}
                $config['upload_path'] = 'images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['image48']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image48')){ 
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                     $this->User_model->editimage48($image);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $image = '';
                    redirect(base_url('Welcome/displayimage'));
                }
             }
              $data['image10'] = $this->User_model->getImage10();
      redirect(base_url('Superadmin/ticketview'));
      	}
               }
               
               
          
               
               
               
               
               
               
               
               
               
               
               
               
               
                public function addSliderHome(){
      if($this->input->post()){
      
      $image=$this->input->post('tit1');
      $image2=$this->input->post('subtit1');
      
      
       $image3=$this->input->post('tit2');
      $image4=$this->input->post('subtit2');
      
      
       $image5=$this->input->post('tit3');
      $image6=$this->input->post('subtit3');
      
      
    
      
     
      
      
        $addSubjt = array(

           'title'=>$image,
          'stitle'=>$image2,
           'title2'=>$image3,
          'stitle2'=>$image4,
          
           'title3'=>$image5,
          'stitle3'=>$image6,
          

         
          );
       

            $this->load->model('User_model');
            if($this->User_model->edittext3($image,$image2,$image3,$image4,$image5,$image6)){
               $this->session->set_flashdata('SUCCESSMSG','Updated Successfull.');
                echo '<script language="javascript">';
                echo 'alert("Added Successfull")';
                echo '</script>';
                
                 $this->load->view('admin');
               
            }
            else{
               $this->session->set_flashdata('SUCCESSMSG','error!!');
           }
        }   
      else{
      $this->session->set_flashdata('SUCCESSMSG','Not Successfully Added!!');
        }
  }
  
  
  
  
  
  
  public function addSliderHome2(){
      if($this->input->post()){
      
      $image=$this->input->post('tit1');
      $image2=$this->input->post('subtit1');
      
      
       $image3=$this->input->post('tit2');
      $image4=$this->input->post('subtit2');
      
      
       $image5=$this->input->post('tit3');
      $image6=$this->input->post('subtit3');
      
      
    
      
     
      
      
        $addSubjt = array(

           'title'=>$image,
          'stitle'=>$image2,
           'title2'=>$image3,
          'stitle2'=>$image4,
          
           'title3'=>$image5,
          'stitle3'=>$image6,
          

         
          );
       

            $this->load->model('User_model');
            if($this->User_model->edittext4($image,$image2,$image3,$image4,$image5,$image6)){
               $this->session->set_flashdata('SUCCESSMSG','Updated Successfull.');
                echo '<script language="javascript">';
                echo 'alert("Added Successfull")';
                echo '</script>';
                
                 $this->load->view('admin');
               
            }
            else{
               $this->session->set_flashdata('SUCCESSMSG','error!!');
           }
        }   
      else{
      $this->session->set_flashdata('SUCCESSMSG','Not Successfully Added!!');
        }
  }
  
  
  
  
  
   public function addSliderHome3(){
      if($this->input->post()){
      
      $image=$this->input->post('tit1');
     
      
        $addSubjt = array(

           'title'=>$image,
         
          );
       

            $this->load->model('User_model');
            if($this->User_model->edittext5($image)){
               $this->session->set_flashdata('SUCCESSMSG','Updated Successfull.');
                echo '<script language="javascript">';
                echo 'alert("Added Successfull")';
                echo '</script>';
                
                 $this->load->view('admin');
               
            }
            else{
               $this->session->set_flashdata('SUCCESSMSG','error!!');
           }
        }   
      else{
      $this->session->set_flashdata('SUCCESSMSG','Not Successfully Added!!');
        }
  }
  
  
  
  
  
  
  public function addSliderHome12(){
      if($this->input->post()){
      
      $image=$this->input->post('tit1');
      
      
      
       $image2=$this->input->post('tit2');
      
      
      
       $image3=$this->input->post('tit3');
       
       
       
       
       $image4=$this->input->post('tit4');
      
      
      
       $image5=$this->input->post('tit5');
      
      
      
       $image6=$this->input->post('tit6');
       
       
       
       $image7=$this->input->post('tit7');
      
      
      
       $image8=$this->input->post('tit8');
      
      
      
       $image9=$this->input->post('tit9');
       
       
       
       $image10=$this->input->post('tit10');
      
      
      
       $image11=$this->input->post('tit11');
      
      
      
       $image12=$this->input->post('tit12');
    
      
      
    
      
     
      
      
        $addSubjt = array(

           'title'=>$image,
          
           'title2'=>$image2,
         
          
           'title3'=>$image3,
           
           
           
            'title4'=>$image4,
          
           'title5'=>$image5,
         
          
           'title6'=>$image6,
           
           
            'title7'=>$image7,
          
           'title8'=>$image8,
         
          
           'title9'=>$image9,
           
           
            'title10'=>$image10,
          
           'title11'=>$image11,
         
          
           'title12'=>$image12,
          
          

         
          );
       

            $this->load->model('User_model');
            if($this->User_model->edittext12($image,$image2,$image3,$image4,$image5,$image6,$image7,$image8,$image9,$image10,$image11,$image12)){
               $this->session->set_flashdata('SUCCESSMSG','Updated Successfull.');
                echo '<script language="javascript">';
                echo 'alert("Added Successfull")';
                echo '</script>';
                
                 $this->load->view('admin');
               
            }
            else{
               $this->session->set_flashdata('SUCCESSMSG','error!!');
           }
        }   
      else{
      $this->session->set_flashdata('SUCCESSMSG','Not Successfully Added!!');
        }
  }
  
  
  
  public function addSliderHome13(){
      if($this->input->post()){
      
      $image=$this->input->post('tit1');
      
      
      
       $image2=$this->input->post('tit2');
      
      
      
       $image3=$this->input->post('tit3');
       
       
       
       
       $image4=$this->input->post('tit4');
      
      
   
      
        $addSubjt = array(

           'title'=>$image,
          
           'title2'=>$image2,
         
          
           'title3'=>$image3,
           
           
           
            'title4'=>$image4,
          
          
          

         
          );
       

            $this->load->model('User_model');
            if($this->User_model->edittext13($image,$image2,$image3,$image4)){
               $this->session->set_flashdata('SUCCESSMSG','Updated Successfull.');
                echo '<script language="javascript">';
                echo 'alert("Added Successfull")';
                echo '</script>';
                
                 $this->load->view('admin');
               
            }
            else{
               $this->session->set_flashdata('SUCCESSMSG','error!!');
           }
        }   
      else{
      $this->session->set_flashdata('SUCCESSMSG','Not Successfully Added!!');
        }
  }
  
  
  
  
  
   public function addSliderHome14(){
      if($this->input->post()){
      
      $image=$this->input->post('tit1');
      
      
      
       $image2=$this->input->post('tit2');
      
      
      
       $image3=$this->input->post('tit3');
       
       
       
       
       $image4=$this->input->post('tit4');
      
      
      
       $image5=$this->input->post('tit5');
      
      
      
       $image6=$this->input->post('tit6');
       
       
       
       $image7=$this->input->post('tit7');
      
      
      
       $image8=$this->input->post('tit8');
      
      
      
       $image9=$this->input->post('tit9');
       
       
       
       $image10=$this->input->post('tit10');
      
     
        $addSubjt = array(

           'title'=>$image,
          
           'title2'=>$image2,
         
          
           'title3'=>$image3,
           
           
           
            'title4'=>$image4,
          
           'title5'=>$image5,
         
          
           'title6'=>$image6,
           
           
            'title7'=>$image7,
          
           'title8'=>$image8,
         
          
           'title9'=>$image9,
           
           
            'title10'=>$image10,
          
          

         
          );
       

            $this->load->model('User_model');
            if($this->User_model->edittext14($image,$image2,$image3,$image4,$image5,$image6,$image7,$image8,$image9,$image10)){
               $this->session->set_flashdata('SUCCESSMSG','Updated Successfull.');
                echo '<script language="javascript">';
                echo 'alert("Added Successfull")';
                echo '</script>';
                
                 $this->load->view('admin');
               
            }
            else{
               $this->session->set_flashdata('SUCCESSMSG','error!!');
           }
        }   
      else{
      $this->session->set_flashdata('SUCCESSMSG','Not Successfully Added!!');
        }
  }
  
  
  
   public function addSliderHome15(){
      if($this->input->post()){
      
      $image=$this->input->post('tit1');
      
      
      
       $image2=$this->input->post('tit2');
      
      
      
       $image3=$this->input->post('tit3');
       
      
        $addSubjt = array(

           'title'=>$image,
          
           'title2'=>$image2,
         
          
           'title3'=>$image3,
           
          
          );
       

            $this->load->model('User_model');
            if($this->User_model->edittext15($image,$image2,$image3)){
               $this->session->set_flashdata('SUCCESSMSG','Updated Successfull.');
                echo '<script language="javascript">';
                echo 'alert("Added Successfull")';
                echo '</script>';
                
                 $this->load->view('admin');
               
            }
            else{
               $this->session->set_flashdata('SUCCESSMSG','error!!');
           }
        }   
      else{
      $this->session->set_flashdata('SUCCESSMSG','Not Successfully Added!!');
        }
  }
  
  
  
   public function addSliderHome17(){
      if($this->input->post()){
      
      $image=$this->input->post('tit1');
      
      
      
       $image2=$this->input->post('tit2');
      
      
      
       $image3=$this->input->post('tit3');
       
       
       
       
       $image4=$this->input->post('tit4');
      
      
      
       $image5=$this->input->post('tit5');
      
      
      
       $image6=$this->input->post('tit6');
       
       
       
       $image7=$this->input->post('tit7');
      
      
      
       $image8=$this->input->post('tit8');
      
      
      
       $image9=$this->input->post('tit9');
       
       
       
       $image10=$this->input->post('tit10');
      
     
        $addSubjt = array(

           'title'=>$image,
          
           'title2'=>$image2,
         
          
           'title3'=>$image3,
           
           
           
            'title4'=>$image4,
          
           'title5'=>$image5,
         
          
           'title6'=>$image6,
           
           
            'title7'=>$image7,
          
           'title8'=>$image8,
         
          
           'title9'=>$image9,
           
           
            'title10'=>$image10,
          
          

         
          );
       

            $this->load->model('User_model');
            if($this->User_model->edittext17($image,$image2,$image3,$image4,$image5,$image6,$image7,$image8,$image9,$image10)){
               $this->session->set_flashdata('SUCCESSMSG','Updated Successfull.');
                echo '<script language="javascript">';
                echo 'alert("Added Successfull")';
                echo '</script>';
                
                 $this->load->view('admin');
               
            }
            else{
               $this->session->set_flashdata('SUCCESSMSG','error!!');
           }
        }   
      else{
      $this->session->set_flashdata('SUCCESSMSG','Not Successfully Added!!');
        }
  }
  
  
  
   public function addSliderHome18(){
      if($this->input->post()){
      
      $image=$this->input->post('tit1');
      
      
      
       $image2=$this->input->post('tit2');
      
      
      
     
       
      
        $addSubjt = array(

           'title'=>$image,
          
           'title2'=>$image2,
         
         
           
          
          );
       

            $this->load->model('User_model');
            if($this->User_model->edittext18($image,$image2)){
               $this->session->set_flashdata('SUCCESSMSG','Updated Successfull.');
                echo '<script language="javascript">';
                echo 'alert("Added Successfull")';
                echo '</script>';
                
                 $this->load->view('admin');
               
            }
            else{
               $this->session->set_flashdata('SUCCESSMSG','error!!');
           }
        }   
      else{
      $this->session->set_flashdata('SUCCESSMSG','Not Successfully Added!!');
        }
  }
  
    public function orion(){
      
      $data['p'] = $this->User_model->getproducts();
 

      $this->load->view('orion',$data);
  } 
  
  
   public function liv(){
      
           $data['p'] = $this->User_model->getproducts();
      $this->load->view('liv',$data);
  } 
  
   public function liv2(){
      
      
      $this->load->view('liv2');
  } 
  
   public function liv3(){
      
      
      $this->load->view('liv3');
  } 
  
   public function liv4(){
      
      
      $this->load->view('liv4');
  } 
  
  function viewproduct($id){
 $this->load->model('User_model');
 $data['image5'] = $this->User_model->getImage5();
  $data['e'] = $this->User_model->gettxt5();
	    	$data['p'] = $this->User_model->getproductbyid($id);
	    	    $data['pro'] = $this->User_model->getproducts();
	    	  $this->load->view('productview',$data);
	    	

}
  public function productlist(){
      
        $data['p'] = $this->User_model->getproducts();
      $this->load->view('productlist',$data);
  }  
               
               
  
  
  
  

}