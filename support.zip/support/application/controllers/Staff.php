<?php
defined('BASEPATH') || exit('No direct script access allowed');
error_reporting(0);

class Staff extends CI_Controller {
	 public function __construct()
	{
		parent::__construct();
		$this->load->model('User_model');
	
	}

	public function index()
	{ $this->session->set_flashdata('success','');
	
		$this->load->view('Login_Registration/home');
	}

	public function nextpage()
	{ $this->session->set_flashdata('success','');
		$this->session->set_flashdata('emailerror','');
		$this->load->view('Login_Registration/home');
	}

	


function logout()
	{
		session_destroy();
		//redirect(base_url('indexpage#login'));
		redirect('https://oriontechnologies.co.in/');
	}
	public function ticketview()  
	{ $udata = $this->session->userdata('UserLoginSession');
    
			
			$companyid = $udata['companyid'] ;
				$staffid = $udata['userid'] ;
		$this->load->model('User_model');  
		//load the method of model  
		$data['h']=$this->User_model->selectticketsofstaff($staffid);  
         //return the data in view  
         $this->load->view('Staff_view/tickets',$data); 
	} 
	function myticketview()
	{
	    $udata = $this->session->userdata('UserLoginSession');
    
			
			$companyid = $udata['companyid'] ;
				$staffid = $udata['userid'] ;
		$this->load->model('User_model');  
		//load the method of model  
		$data['h']=$this->User_model->selectticketsofstaff($staffid);  
		//return the data in view  
		$this->load->view('Staff_view/myticket', $data); 
	}
	function viewmyoverduetickets()
	{  $udata = $this->session->userdata('UserLoginSession');
    
			
			$companyid = $udata['companyid'] ;
				$staffid = $udata['userid'] ;
		$this->load->model('User_model');  
		//load the method of model  
		$data['h']=$this->User_model->selectticketsofstaff($staffid);  
		//return the data in view  
		$this->load->view('Staff_view/myoverdue', $data); 
	}
	function viewmyduetoday()
	{ $udata = $this->session->userdata('UserLoginSession');
    
			
			$companyid = $udata['companyid'] ;
				$staffid = $udata['userid'] ;
		$this->load->model('User_model');  
		//load the method of model  
		$data['h']=$this->User_model->selectticketsofstaff($staffid);  
		//return the data in view  
		$this->load->view('Staff_view/myduetoday', $data); 
	}
	function viewmypending()
	{$udata = $this->session->userdata('UserLoginSession');
    
			
			$companyid = $udata['companyid'] ;
				$staffid = $udata['userid'] ;
		$this->load->model('User_model');  
		//load the method of model  
		$data['h']=$this->User_model->selectticketsofstaff($staffid);  
		//return the data in view  
		$this->load->view('Staff_view/mypending', $data); 
	
	}
	function viewopentickets()
	{	 $udata = $this->session->userdata('UserLoginSession');
    
			
			$companyid = $udata['companyid'] ;
	  
         $this->load->model('User_model');  
         //load the method of model  
          $data['h']=$this->User_model->selectallticket($companyid);
		//return the data in view  
		$this->load->view('Staff_view/opentickets', $data); 

	}
	function viewoverduetickets()
	{ $udata = $this->session->userdata('UserLoginSession');
    
			
			$companyid = $udata['companyid'] ;
	  
         $this->load->model('User_model');  
         //load the method of model  
          $data['h']=$this->User_model->selectallticket($companyid);
		//return the data in view  
		$this->load->view('Staff_view/overduetickets', $data); 
	}
	function viewunassigned()
	{	$this->load->model('User_model');  
		//load the method of model  
		$data['h']=$this->User_model->select();  
		//return the data in view  
		$this->load->view('Staff_view/unassigned', $data); 

	}
	function viewunanswered()
	{	$this->load->model('User_model');  
		//load the method of model  
		$data['h']=$this->User_model->select();  
		//return the data in view  
		$this->load->view('Staff_view/unanswered', $data); 
	}
		public function registeruser()  
	{  
	  
         
         $this->load->view('Staff_view/userregistration'); 
	} 
	function removeuser()
	{$udata = $this->session->userdata('UserLoginSession');
    
			$companyid = $udata['companyid'] ;
	     if($_SERVER['REQUEST_METHOD']=='POST')
    	{
    	    	$email = $this->input->post('delete');

    	    	 $this->load->model('User_model');  
         
         $this->User_model->removeuser($email); 
         
    	}
	    
	    $this->load->model('User_model'); 
	    $udata = $this->session->userdata('UserLoginSession');
        $usrid=$udata['userid'] ;
        $urol=$udata['role'] ;
		//load the method of model  
		if($urol=="Staff"){
		    $data['m']=$this->User_model->selectStfCret($usrid); 
		}else{
		    $data['m']=$this->User_model->selectuser($companyid); 
		}
		//return the data in view  
		$this->load->view('Staff_view/userremoval', $data); 
	}
	 function view_faq(){
        $udata = $this->session->userdata('UserLoginSession');
    
		
			$companyid = $udata['companyid'] ;
         $this->load->model('User_model');
          
	    $data['m']=$this->User_model->view_faq($companyid);
    $this->load->view('Staff_view/faq_view',$data);
}
function opencomp(){
    	if($_SERVER['REQUEST_METHOD']=='POST')
	{
	    	$id = $this->input->post('ticketid');
	    	$data['tick'] = $this->User_model->getticket($id);
	    	  $this->load->view('Staff_view/complaint',$data);
	    	
	}

}
	function myresolvedtickets(){
	    $udata = $this->session->userdata('UserLoginSession');
    
		
			$staffid = $udata['userid'] ;
	   	$data['h']=$this->User_model->selectresolved($staffid);  
	
		$this->load->view('Staff_view/resolved', $data);  
	}
	function generatebill(){
	   	if($_SERVER['REQUEST_METHOD']=='POST')
	{
	    	$cname= $this->input->post('customername');
	    	$cphone= $this->input->post('cphone');
	    	$engineer= $this->input->post('engineer');
	    	$ephone= $this->input->post('ephone');
	    	$tickid= $this->input->post('tickid');
	    	$item= $this->input->post('item');
	    	$model= $this->input->post('model');
	    	$brand= $this->input->post('brand');
	    	$rqr= $this->input->post('rqr');
	    	$complaint= $this->input->post('complaint');
	    	$work= $this->input->post('work');
	    	$note= $this->input->post('note');
	    	$paymentby= $this->input->post('paymentby');
	    	$amount= $this->input->post('amount');
	    	$paystatus= $this->input->post('paystatus');
	    	if($complaint){
	    	   	$data = array(
                        'customername'=>$cname,
						'cphone'=>$cphone,
						'engineer' => $engineer,
						'ephone' => $ephone,
						'tickid' => $tickid,
						'item'=> $item,
						'model' => $model,
						'brand' => $brand,
						'rqr' => $rqr,
						'complaint' => $complaint,
						'work' => $work,
						'note' => $note,
						'paymentby' => $paymentby,
						'amount' => $amount,
						'paystatus' => $paystatus,
						'status'=>1
					);
	    	 $this->User_model->insertresponse($data,$tickid); 
	   	$data['tick']=$this->User_model->getbill($tickid);  
	
		$this->load->view('Staff_view/bill', $data);   
	    	}else{
	    	 	redirect('Ticketresponse/opencomp/'.$tickid);
	    	}
	    
	} 
	}
	function viewbill($id){
	 	$data['tick']=$this->User_model->getbill($id);  
	
		$this->load->view('Staff_view/bill1', $data);     
	}
		function myviewbill($id){
	 	$data['tick']=$this->User_model->getbill($id);  
	
		$this->load->view('Staff_view/bill3', $data);     
	}
	function viewcustomerbill($id){
	    	$data['tick']=$this->User_model->getbill($id);  
	        if(empty($data['tick'])){
	            $this->load->view('Staff_view/bill4', $data);  
	        }else{
		        $this->load->view('Staff_view/bill2', $data);  
	        }
	}
}



