<?php
defined('BASEPATH') || exit('No direct script access allowed');

class Customer extends CI_Controller {
       public function __construct()
	{
		parent::__construct();
		$this->load->model('User_model');
		$customer;
	}
	public function index()
	{ $this->session->set_flashdata('success','');
	
		$this->load->view('Login_Registration/home');
	}

	public function nextpage()
	{ $this->session->set_flashdata('success','');
		$this->session->set_flashdata('emailerror','');
		$this->load->view('Login_Registration/home');
	}

	


	 function logout()
	{
		session_destroy();
		redirect(base_url('indexpage#login'));
	}
	public function homepage()  
	{   $udata = $this->session->userdata('UserLoginSession');
    	$cusid = $udata['userid'] ;
	 	$data['h']=$this->User_model->selectcustomertickets($cusid);  
         $this->load->view('Customer_View/homepage',$data); 
	} 
	
		public function bookticket()  
	{  	$udata = $this->session->userdata('UserLoginSession');
    	$cusid = $udata['userid'] ;
	 	$data['h']=$this->User_model->selectcustomertickets($cusid);  
	 	if($_SERVER['REQUEST_METHOD']=='POST')
	{
   
    
     date_default_timezone_set('Asia/Kolkata');
            $companyname=$udata['companyname'];
            $companyid=$udata['companyid'];
			$customername = $udata['username'] ;
			$customerid=$udata['userid'];
			$name= $this->input->post('name');
			$email =  $this->input->post('email');
			$phone =  $this->input->post('phone');
			$address =  $this->input->post('address');
			$item =  $this->input->post('item');
			$model =  $this->input->post('model');
			$brand =  $this->input->post('brand');
			$prodetail =  $this->input->post('prodetail');
			$comdetail =  $this->input->post('comdetail');
			$remark =  $this->input->post('remark');
				$date=date("Y/m/d");
			$time=date("H:i:s");
	
		
			$data1 = array(
			    'companyname'=>$companyname,
			    'companyid'=>$companyid,
			    'customername'=>$customername,
				'customerid'=>$customerid,
				
				'email'=>$email,
				'phone'=>$phone,
				'address'=>$address,
				'item'=>$item,
				'model'=>$model,
				'brand'=>$brand,
				'prodetail'=>$prodetail,
				'rqr'=>$comdetail,
				'remark'=>$remark,
				'status'=>'1',
				'date'=>$date,
				'time'=>$time,
				'view_status'=>'0',
				'staffid'=>'0',
				'staff'=>'-',
				'assign_status'=>'0',
			);

			$this->load->model('User_model');
			$this->User_model->registerticket($data1);
			$this->session->set_flashdata('ticketsuccess','Ticket Registered');
		
		$this->load->view('Customer_View/bookticket',$data); 
		
	}
	else{
	    	$this->session->set_flashdata('ticketsuccess','');
         $this->load->view('Customer_View/bookticket',$data); 
	} 
	}
		 function faq(){
        $udata = $this->session->userdata('UserLoginSession');
   
    	$cusid = $udata['userid'] ;
	 	$data['h']=$this->User_model->selectcustomertickets($cusid);  
		
			$companyid = $udata['companyid'] ;
         $this->load->model('User_model');
	    $data['m']=$this->User_model->view_faq($companyid);
    $this->load->view('Customer_View/faq_view',$data);
}
	
	function front()
	{
     $this->load->model('User_model');
 $data['image1'] = $this->User_model->getImage1();
 $data['image2'] = $this->User_model->getImage2();
  $data['image3'] = $this->User_model->getImage3();
  
 $data['a'] = $this->User_model->gettxt();
  $data['b'] = $this->User_model->gettxt2();
  $data['c'] = $this->User_model->gettxt3();
  
	   $this->load->view('Customer_View/front',$data);
	}
	 function add(){
	       $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        if($this->input->post('membersubmit')){
              $email=$udata['email'] ;
               $image['check']= $this->User_model->getImage($email);
            
             foreach( $image['check']->result() as $row){
                     if (file_exists("uploads/images/".$row->profile_img)){      
                 unlink("uploads/images/".$row->profile_img);
                     }
             }
            //Check whether Member upload profile_img
            if(!empty($_FILES['profile_img']['name'])){
                $config['upload_path'] = 'uploads/images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mp3';
                $config['file_name'] = $_FILES['profile_img']['name'];
                
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('profile_img')){
                    $uploadData = $this->upload->data();
                    $profile_img = $uploadData['file_name'];
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $profile_img = '';
                    redirect(base_url('Customer/displayimage'));
                }
            }else{
                $profile_img = '';
            }
            
         
                
              
      
            
            
            //Pass Member data to model
            $insertMemberData = $this->User_model->insert($email,$profile_img);
            
            //Storing insertion status message.
            if($insertMemberData){
                $this->session->set_flashdata('success_msg', 'Image updated successfully.');
            }else{
                $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
            }
        }
        //Form for adding Member data
        $data['image'] = $this->User_model->getImage($email);
        $this->session->set_flashdata('error_msg', NULL);
            $this->session->set_flashdata('proimg', '$image');
            $this->load->view('add',$data);
    }
    function displayimage(){
         $this->load->model('User_model');
        $udata = $this->session->userdata('UserLoginSession');
        
             $email=$udata['email'] ;
            $data['image'] = $this->User_model->getImage($email);
            $this->session->set_flashdata('proimg', '$image');
            $this->load->view('add',$data);
          
               }
    function  viewmytickets(){
                  $udata = $this->session->userdata('UserLoginSession');
    
			
		
				$cusid = $udata['userid'] ;
		$this->load->model('User_model');  
		//load the method of model  
		$data['h']=$this->User_model->selectcustomertickets($cusid);  
		//return the data in view  
		$this->load->view('Customer_View/myticket', $data); 
             }
    function editprofile(){
          $udata = $this->session->userdata('UserLoginSession');
   	if($_SERVER['REQUEST_METHOD']=='POST')
	{	$id = $this->input->post('proid');
	    	$username = $this->input->post('name');
			$email =$this->input->post('email');
				$phone = $this->input->post('phone');
			$address =$this->input->post('address');
				$password =$this->input->post('password');
					$pincode =$this->input->post('pincode');
					$this->User_model->editpro($id,$username,$email,$phone,$address,$password,$pincode);
						$status = $this->User_model->getpro($id);
						 $userid=$status->id;
					$username = $status->username;
					$email = $status->email;
					$role=$status->role;
					$profile_img=$status->profile_img;
					$companyname=$status->companyname;
					$companyid=$status->companyid;
					$phone=$status->phone;
						$address=$status->address;
					$session_data = array(
                        'userid'=>$userid,
						'username'=>$username,
						'email' => $email,
						'phone' => $phone,
						'address' => $address,
						'profile'=> $profile_img,
						'companyname' => $companyname,
						'companyid' => $companyid,
						'role'=>$role
					);
	}
    	$cusid = $udata['userid'] ;
	 	$data['h']=$this->User_model->selectcustomertickets($cusid);  
	 		$data['pro']=$this->User_model->getpro($cusid);  
        	$this->load->view('Customer_View/editprofile', $data); 
    }
		public function complaint() { 
			if($_SERVER['REQUEST_METHOD']=='POST')
			{

					
				date_default_timezone_set('Asia/Kolkata');
				$companyname='test_company2';
				$companyid='2';

				$name= $this->input->post('name');
				$email =  $this->input->post('email');
				$phone =  $this->input->post('phone');
				$address =  $this->input->post('address');
				$item =  $this->input->post('item');
				$model =  $this->input->post('model');
				$brand =  $this->input->post('brand');
				$prodetail =  $this->input->post('prodetail');
				$comdetail =  $this->input->post('comdetail');
				$remark =  $this->input->post('remark');
				$date=date("Y/m/d");
				$time=date("H:i:s");
				$companyid='2' ;
				$companyname='test_company2' ;


				$cemail = $email;

				$password_1 = 'password';
				$referalid = '-';
				$pincode = '-';
				$designation ="Customer";

				$userdata = array(
				'username'=>$name,
				'companyid'=>$companyid,
				'companyname'=>$companyname,
				'designation'=>$designation,
				'email'=>$email,
				'cemail'=>$cemail,
				'phone'=>$phone,

				'password_1'=>$password_1,
				'profile_img'=>NULL,
				'referalid'=>$referalid,
				// 'pincode'=>$pincode,
				'status'=>'1',
				// 'address'=>$address,
				'role'=>'Customer'
				);

				$this->load->model('User_model');
				$this->User_model->insertuser($userdata,$phone);
				$status=	$this->User_model->getbyphone($phone);
				$data['u']=	$this->User_model->getticketbyid($status->id);
				$count=0;
				foreach($data['u']->result() as $row){
				$t1=$row->time;  
				$d1=$row->date;


				$start_date = strtotime($d1);
				$end_date = strtotime($date);
				$day=($end_date - $start_date)/(60*60*24);	  
				if($day<1){
				$count=$count+1;


				}
				if($day==1){
					$time1 = new DateTime($t1);
					$timemax=new DateTime("24:00:00");
					$timemin=new DateTime("00:00:00");
					$time2 = new DateTime($time);
					$interval1 = $time1->diff($timemax);
					$interval2 = $timemin->diff($time2);
					$h1= $interval1->format('%H');
					$i1= ($interval1->format('%i')/60);
					$s1= ($interval1->format('%s')/(60*60));
					$diff1=$h1+$i1+$s1; 
					$h2= $interval2->format('%H');
					$i2= ($interval2->format('%i')/60);
					$s2= ($interval2->format('%s')/(60*60));
					$diff2=$h2+$i2+$s2; 
					$tottime=$diff1+$diff2;
					if($tottime<24){
					$count=$count+1;  
					}
				}


				}
				if($count>=2){
					$this->session->set_flashdata('ticketsuccess','You have reached your Complaint Limit, Please Try Again after 24 hours.');
					$data['flag']=2;

					$this->load->view('Customer_View/complaint',$data);  
				}else{
					$data1 = array(
					'companyname'=>$companyname,
					'companyid'=>$companyid,
					'customername'=>$name,
					'customerid'=>$status->id,

					'email'=>$email,
					'phone'=>$phone,
					// 'address'=>$address,
					// 'item'=>$item,
					// 'model'=>$model,
					// 'brand'=>$brand,
					// 'prodetail'=>$prodetail,
					'rqr'=>$comdetail,
					// 'remark'=>$remark,
					'status'=>'0',
					'date'=>$date,
					'time'=>$time,
					'view_status'=>'0',
					'staffid'=>'0',
					'staff'=>'-',
					'assign_status'=>'0',
					);

					$this->load->model('User_model');
					$this->User_model->registerticket($data1);
					$this->session->set_flashdata('ticketsuccess','Your Complaint has been Assigned, Our Service Team will contact to you shortly. Check Your service status by using your complaint id to know the updates.');
					$data['flag']=1;
					$data['tick']=$tick=	$this->User_model->getticketid($phone,$status->id);

					//sms integration 
					if(strlen($phone)>10){
						$mob = substr($phone,-10);
					} 
					else{
						$mob = $phone;
					}
 			
					$sms ="We have received your Complaint. Your support complaint number is #".$tick->id.". Please do not hesitate to contact us again if any questions arise.";
					$this->User_model->sendsms($phone,$mob);
					$mob = '9895770723';
					$sms ="New complaint is registed in orion portel with Complaint no #".$tick->id.", Name:".$name.", Phone:".$phone;
					$this->User_model->sendsms($phone,$mob);

					
					$this->load->view('Customer_View/complaint',$data);   
				}




			}
			else{
				$data['flag']=0;
				$this->session->set_flashdata('ticketsuccess','');
				$this->load->view('Customer_View/complaint',$data); 
			} 
		}
	
	public function complaintpage(){
	    $this->load->view('Customer_View/complaintst'); 
	}
	public function sendsms(){
		$phone="9526878048";
		$sms ="testing";
		$this->User_model->sendsms($phone,$sms);
	}
}