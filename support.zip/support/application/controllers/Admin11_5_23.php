<?php
defined('BASEPATH') || exit('No direct script access allowed');
error_reporting(0);

class Admin extends CI_Controller {
	public $companyid = '2' ;
 public function __construct()
	{
		parent::__construct();
		$this->load->model('User_model');
		$customer;
		
	}
	public function index()
	{ $this->session->set_flashdata('success','');
	
		$this->load->view('Login_Registration/home');
	}

	public function nextpage()
	{ $this->session->set_flashdata('success','');
		$this->session->set_flashdata('emailerror','');
		$this->load->view('Login_Registration/home');
	}

	


 function logout()
	{
		session_destroy();
		//redirect(base_url('indexpage#login'));
		redirect('https://oriontechnologies.co.in/');
	}
	public function ticketview()  
	{   $udata = $this->session->userdata('UserLoginSession');
    
			
			//$companyid = '2' ;
	  
         $this->load->model('User_model');  
         //load the method of model  
         $data['h']=$this->User_model->selectallticket($this->companyid);
          $data['i']=$this->User_model->selectbyorder($this->companyid);
           $data['j']=$this->User_model->selectall($this->companyid);
         //return the data in view  
         $this->load->view('Admin_view/tickets', $data); 
	} 
		public function registerstaff()  
	{  
	    $udata = $this->session->userdata('UserLoginSession');
		$data=array();
		$menu = explode('::',__METHOD__);
		$data['active']=trim($menu[1]);
			
			//$companyid = '2' ;
	   $this->load->model('User_model');  
          $data['i']=$this->User_model->selectbyorder($this->companyid);
            $data['j']=$this->User_model->selectall($this->companyid);
         $this->load->view('Admin_view/registerstaff',$data); 
	}
	public function dealerstaff()  
	{   $udata = $this->session->userdata('UserLoginSession');
    
		$data=array();
		$menu = explode('::',__METHOD__);
		$data['active']=trim($menu[1]);
			//$companyid = '2' ;
	   $this->load->model('User_model');  
          $data['i']=$this->User_model->selectbyorder($this->companyid);
            $data['j']=$this->User_model->selectall($this->companyid);
         $this->load->view('Admin_view/dealerregister',$data); 
	}
	function allticketview(){
		$data=array();
		$menu = explode('::',__METHOD__);
		$data['active']=trim($menu[1]);
	    $udata = $this->session->userdata('UserLoginSession');
    	//$companyid = '2' ;
		$this->load->model('User_model');  
		//load the method of model  
		
		//  $data['i']=$this->User_model->selectbyorder($this->companyid);
		//    $data['j']=$this->User_model->selectall($this->companyid);
		//return the data in view  
		$this->load->view('Admin_view/myticket', $data); 
	}
	function getticket(){
		$draw = intval($this->input->get("draw"));
        $start = intval($this->input->get("start"));
      	$length = intval($this->input->get("length"));
		$data = [];
		$h=$this->User_model->selectallticket($this->companyid); 
		foreach ($h->result() as $row)  
                      {   
                        // $d1=new DateTime();
                        // $d2 = date_create($row->date);
                        // $row->diff=date_diff($d2,$d1);
                        // $row->d=(int)$row->diff->format("%R%a");
$staff ='';
						 $staff = $row->staff.($row->staffid!=0)? '(Engineer Id:'.$row->staffid.')':'' ;
						$status='';
						if(($row->status)==0){ $status='<p style="color:red"> Open </p>';
						 } 
						 if(($row->status)==1){ 
							$status='<p style="color:#a63d05"> Working </p>';}
							if(($row->status)==2){ $status='<p style="color:#bf762c"> Temporarly Closed </p>'; } 
							 if(($row->status)==3){ $status='<p style="color:green"> Closed </p>'; } 
						 	 $status1='';
							 if(($row->status==3)||($row->status==2)){ 
								$status1='<p><a href="'.base_url("Superadmin/viewbill1/".$row->id).'" type="link" class="link" >View Bill</a></p>';
							}
							$assign_status='';
							if(($row->assign_status)==0){ 
								$assign_status='<p style="color:red"> Unassigned </p>';
							 } 
							 if(($row->assign_status)==1){ $assign_status='<p style="color:green"> Assigned </p>';
							 }
							 $link ='';
							 $link ='<a href="'.base_url("Superadmin/editComplaint/".$row->id).'"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> </a>
							    &nbsp;&nbsp;&nbsp;<a onclick="deleteTicket(\''.$row->id .'\');"><i class="fa fa-trash " style="color:red;" aria-hidden="true"></i> </a>';
						
							 $data[] = array(
							$row->id,
							$row->date.' '.$row->time,
							$row->customername,
							$row->phone,
							$row->item,
							$staff,
							 $status,
							 $status1,
							 $assign_status,
							 $link
						);
                      
                        }  
						$result1 = array(
							"draw" => $draw,
							  "recordsTotal" => count($h),
							  "recordsFiltered" => count($h),
							  "data" => $data
						 );   

   echo json_encode($result1);
   exit();
		 
		
	}
	function deleteticket(){
		$id =  $this->input->post("id");
		if($this->User_model->deleteticket($id)){
			echo 1;
		}else{
			echo 0;
		}
	}
	function viewmyoverduetickets()
	{ $udata = $this->session->userdata('UserLoginSession');
    
			
			//$companyid = '2' ;
		$this->load->model('User_model');  
		//load the method of model  
		$data['h']=$this->User_model->selectallticket($this->companyid);  
		 $data['i']=$this->User_model->selectbyorder($this->companyid);
		 $data['j']=$this->User_model->selectall($this->companyid);
		//return the data in view  
		$this->load->view('Admin_view/myoverdue', $data); 
	}
	function viewmyduetoday()
	{ $udata = $this->session->userdata('UserLoginSession');
		$data=array();
		$menu = explode('::',__METHOD__);
		$data['active']=trim($menu[1]);
			
			//$companyid = '2' ;
	    $this->load->model('User_model');  
		//load the method of model  
		$data['h']=$this->User_model->selectallticket($this->companyid);  
		 $data['i']=$this->User_model->selectbyorder($this->companyid);
		   $data['j']=$this->User_model->selectall($this->companyid);
		//return the data in view  
		$this->load->view('Admin_view/myduetoday', $data); 
	}
	function viewmypending()
	{ $udata = $this->session->userdata('UserLoginSession');
    
			
			//$companyid = '2' ;
	    $this->load->model('User_model');  
		//load the method of model  
		$data['h']=$this->User_model->selectallticket($this->companyid);  
		 $data['i']=$this->User_model->selectbyorder($this->companyid);
		   $data['j']=$this->User_model->selectall($this->companyid);
		//return the data in view  
		$this->load->view('Admin_view/mypending', $data); 
	
	}
	function viewopentickets()
	{ $udata = $this->session->userdata('UserLoginSession');
    
		$data=array();
		$menu = explode('::',__METHOD__);
		$data['active']=trim($menu[1]);	
			//$companyid = '2' ;
	    $this->load->model('User_model');  
		//load the method of model  
		$data['h']=$this->User_model->selectallticket($this->companyid);
		 $data['i']=$this->User_model->selectbyorder($this->companyid);
		   $data['j']=$this->User_model->selectall($this->companyid);
		//return the data in view  
		$this->load->view('Admin_view/opentickets', $data); 

	}
	function viewoverduetickets()
	{ $udata = $this->session->userdata('UserLoginSession');
    
		$data=array();
		$menu = explode('::',__METHOD__);
		$data['active']=trim($menu[1]);	
			//$companyid = '2' ;
	    $this->load->model('User_model');  
		//load the method of model  
		$data['h']=$this->User_model->selectallticket($this->companyid);  
		 $data['i']=$this->User_model->selectbyorder($this->companyid);
		   $data['j']=$this->User_model->selectall($this->companyid);
		//return the data in view  
		$this->load->view('Admin_view/overduetickets', $data); 
	}
	function viewunassigned()
	{ $udata = $this->session->userdata('UserLoginSession');
		$data=array();
		$menu = explode('::',__METHOD__);
		$data['active']=trim($menu[1]);
			
			//$companyid = '2' ;
			
	    $this->load->model('User_model');  
		//load the method of model  
		$data['h']=$this->User_model->selectallticket($this->companyid);
		 $data['i']=$this->User_model->selectbyorder($this->companyid);
		   $data['j']=$this->User_model->selectall($this->companyid);
		//return the data in view  
		$this->load->view('Admin_view/unassigned', $data); 

	}
	function viewassigned(){
	   	$udata = $this->session->userdata('UserLoginSession');
		   $data=array();
		   $menu = explode('::',__METHOD__);
		   $data['active']=trim($menu[1]);
			
			//$companyid = '2' ;
			$this->load->model('User_model');  
		//load the method of model  
		$data['h']=$this->User_model->selectallticket($this->companyid);  
		 $data['i']=$this->User_model->selectbyorder($this->companyid);
		   $data['j']=$this->User_model->selectall($this->companyid);
		//return the data in view  
		$this->load->view('Admin_view/assigned', $data);  
	}
	function viewunanswered()
	{	$udata = $this->session->userdata('UserLoginSession');
    
			
			//$companyid = '2' ;
			$this->load->model('User_model');  
		//load the method of model  
		$data['h']=$this->User_model->selectallticket($this->companyid);  
		 $data['i']=$this->User_model->selectbyorder($this->companyid);
		   $data['j']=$this->User_model->selectall($this->companyid);
		//return the data in view  
		$this->load->view('Admin_view/unanswered', $data); 
	}
		function removestaff()
	{$udata = $this->session->userdata('UserLoginSession');
    
		$data=array();
		$menu = explode('::',__METHOD__);
		$data['active']=trim($menu[1]);
			//$companyid = '2' ;
			
	     if($_SERVER['REQUEST_METHOD']=='POST')
    	{
    	    	$email = $this->input->post('delete');
    	    $status= $this->User_model->getstaff($email);
    	    $proimg=$status->profile_img;
    	    $idproof=$status->id_proof;
    	    if(($proimg==NULL)||($proimg=='')){
    	        $imgpath = 'images/Staff/'.$proimg;
       unlink( $imgpath );   
    	    }
    	     if(($idproof==NULL)||($idproof=='')){
    	        $imgpath = 'images/Staff/'.$idproof;
       unlink( $imgpath );   
    	    }
    	    	 $this->load->model('User_model');  
         
         $this->User_model->removestaff($email); 
         
    	}
	    
	    $this->load->model('User_model');  
		//load the method of model  
		$data['m']=$this->User_model->selectstaff($this->companyid);  
		 $data['i']=$this->User_model->selectbyorder($this->companyid);
		   $data['j']=$this->User_model->selectall($this->companyid);
		//return the data in view  
		$this->load->view('Admin_view/removestaff', $data); 
	}
	function removedealer()
	{$udata = $this->session->userdata('UserLoginSession');
    
		$data=array();
		$menu = explode('::',__METHOD__);
		$data['active']=trim($menu[1]);
			//$companyid = '2' ;
			
	     if($_SERVER['REQUEST_METHOD']=='POST')
    	{
    	    	$email = $this->input->post('delete');
    	    $status= $this->User_model->getdealer($email);
    	    $proimg=$status->profile_img;
    	    $idproof=$status->id_proof;
    	    if(($proimg==NULL)||($proimg=='')){
    	        $imgpath = 'images/Staff/'.$proimg;
       unlink( $imgpath );   
    	    }
    	     if(($idproof==NULL)||($idproof=='')){
    	        $imgpath = 'images/Staff/'.$idproof;
       unlink( $imgpath );   
    	    }
    	    	 $this->load->model('User_model');  
         
         $this->User_model->removedealer($email); 
         
    	}
	    
	    $this->load->model('User_model');  
		//load the method of model  
		$data['m']=$this->User_model->selectdealer($this->companyid);  
		 $data['i']=$this->User_model->selectbyorder($this->companyid);
		   $data['j']=$this->User_model->selectall($this->companyid);
		//return the data in view  
		$this->load->view('Admin_view/removedealer', $data); 
	}
			public function notification()  
	{  
	  $udata = $this->session->userdata('UserLoginSession');
    
			
			//$companyid = '2' ;
			
         $this->load->model('User_model');  
         //load the method of model  
         $data['h']=$this->User_model->selectallticket($this->companyid);
          $data['i']=$this->User_model->selectbyorder($this->companyid);
          foreach($data['h']->result() as $row){
             $id=$row->id;
            
           $this->User_model->changeviewstatus($id);  
     
         }
           $data['j']=$this->User_model->selectall($this->companyid);
         //return the data in view  
         $this->load->view('Admin_view/notification', $data); 
	} 
		public function assignstaff()  
	{  
		$data=array();
		$menu = explode('::',__METHOD__);
		$data['active']=trim($menu[1]);
		$udata = $this->session->userdata('UserLoginSession');
    
			
			//$companyid = '2' ;
			$this->load->model('User_model'); 
	   if($_SERVER['REQUEST_METHOD']=='POST')
    	{   
    	    $this->form_validation->set_rules('staff','Staff','required');
    	   
			
			if($this->form_validation->run()==TRUE)
			{
    	    	 $staff = $this->input->post('staff');
    	    	 $data['staff']=	$this->User_model->staffdetails($staff); 
    	    	 	foreach($data['staff']->result() as $value){
						$staffname= $value->username;
						}
						$ticket = $this->input->post('ticket');
						if($ticket==NULL){
							echo "<script>alert('Ticket not selected');</script>";
						}
						else{
								foreach($ticket as $temp){
									$this->User_model->assignticket($staff,$staffname,$temp);
									//sms integration 


								}
						}
    	     
         
        
    		}
    	
    	}
      
         //load the method of model  
         $data['h']=$this->User_model->selectallticket($this->companyid);
          $data['i']=$this->User_model->selectbyorder($this->companyid);
         
           $data['j']=$this->User_model->selectall($this->companyid);
            $data['k']=$this->User_model->selectticket($this->companyid);
             $data['l']=$this->User_model->selectstaff($this->companyid);
         //return the data in view  
         $this->load->view('Admin_view/assignstaff', $data); 
	} 
		public function faqcreation()  
	{  	$udata = $this->session->userdata('UserLoginSession');
    
			
		//	$companyid = '2' ;
			
	    $companyname = "";

			$question ="";
			$answer = "";
		    $status="";
	 	if($_SERVER['REQUEST_METHOD']=='POST')
	{
    $udata = $this->session->userdata('UserLoginSession');
    
			$companyname = 'test_company2' ;
		
			$question = $this->input->post('question');
			$answer = $this->input->post('answer');
		    $status=1;

			$this->load->model('User_model');
			 $data['i']=$this->User_model->selectbyorder($this->companyid);
         
           $data['j']=$this->User_model->selectall($this->companyid);
			$this->User_model->registerfaq($companyname,$this->companyid,$question,$answer,$status);
		
			$this->session->set_flashdata('faqsuccess','FAQ Registered');
			
		$this->load->view('Admin_view/faqcreation',$data); 
		
	}else{
	    	$this->session->set_flashdata('faqsuccess','');
	    $this->load->model('User_model');
	    $data['i']=$this->User_model->selectbyorder($this->companyid);
        $data['j']=$this->User_model->selectall($this->companyid);
		$this->load->view('Admin_view/faqcreation',$data);
	}

}
    function view_faq(){
        $udata = $this->session->userdata('UserLoginSession');
    
		
		//	$companyid = '2' ;
         $this->load->model('User_model');
           $data['i']=$this->User_model->selectbyorder($this->companyid);
        $data['j']=$this->User_model->selectall($this->companyid);
	    $data['m']=$this->User_model->view_faq($this->companyid);
    $this->load->view('Admin_view/view_faq',$data);
}
    function faq_delete($id){
    	 $this->load->model('User_model');  
         
         $this->User_model->faq_delete($id); 
         		redirect(base_url('Admin/view_faq'));
}
function staffedit($id)
{	

	if($_SERVER['REQUEST_METHOD']=='POST')
	{
		
		
		
	
	       
          
			$username = $this->input->post('username');
			$email = $this->input->post('email');
			$cemail = $this->input->post('cemail');
			$phone = $this->input->post('phone');
			$designation = $this->input->post('designation');
			$password_1 = $this->input->post('password');
			$address=$this->input->post('address');
			$pincode = $this->input->post('pincode');
			$this->User_model->editstaffdetails($id,$username,$email,$cemail,$phone,$designation,$password_1,$pincode,$address);
			 $status= $this->User_model->getstaff($id);
    	    $proimg=$status->profile_img;
    	    $idproof=$status->id_proof;
                  if(!empty($_FILES['image']['name'])){  
       $config['upload_path'] = 'images/Staff/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|';
                $config['file_name'] = $_FILES['image']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
               
                if($this->upload->do_upload('image')){ 
                    $uploadData = $this->upload->data();
                    $image1 = $uploadData['file_name'];
                    if(($proimg!=NULL)||($proimg!='')){
    	        $imgpath = 'images/Staff/'.$proimg;
       unlink( $imgpath );   
    	    }
                  	$this->User_model->editstaffpro($id,$image1);  
         
                }
            }
				
			 if(!empty($_FILES['imge']['name'])){  
       
                $config['upload_path'] = 'images/Staff/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|';
                $config['file_name'] = $_FILES['imge']['name'];
             
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('imge')){
                    $uploadData = $this->upload->data();
                    $image2 = $uploadData['file_name'];
                      if(($idproof!=NULL)||($idproof!='')){
    	        $imgpath = 'images/Staff/'.$idproof;
       unlink( $imgpath );   
    	    }
         	$this->User_model->editstaffid($id,$image2);  
		
                    
                }
            }
		
		
				redirect('Admin/staffedit/'.$id);
		
		
	}
	$data['staff']=	$this->User_model->getstaffdet($id);
	$this->load->view('Admin_view/viewstaff',$data);	
}
function dealeredit($id)
{	

	if($_SERVER['REQUEST_METHOD']=='POST')
	{
		
		
		
	
	       
          
			$username = $this->input->post('username');
			$email = $this->input->post('email');
			$cemail = $this->input->post('cemail');
			$phone = $this->input->post('phone');
			$designation = $this->input->post('designation');
			$password_1 = $this->input->post('password');
			$address=$this->input->post('address');
			$pincode = $this->input->post('pincode');
			$this->User_model->editdealerdetails($id,$username,$email,$cemail,$phone,$designation,$password_1,$pincode,$address);
			 $status= $this->User_model->getdealer($id);
    	    $proimg=$status->profile_img;
    	    $idproof=$status->id_proof;
                  if(!empty($_FILES['image']['name'])){  
       $config['upload_path'] = 'images/Staff/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|';
                $config['file_name'] = $_FILES['image']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
               
                if($this->upload->do_upload('image')){ 
                    $uploadData = $this->upload->data();
                    $image1 = $uploadData['file_name'];
                    if(($proimg!=NULL)||($proimg!='')){
    	        $imgpath = 'images/Staff/'.$proimg;
       unlink( $imgpath );   
    	    }
                  	$this->User_model->editdealerpro($id,$image1);  
         
                }
            }
				
			 if(!empty($_FILES['imge']['name'])){  
       
                $config['upload_path'] = 'images/Staff/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|';
                $config['file_name'] = $_FILES['imge']['name'];
             
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('imge')){
                    $uploadData = $this->upload->data();
                    $image2 = $uploadData['file_name'];
                      if(($idproof!=NULL)||($idproof!='')){
    	        $imgpath = 'images/Staff/'.$idproof;
       unlink( $imgpath );   
    	    }
         	$this->User_model->editdealerid($id,$image2);  
		
                    
                }
            }
		
		
				redirect('Admin/dealeredit/'.$id);
		
		
	}
	$data['dealer']=	$this->User_model->getdealerdet($id);
	$this->load->view('Admin_view/viewdealer',$data);	
}
function revokelogin($id){
    $this->User_model->revokestaff($id);
    	redirect(base_url('Admin/removestaff'));
}

function revokedealerlogin($id){
    $this->User_model->revokedealer($id);
    	redirect(base_url('Admin/removedealer'));
}
public function dailyReport(){
$data=array();
	$menu = explode('::',__METHOD__);
		$data['active']=trim($menu[1]);
	if($this->session->userdata('UserLoginSession')){
		
		$data['staff']=$this->User_model->selectstaff($this->companyid);
		$this->load->view('Admin_view/dailyreport', $data); 

	}else{
		redirect(base_url());
	}
}

public function dailyReportBystaff()  {
	 if($this->session->userdata('UserLoginSession'))
    {
			
			//$companyid = '2' ;
			$this->load->model('User_model'); 
	   if($_SERVER['REQUEST_METHOD']=='POST')
    	{   
    	    
    	    	 $staff = $this->input->post('staff');
				 $dates = $this->input->post('dates');
				 $date = new DateTime($dates);
    			$newdate =  $date->format('"Y/m/d"'); 
				 $data['report']=$this->User_model->selectstaffWork($staff,$newdate); 
    	    	
    	    	 	
		}
	        	 
	        	  
		}
    	     
         
        
    	 
    	
    	 
      
         
        $data['staff']=$this->User_model->selectstaff($this->companyid); 
         $this->load->view('Admin_view/dailyreport', $data); 
	} 
	public function MonthlyReport(){
		$data=array();
		$menu = explode('::',__METHOD__);
		$data['active']=trim($menu[1]);
		if($this->session->userdata('UserLoginSession')){
			
			$data['staff']=$this->User_model->selectstaff($this->companyid);
			$this->load->view('Admin_view/monthlyReport', $data); 
	
		}else{
			redirect(base_url());
		}
	}
	public function monthReportBystaff()  {
		if($this->session->userdata('UserLoginSession'))
	   {
			   
			   //$companyid = '2' ;
			   $this->load->model('User_model'); 
		  if($_SERVER['REQUEST_METHOD']=='POST')
		   {   
			   
					$staff = $this->input->post('staff');
					$datesFrom = $this->input->post('dates1');
					$datesTo = $this->input->post('dates2');
					$dateF = new DateTime($datesFrom);
				   $newdateFrom =  $dateF->format('"Y/m/d"'); 
					$dateT = new DateTime($datesTo);
				   $newdateTo =  $dateT->format('"Y/m/d"');
				   
					$data['report']=$this->User_model->selectstaffWorkMonthly($staff,$newdateFrom,$newdateTo); 
				   
						
		   }
					
					 
		   }
				
			
		   
			
		   
			
		 
			
		   $data['staff']=$this->User_model->selectstaff($this->companyid); 
			$this->load->view('Admin_view/monthlyReport', $data); 
	   } 


	   public function getdailyreport(){
		$draw = intval($this->input->get("draw"));
        $start = intval($this->input->get("start"));
      	$length = intval($this->input->get("length"));
		$data = [];
		$staff = $this->input->post('staff');
		$dates = $this->input->post('dates');
		$date = new DateTime($dates);
		$newdate =  $date->format('"Y/m/d"'); 
		$report=$this->User_model->selectstaffWork($staff,$newdate); 
		foreach ($report  as $row)  
        {   
    
							$d1=new DateTime();
							$d2 = date_create($row->date);
							$row->diff=date_diff($d2,$d1);
							$row->d=(int)$row->diff->format("%R%a");
							 
							 
								 
							 $staff =  $row->staff." ".($row->staffid!=0)?$row->username.'(Engineer Id:'.$row->staffid.')':"";
							 if(($row->status)==0){
								$status ='<p style="color:red"> Open </p>';
							 }else if(($row->status)==1){
								$status ='<p style="color:#a63d05"> Working </p>';
							 }else if(($row->status)==2){
								$status ='<p style="color:#bf762c"> Temporarly Closed </p>';
							 }else if(($row->status)==3){
								$status ='<p style="color:green"> Closed </p>';
							 }
							if(($row->status==3)||($row->status==2)){ 
								 $status1 = '<p><a href="'.base_url('Superadmin/viewbillNew/'.$row->id).'" type="link" class="link" >View More</a></p>'; 
							} 
							if(($row->assign_status)==0){
								$assign_status ='<p style="color:red"> Unassigned </p>';
							 }
							 else if(($row->assign_status)==1){
								$assign_status ='<p style="color:green"> Assigned </p>';
							 } 
							 $data[] = array(
							$row->id,
							"Due Time:".$row->date.' '.$row->time,
							$row->customername,
							$row->phone,
							$row->item,
							$staff,
							 $status,
							 $status1,
							 $assign_status
						);
                      
                        }  
						$result1 = array(
							"draw" => $draw,
							  "recordsTotal" => count($h),
							  "recordsFiltered" => count($h),
							  "data" => $data
						 );   

   echo json_encode($result1);
   exit();
	
	   }
	   
}



