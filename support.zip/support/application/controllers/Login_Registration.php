<?php
defined('BASEPATH') || exit('No direct script access allowed');

class Login_Registration extends CI_Controller {
    public function __construct()
	{
		parent::__construct();
		$this->load->model('User_model');
		$customer;
	}
    public function index()
	{ $this->session->set_flashdata('success','');
		$this->load->view('Login_Registration_view/home');
	}
    public function nextpage()
	{ $this->session->set_flashdata('success','');
		$this->load->view('Login_Registration_view/register');
	}

	function registerNow()
{	

	if($_SERVER['REQUEST_METHOD']=='POST')
	{
		
		$dd = $_POST;
		$email = $this->input->post('email');
				$this->load->model('User_model');
				$status = $this->User_model->checkEmail($email);
				if($status!=false)
				{
					
					$this->session->set_flashdata('emailerror','Company already registered');

					redirect(base_url('Login_Registration/index'));
				}
				else
				{
					$this->session->set_flashdata('emailerror','');
					$this->session->set_flashdata('success','');
				}
		
		if ($dd['password_1'] !== $dd['password_2']) {
			$this->session->set_flashdata('error1','password doesnot match');
			redirect(base_url('Login_Registration/index'));
		}else{
			$this->session->set_flashdata('error1','');
		}
	
			$companyname = $this->input->post('companyname');
			$companymail = $this->input->post('companymail');
		
			$companynumber = $this->input->post('companynumber');
			$password = $this->input->post('password_1');
			$gst = $this->input->post('gst');
			$location = $this->input->post('location');
			$district = $this->input->post('district');
			$state = $this->input->post('state');
			$country = $this->input->post('country');
			$pincode = $this->input->post('pincode');

			$data = array(
				'companyname'=>$companyname,
				'companymail'=>$companymail,
				'companynumber'=>$companynumber,
				'password'=>$password,
				'gst'=>$gst,
				'location'=>$location,
				'district'=>$district,
				'state'=>$state,
				'country'=>$country,
				'pincode'=>$pincode,
				'role'=>'Company',
				'status'=>'0'
			);

			$this->load->model('User_model');
			$this->User_model->insertcompany($data);
			$this->session->set_flashdata('success','Company Registered and Send for Apporval');
			redirect(base_url('Login_Registration/register'));
		
	}
}
function register()
{
	$this->load->view('Login_Registration_view/home');
}

function about()
{
    
     $this->load->model('User_model');
 $data['image3'] = $this->User_model->getImage3();

$data['c'] = $this->User_model->gettxt3();

	$this->load->view('about',$data);
}



function blog()
{
	$this->load->view('blog');
}



function contact()
{
	$this->load->view('contact');
}


function product()
{
    
      $this->load->model('User_model');
 $data['image5'] = $this->User_model->getImage5();

$data['e'] = $this->User_model->gettxt5();
   $data['p'] = $this->User_model->getproducts();
	$this->load->view('product',$data);
}
	
	function login()
	{
		$this->load->view('login');
	}
	function loginclear()
	{   $this->session->set_flashdata('statuserror','');	
		$this->session->set_flashdata('error','');	
		$this->session->set_flashdata('error1','');	
		$this->load->view('Login_Registration_view/login');
	}

	function loginnow()
	{  $this->session->set_flashdata('statuserror','');
	
		if($_SERVER['REQUEST_METHOD']=='POST')
		{
			$this->form_validation->set_rules('email','Email','required');
			$this->form_validation->set_rules('password_1','Password','required');

			if($this->form_validation->run()==TRUE)
			{
				$email = $this->input->post('email');
				$password_1 = $this->input->post('password_1');

				$this->load->model('User_model');
				$status = $this->User_model->checkPassword($password_1,$email);
				if($status!=false)
				{  
				    $userid=$status->id;
					$username = $status->username;
					$email = $status->email;
					$role=$status->role;
					$profile_img=$status->profile_img;
					$companyname=$status->companyname;
					$companyid=$status->companyid;
					$phone=$status->phone;
						$address=$status->address;
					$session_data = array(
                        'userid'=>$userid,
						'username'=>$username,
						'email' => $email,
						'phone' => $phone,
						'address' => $address,
						'profile'=> $profile_img,
						'companyname' => $companyname,
						'companyid' => $companyid,
						'chatflag' =>1,
						'role'=>$role
					);
				
					$this->session->set_userdata('UserLoginSession',$session_data);
					
					if($role=="Staff"){
						redirect(base_url('Staff/ticketview'));	
					}
					if($role=="Super Admin"){
						redirect(base_url('Superadmin/ticketview'));	
					}
						if($role=="Customer"){
						redirect(base_url('Customer/homepage'));	
					}

				}
				else
				{
				    $status1 = $this->User_model->checkcompany($password_1,$email);
					if($status1!=false)
				{  
					$username = $status1->companyname;
					$email = $status1->companymail;
					$role=$status1->role;
					$companyname=$status1->companyname;
					$companyid=$status1->companyid;
					
					$session_data = array(

						'username'=>$username,
						'email' => $email,
						'companyname' => $companyname,
						'companyid' => $companyid,
						'chatflag' =>1,
						'role'=>$role
					);
				
					$this->session->set_userdata('UserLoginSession',$session_data);
					    if($status1->status==1){ 
					redirect(base_url('Admin/ticketview'));
					    }
					    else{
					        $this->session->set_flashdata('statuserror','Waiting for Approval');
					redirect(base_url('indexpage#login'));
					    }

				}
				else
				{
				   
					$this->session->set_flashdata('error','Email or Password is Wrong or Login Restricted');
					redirect(base_url('Login_Registration/login'));
				}
				}

			}
			else
			{
				$this->session->set_flashdata('error','Fill all the required fields');
				redirect(base_url('indexpage#login'));
			}
		}
	}
	
	
		function staffregister()
{	

	if($_SERVER['REQUEST_METHOD']=='POST')
	{
		
		$dd = $_POST;
		$email = $this->input->post('email');
				$this->load->model('User_model');
				$status = $this->User_model->checkEmail($email);
				if($status!=false)
				{
					
					$this->session->set_flashdata('staffemailerror','Email already exist');

					redirect(base_url('Admin/registerstaff'));
				}
				else
				{
					$this->session->set_flashdata('staffemailerror','');
					$this->session->set_flashdata('staffsuccess','');
				}
		
		if ($dd['password_1'] !== $dd['password_2']) {
			$this->session->set_flashdata('stafferror1','password doesnot match');
			redirect(base_url('Admin/registerstaff'));
		}else{
			$this->session->set_flashdata('error1','');
		}
	       $image1=NULL;$image2=NULL;
            $companyid='2';
            $companyname='test_company2' ;
			$username = $this->input->post('username');
			$email = $this->input->post('email');
			$cemail = $this->input->post('cemail');
			$phone = $this->input->post('phone');
			$designation = $this->input->post('designation');
			$password_1 = $this->input->post('password_1');
			$referalid = $this->input->post('referalid');
			$pincode = $this->input->post('pincode');
			$address= $this->input->post('address');
                  if(!empty($_FILES['image']['name'])){  
       
                $config['upload_path'] = 'images/Staff/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|';
                $config['file_name'] = $_FILES['image']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image')){ 
                    $flag1=1;
                    $uploadData = $this->upload->data();
                    $image1 = $uploadData['file_name'];
         
                }else{
                    $flag1=0;
                  $this->session->set_flashdata('stafffail',' Staff Registration Failed ');
			redirect(base_url('Admin/registerstaff'));  
                }
            }
				
			 if(!empty($_FILES['imge']['name'])){  
       
                $config['upload_path'] = 'images/Staff/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|';
                $config['file_name'] = $_FILES['imge']['name'];
             
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('imge')){
                    $uploadData = $this->upload->data();
                    $image2 = $uploadData['file_name'];
                    $flag2=1;
                }else{ $flag2=0;
                  $this->session->set_flashdata('stafffail',' Staff Registration Failed ');
			redirect(base_url('Admin/registerstaff'));  
                }
               
         
		
                    
                
            }
			$data = array(
				'username'=>$username,
				'companyid'=>$companyid,
				'companyname'=>$companyname,
				'designation'=>$designation,
				'email'=>$email,
				'cemail'=>$cemail,
				'phone'=>$phone,
				'address'=>$address,
				'password_1'=>$password_1,
				'profile_img'=>$image1,
				'id_proof'=>$image2,
				'referalid'=>$referalid,
				'pincode'=>$pincode,
				'status'=>'1',
				'role'=>'Staff'
			);
			$this->load->model('User_model');
			$this->User_model->insertuser($data,$phone);
			$this->session->set_flashdata('staffsuccess',' Staff Registered Successfully ');   
	redirect(base_url('Admin/registerstaff'));
		
		
	}
}

function dealerregister()
{	

	if($_SERVER['REQUEST_METHOD']=='POST')
	{
		
		$dd = $_POST;
		$email = $this->input->post('email');
				$this->load->model('User_model');
				$status = $this->User_model->checkDealerEmail($email);
				if($status!=false)
				{
					
					$this->session->set_flashdata('staffemailerror','Email already exist');

					redirect(base_url('Admin/dealerstaff'));
				}
				else
				{
					$this->session->set_flashdata('staffemailerror','');
					$this->session->set_flashdata('staffsuccess','');
				}
		
		if ($dd['password_1'] !== $dd['password_2']) {
			$this->session->set_flashdata('stafferror1','password doesnot match');
			redirect(base_url('Admin/dealerstaff'));
		}else{
			$this->session->set_flashdata('error1','');
		}
	       $image1=NULL;$image2=NULL;
            $companyid='2';
            $companyname='test_company2' ;
			$username = $this->input->post('username');
			$email = $this->input->post('email');
			$cemail = $this->input->post('cemail');
			$phone = $this->input->post('phone');
			$designation = $this->input->post('designation');
			$password_1 = $this->input->post('password_1');
			$referalid = $this->input->post('referalid');
			$pincode = $this->input->post('pincode');
			$address= $this->input->post('address');
                  if(!empty($_FILES['image']['name'])){  
       
                $config['upload_path'] = 'images/Staff/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|';
                $config['file_name'] = $_FILES['image']['name'];
              
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image')){ 
                    $flag1=1;
                    $uploadData = $this->upload->data();
                    $image1 = $uploadData['file_name'];
         
                }else{
                    $flag1=0;
                  $this->session->set_flashdata('stafffail',' Dealer Registration Failed ');
			redirect(base_url('Admin/dealerstaff'));  
                }
            }
				
			 if(!empty($_FILES['imge']['name'])){  
       
                $config['upload_path'] = 'images/Staff/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|';
                $config['file_name'] = $_FILES['imge']['name'];
             
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('imge')){
                    $uploadData = $this->upload->data();
                    $image2 = $uploadData['file_name'];
                    $flag2=1;
                }else{ $flag2=0;
                  $this->session->set_flashdata('stafffail',' Dealer Registration Failed ');
			redirect(base_url('Admin/dealerstaff'));  
                }
               
         
		
                    
                
            }
			$data = array(
				'username'=>$username,
				'companyid'=>$companyid,
				'companyname'=>$companyname,
				'designation'=>$designation,
				'email'=>$email,
				'cemail'=>$cemail,
				'phone'=>$phone,
				'address'=>$address,
				'password_1'=>$password_1,
				'profile_img'=>$image1,
				'id_proof'=>$image2,
				'referalid'=>$referalid,
				'pincode'=>$pincode,
				'status'=>'1',
				'role'=>'Staff'
			);
			$this->load->model('User_model');
			$this->User_model->insertdealer($data,$phone);
			$this->session->set_flashdata('staffsuccess',' Dealer Registered Successfully ');   
	redirect(base_url('Admin/dealerstaff'));
		
		
	}
}

	function userregister()
{	

	if($_SERVER['REQUEST_METHOD']=='POST')
	{
		
		$dd = $_POST;
		$email = $this->input->post('email');
				$this->load->model('User_model');
				$status = $this->User_model->checkEmail($email);
				if($status!=false)
				{
					
					$this->session->set_flashdata('useremailerror','Email already exist');

					redirect(base_url('Staff/registeruser'));
				}
				else
				{
					$this->session->set_flashdata('useremailerror','');
					$this->session->set_flashdata('usersuccess','');
				}
		
		if ($dd['password_1'] !== $dd['password_2']) {
			$this->session->set_flashdata('usererror1','password doesnot match');
			redirect(base_url('Staff/registeruser'));
		}else{
			$this->session->set_flashdata('error1','');
		}
	        $companyid='2';
            $companyname='test_company2' ;
			$username = $this->input->post('username');
			$email = $this->input->post('email');
			$cemail = $this->input->post('cemail');
			$phone = $this->input->post('phone');
			$password_1 = $this->input->post('password_1');
			$referalid = $this->input->post('referalid');
			$pincode = $this->input->post('pincode');
            $designation ="Customer";
            
            $udata = $this->session->userdata('UserLoginSession');
            $usrid=$udata['userid'] ;
			$data = array(
				'username'=>$username,
				'companyid'=>$companyid,
				'companyname'=>$companyname,
				'designation'=>$designation,
				'email'=>$email,
				'cemail'=>$cemail,
				'phone'=>$phone,
				'password_1'=>$password_1,
				'profile_img'=>NULL,
				'referalid'=>$referalid,
				'pincode'=>$pincode,
				'status'=>'1',
				'role'=>'Customer',
				'adusr'=>$usrid
			);

			$this->load->model('User_model');
			$this->User_model->insertuser($data,$phone);
			$this->session->set_flashdata('usersuccess',' Customer Registration Successful ');
			redirect(base_url('Staff/registeruser'));
		
	}
}

	function userregistration()
{	

	if($_SERVER['REQUEST_METHOD']=='POST')
	{
		
		$dd = $_POST;
		$email = $this->input->post('email');
				$this->load->model('User_model');
				$status = $this->User_model->checkEmail($email);
				if($status!=false)
				{
					
					$this->session->set_flashdata('useremailerror','Email already exist');

					redirect(base_url('Staff/registeruser'));
				}
				else
				{
					$this->session->set_flashdata('useremailerror','');
					$this->session->set_flashdata('usersuccess','');
				}
		
		if ($dd['password_1'] !== $dd['password_2']) {
			$this->session->set_flashdata('usererror1','password doesnot match');
			redirect(base_url('Staff/registeruser'));
		}else{
			$this->session->set_flashdata('error1','');
		}
	        $udata = $this->session->userdata('UserLoginSession');
            $companyid='2' ;
            $companyname='test_company2' ;
			$username = $this->input->post('username');
			$email =$this->input->post('email');
			$cemail = $email;
			$phone = $this->input->post('phone');
			$password_1 = $this->input->post('password_1');
			$referalid = $this->input->post('referalid');
			$pincode = $this->input->post('pincode');
            $designation ="Customer";
            $address = $this->input->post('address');
			$data = array(
				'username'=>$username,
				'companyid'=>$companyid,
				'companyname'=>$companyname,
				'designation'=>$designation,
				'email'=>$email,
				'cemail'=>$cemail,
				'phone'=>$phone,
				
				'password_1'=>$password_1,
					'profile_img'=>NULL,
				'referalid'=>$referalid,
				'pincode'=>$pincode,
				'status'=>'1',
				'address'=>$address,
				'role'=>'Customer'
			);

			$this->load->model('User_model');
			$this->User_model->insertuser($data,$phone);
			$this->session->set_flashdata('usersuccess',' Customer Registration Successful ');
			redirect(base_url('indexpage'));
		
	}
}
    function logout()
	{
		session_destroy();
		redirect(base_url('indexpage'));
	}


}