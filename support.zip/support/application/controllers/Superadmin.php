<?php
defined('BASEPATH') || exit('No direct script access allowed');

class Superadmin extends CI_Controller {
 public function __construct()
	{
		parent::__construct();
		$this->load->model('User_model');
		$customer;
	}
	public function index()
	{ $this->session->set_flashdata('success','');
	
		$this->load->view('Login_Registration/home');
	}

	public function nextpage()
	{ $this->session->set_flashdata('success','');
		$this->session->set_flashdata('emailerror','');
		$this->load->view('Login_Registration/home');
	}

	


function logout()
	{
		session_destroy();
		//redirect(base_url('indexpage#login'));
		redirect('https://oriontechnologies.co.in/');
	}
	public function ticketview()  
	{  
	  
         $this->load->model('User_model');  
         //load the method of model  
         $data['h']=$this->User_model->select();  
         //return the data in view  
         $this->load->view('Superadmin_view/tickets', $data); 
	} 
		public function adminapproval()  
	{  
        
         if($_SERVER['REQUEST_METHOD']=='POST')
    	{
    	    	$companyid = $this->input->post('company');
    	    	 $this->load->model('User_model');  
         
         $this->User_model->changestatus($companyid);  
    	}
    	 $this->load->model('User_model');  
        
         $data['h']=$this->User_model->pending();  
         
         $this->load->view('Superadmin_view/adminapproval', $data); 
	} 
	function myticketview()
	{
		$this->load->model('User_model');  
		//load the method of model  
		$data['h']=$this->User_model->select();  
		//return the data in view  
		$this->load->view('Superadmin_view/myticket', $data); 
	}
	function viewmyoverduetickets()
	{
		$this->load->model('User_model');  
		//load the method of model  
		$data['h']=$this->User_model->select();  
		//return the data in view  
		$this->load->view('Superadmin_view/myoverdue', $data); 
	}
	function viewmyduetoday()
	{	$this->load->model('User_model');  
		//load the method of model  
		$data['h']=$this->User_model->select();  
		//return the data in view  
		$this->load->view('Superadmin_view/myduetoday', $data); 
	}
	function viewmypending()
	{	$this->load->model('User_model');  
		//load the method of model  
		$data['h']=$this->User_model->select();  
		//return the data in view  
		$this->load->view('Superadmin_view/mypending', $data); 
	
	}
	function viewopentickets()
	{	$this->load->model('User_model');  
		//load the method of model  
		$data['h']=$this->User_model->select();  
		//return the data in view  
		$this->load->view('Superadmin_view/opentickets', $data); 

	}
	function viewoverduetickets()
	{$this->load->model('User_model');  
		//load the method of model  
		$data['h']=$this->User_model->select();  
		//return the data in view  
		$this->load->view('Superadmin_view/overduetickets', $data); 
	}
	function viewunassigned()
	{	$this->load->model('User_model');  
		//load the method of model  
		$data['h']=$this->User_model->select();  
		//return the data in view  
		$this->load->view('Superadmin_view/unassigned', $data); 

	}
	function viewunanswered()
	{	$this->load->model('User_model');  
		//load the method of model  
		$data['h']=$this->User_model->select();  
		//return the data in view  
		$this->load->view('Superadmin_view/unanswered', $data); 
	}
		function viewallcompany()
	{	$this->load->model('User_model');  
		//load the method of model  
		$data['h']=$this->User_model->viewallcompany();  
		//return the data in view  
		$this->load->view('Superadmin_view/viewallcompany', $data); 
	}
	function userrecords(){
	    $data['d']=$this->User_model->getdistinct();
	    $data['t']=$this->User_model->gettickets();
	    $this->load->view('Superadmin_view/userrecords', $data); 
	}
	function usertickets($phone){
	     $data['d']=$this->User_model->getticks($phone);
	     $this->load->view('Superadmin_view/userticks', $data); 
	}
	function registercomplaint(){
	     	if($_SERVER['REQUEST_METHOD']=='POST')
	{
   
    
     date_default_timezone_set('Asia/Kolkata');
            $companyname='test_company2';
            $companyid='2';
		
			$name= $this->input->post('name');
			$email =  $this->input->post('email');
			$phone =  $this->input->post('phone');
			$address =  $this->input->post('address');
			$item =  $this->input->post('item');
			$model =  $this->input->post('model');
			$brand =  $this->input->post('brand');
			$prodetail =  $this->input->post('prodetail');
			$comdetail =  $this->input->post('comdetail');
			$remark =  $this->input->post('remark');
				$date=date("Y/m/d");
			$time=date("H:i:s");
$companyid='2' ;
            $companyname='test_company2' ;
		
		
			$cemail = $email;
		
			$password_1 = 'password';
			$referalid = '-';
			$pincode = '-';
            $designation ="Customer";
           
			$userdata = array(
				'username'=>$name,
				'companyid'=>$companyid,
				'companyname'=>$companyname,
				'designation'=>$designation,
				'email'=>$email,
				'cemail'=>$cemail,
				'phone'=>$phone,
				
				'password_1'=>$password_1,
					'profile_img'=>NULL,
				'referalid'=>$referalid,
				'pincode'=>$pincode,
				'status'=>'1',
				'address'=>$address,
				'role'=>'Customer'
			);

			$this->load->model('User_model');
			$this->User_model->insertuser($userdata,$phone);
		$status=	$this->User_model->getbyphone($phone);
		$data1 = array(
			    'companyname'=>$companyname,
			    'companyid'=>$companyid,
			    'customername'=>$name,
				'customerid'=>$status->id,
				
				'email'=>$email,
				'phone'=>$phone,
				'address'=>$address,
				'item'=>$item,
				'model'=>$model,
				'brand'=>$brand,
				'prodetail'=>$prodetail,
				'rqr'=>$comdetail,
				'remark'=>$remark,
				'status'=>'0',
				'date'=>$date,
				'time'=>$time,
				'view_status'=>'0',
				'staffid'=>'0',
				'staff'=>'-',
				'assign_status'=>'0',
			);

			$this->load->model('User_model');
			$this->User_model->registerticket($data1);
			$this->session->set_flashdata('ticketsuccess','Complaint has been Registered.');
		$data['flag']=1;
			$data['tick']=	$this->User_model->getticketid($phone,$status->id);
		$this->load->view('Superadmin_view/complaint',$data);   

	
		
	
		
	}
	else{
	    	$data['flag']=0;
	    	$this->session->set_flashdata('ticketsuccess','');
         $this->load->view('Superadmin_view/complaint',$data); 
	} 
	}
		function resolvedtickets(){
		$data=array();
		$menu = explode('::',__METHOD__);
		$data['active']=trim($menu[1]);

	   	$data['h']=$this->User_model->resolved();  
	
		$this->load->view('Superadmin_view/resolved', $data);  
	}
		function viewbill($id){
	 	$data['tick']=$this->User_model->getbill($id);  
	    $data['flag']=1;
		$this->load->view('Superadmin_view/bill', $data);     
	}
		function viewbill1($id){
	 	$data['tick']=$this->User_model->getbill($id);  
	    $data['flag']=2;
		$this->load->view('Superadmin_view/bill', $data);     
	}
	function viewUbill1($id){
	 	$data['tick']=$this->User_model->getbill($id);  
	    $data['flag']=2;
		$this->load->view('Superadmin_view/billu', $data);     
	}
	
	function editComplaint($eid){
	    $data['tick']=$this->User_model->getticketWidNew($eid);  
	    
		$this->load->view('Superadmin_view/complaintedit', $data);   
	}
	
	function editedComplaintUpdt(){
	    if($_SERVER['REQUEST_METHOD']=='POST'){
   
            $cid= $this->input->post('cid');
            $cusid= $this->input->post('cusid');
   
			$name= $this->input->post('name');
			$email =  $this->input->post('email');
			$phone =  $this->input->post('phone');
			$address =  $this->input->post('address');
			$item =  $this->input->post('item');
			$model =  $this->input->post('model');
			$brand =  $this->input->post('brand');
			$prodetail =  $this->input->post('prodetail');
			$comdetail =  $this->input->post('comdetail');
			$remark =  $this->input->post('remark');
			$orgname =  $this->input->post('orgname');
		$data1 = array(
			    'customername'=>$name,
				'customerid'=>$cusid,
				'orgname'=>$orgname,
				'email'=>$email,
				'phone'=>$phone,
				'address'=>$address,
				'item'=>$item,
				'model'=>$model,
				'brand'=>$brand,
				'prodetail'=>$prodetail,
				'rqr'=>$comdetail,
				'remark'=>$remark
			);

			$this->load->model('User_model');
			$this->User_model->updateTicket($data1,$cid);
			$this->session->set_flashdata('ticketsuccess','Complaint updated success.');
		    redirect(base_url('Admin/allticketview'));
		
	}
	else{
	    	$data['flag']=0;
	    	$this->session->set_flashdata('ticketsuccess','');
         redirect(base_url('Admin/allticketview'));
	}
	}
	function viewbillNew($id){
		$data['tick']=$this->User_model->getbill($id);  
	   $data['flag']=3;
	   $this->load->view('Superadmin_view/bill', $data);     
   }
	function viewbillNewM($id){
		$data['tick']=$this->User_model->getbill($id);  
	   $data['flag']=4;
	   $this->load->view('Superadmin_view/bill', $data);     
   }function changePassword(){
	
	$data = array(); 
	if($this->input->post()){
		$username = $this->input->post('email');
		$password = $this->input->post('pwd');
		$npwd = $this->input->post('npwd');
		$cnpwd = $this->input->post('cnpwd');
		$userdata =  $this->session->userdata('UserLoginSession') ;
		$usr_id = $userdata['userid'];
		$result= $this->User_model->getpassword($usr_id,$password);
		if($result == null){
			$this->session->set_flashdata('usererror2','Current password is incorrect');
		}
		else{
			if($npwd != $cnpwd){
				$this->session->set_flashdata('usererror2','Both new passwords are not same');
			}else{
				$result = $this->User_model->updateUser(array('password_1'=>$npwd),array('id'=>$usr_id));
				if($result){
					$this->session->set_flashdata('ticketsuccess','Password successfully changed');
				}
			}
		}
		unset($this->input->post);
	}
	   $this->load->view('Superadmin_view/changepassword_view', $data);     
   }
   public function listitem(){
	$data=array();
	$menu = explode('::',__METHOD__);
	$data['active']=trim($menu[1]);
	if($this->session->userdata('UserLoginSession')){
		 
	
		$this->load->view('Superadmin_view/listitem', $data); 

	}else{
		redirect(base_url());
	}
}
public function getitemlist(){
	$draw = intval($this->input->get("draw"));
	$start = intval($this->input->get("start"));
	  $length = intval($this->input->get("length"));
	$data = [];
	 
	$report=$this->User_model->getitemlist(); 
	$row_id=0;
	foreach ($report  as $row)  
	{   
		$row_id++;
		
						 if(($row->	itm_isactive)==0){
							$status ='<p style="color:red"> InActive </p>';
						 }else if(($row->itm_isactive)==1){
							$status ='<p style="color:green"> Active </p>';
						 }
						 $action ='<a href="'.base_url().'superadmin/editItem/'.$row->itm_id.'"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> </a>
						 &nbsp;&nbsp;&nbsp;<a style="cursor:pointer;" onclick="deleteItem(\''.$row->itm_id.'\');"><i class="fa fa-trash " style="color:red;" aria-hidden="true"></i> </a>';
						 $data[] = array(
						$row_id,
						$row->itm_name,
						$status,
						$action 
					);
				  
					}  
					$result1 = array(
						"draw" => $draw,
						  "recordsTotal" => count($report),
						  "recordsFiltered" => count($report),
						  "data" => $data
					 );   

echo json_encode($result1);
exit();

   }
   function addItem(){
	$this->session->set_flashdata('success','');
	$data = array(); 
	if($this->input->post()){
		$itm_name = $this->input->post('itm_name');
		 $array['itm_name'] =$itm_name;
		if($this->User_model->insertItem( $array,'item')){
			$this->session->set_flashdata('success','Successfully Insert');
		}else{
			$this->session->set_flashdata('usererror2','Error in Insert');
		}
		 
		unset($this->input->post);
		redirect("Superadmin/listitem");
	}
	   $this->load->view('Superadmin_view/addItem_view', $data);     
   }
    function editItem($itm_id){
		
		
	$this->session->set_flashdata('success','');
	$data = array(); 
	$data['result']=$this->User_model->getItem($itm_id);
	if($this->input->post()){
		$itm_name = $this->input->post('itm_name');
		$itm_id = $this->input->post('itm_id');
		 $array['itm_name'] =$itm_name;
		if($this->User_model->updateItem($array,array("itm_id"=>$itm_id),'item')){
			$this->session->set_flashdata('success','Successfully Insert');
		}else{
			$this->session->set_flashdata('usererror2','Error in Insert');
		}
		 
		unset($this->input->post);
		redirect("Superadmin/listitem");
	}
	   $this->load->view('Superadmin_view/editItem_view', $data);     
   } 
   function deleteItem(){
		$itm_id = $this->input->post('itm_id');
		if($this->User_model->deleteItem(array("itm_id"=>$itm_id),'item')){
			echo 1;
		}else{
			echo 0;
		}
   }
   public function listmodel(){
	$data=array();
	$menu = explode('::',__METHOD__);
	$data['active']=trim($menu[1]);
	if($this->session->userdata('UserLoginSession')){
		 
	
		$this->load->view('Superadmin_view/listmodel', $data); 

	}else{
		redirect(base_url());
	}
}
public function getitemmodel(){
	$draw = intval($this->input->get("draw"));
	$start = intval($this->input->get("start"));
	  $length = intval($this->input->get("length"));
	$data = [];
	 
	$report=$this->User_model->getModelList(); 
	$row_id=0;
	foreach ($report  as $row)  
	{   
		$row_id++;
		
						 if(($row->	mdl_isactive)==0){
							$status ='<p style="color:red"> InActive </p>';
						 }else if(($row->mdl_isactive)==1){
							$status ='<p style="color:green"> Active </p>';
						 }
						 $action ='<a href="'.base_url().'superadmin/editModel/'.$row->mdl_id.'"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> </a>
						 &nbsp;&nbsp;&nbsp;<a style="cursor:pointer;" onclick="deleteItem(\''.$row->mdl_id.'\');"><i class="fa fa-trash " style="color:red;" aria-hidden="true"></i> </a>';
						 $data[] = array(
						$row_id,
						$row->mdl_title,
						$row->itm_name,
						$status,
						$action 
					);
				  
					}  
					$result1 = array(
						"draw" => $draw,
						  "recordsTotal" => count($report),
						  "recordsFiltered" => count($report),
						  "data" => $data
					 );   

echo json_encode($result1);
exit();

   }
   function addModel(){
	$this->session->set_flashdata('success','');
	$data = array(); 
	$data["itemlist"]=$this->User_model->getitemlistAct();
	if($this->input->post()){
		$array['itm_id'] = $this->input->post('itm_name');
		$array['mdl_title'] = $this->input->post('mdl_title');
		if($this->User_model->insertItem( $array,'model')){
			$this->session->set_flashdata('success','Successfully Insert');
		}else{
			$this->session->set_flashdata('usererror2','Error in Insert');
		}
		 
		unset($this->input->post);
		redirect("Superadmin/listmodel");
	}
	   $this->load->view('Superadmin_view/addmodel_view', $data);     
   }
    function editModel($mdl_id){
		
		
	$this->session->set_flashdata('success','');
	$data = array(); 
	$data["itemlist"]=$this->User_model->getitemlistAct();
	$data['result']=$this->User_model->getmodel($mdl_id);
	if($this->input->post()){
		$array['itm_id'] = $this->input->post('itm_name');
		$array['mdl_title'] = $this->input->post('mdl_title');
		$mdl_id = $this->input->post('mdl_id');
		if($this->User_model->updateItem($array,array("mdl_id"=>$mdl_id),'model')){
			$this->session->set_flashdata('success','Successfully Insert');
		}else{
			$this->session->set_flashdata('usererror2','Error in Insert');
		}
		 
		unset($this->input->post);
		redirect("Superadmin/listmodel");
	}
	   $this->load->view('Superadmin_view/editmodel_view', $data);     
   } 
   function deleteModel(){
		$itm_id = $this->input->post('itm_id');
		if($this->User_model->deleteItem(array("mdl_id"=>$itm_id),'model')){
			echo 1;
		}else{
			echo 0;
		}
   }
   public function listbrand(){
	$data=array();
	$menu = explode('::',__METHOD__);
	$data['active']=trim($menu[1]);
	if($this->session->userdata('UserLoginSession')){
		 
	
		$this->load->view('Superadmin_view/listbrand', $data); 

	}else{
		redirect(base_url());
	}
}
public function getitembrand(){
	$draw = intval($this->input->get("draw"));
	$start = intval($this->input->get("start"));
	  $length = intval($this->input->get("length"));
	$data = [];
	 
	$report=$this->User_model->getbrands(); 
	$row_id=0;
	foreach ($report  as $row)  
	{   
		$row_id++;
		
						 if(($row->	bnd_isactive)==0){
							$status ='<p style="color:red"> InActive </p>';
						 }else if(($row->bnd_isactive)==1){
							$status ='<p style="color:green"> Active </p>';
						 }
						 $action ='<a href="'.base_url().'superadmin/editbrand/'.$row->bnd_id.'"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> </a>
						 &nbsp;&nbsp;&nbsp;<a style="cursor:pointer;" onclick="deleteItem(\''.$row->bnd_id.'\');"><i class="fa fa-trash " style="color:red;" aria-hidden="true"></i> </a>';
						 $data[] = array(
						$row_id,
						$row->mdl_title,
						$row->itm_name,
						$row->bnd_title,
						$status,
						$action 
					);
				  
					}  
					$result1 = array(
						"draw" => $draw,
						  "recordsTotal" => count($report),
						  "recordsFiltered" => count($report),
						  "data" => $data
					 );   

echo json_encode($result1);
exit();

   }
   function addbrand(){
	$this->session->set_flashdata('success','');
	$data = array(); 
	$data["itemlist"]=$this->User_model->getitemlistAct();
	$data["modellist"]=$this->User_model->getmodellistAct();
	if($this->input->post()){
		$array['itm_id'] = $this->input->post('itm_name');
		$array['mdl_id'] = $this->input->post('mdl_title');
		$array['bnd_title'] = $this->input->post('bnd_title');
		if($this->User_model->insertItem( $array,'brand')){
			$this->session->set_flashdata('success','Successfully Insert');
		}else{
			$this->session->set_flashdata('usererror2','Error in Insert');
		}
		 
		unset($this->input->post);
		redirect("Superadmin/listbrand");
	}
	   $this->load->view('Superadmin_view/addbrand_view', $data);     
   }
    function editbrand($bnd_id){
		
		
	$this->session->set_flashdata('success','');
	$data = array(); 
	$data["itemlist"]=$this->User_model->getitemlistAct();
	$data['result']=$this->User_model->getbrand($bnd_id);
	if($this->input->post()){
		$array['itm_id'] = $this->input->post('itm_name');
		$array['mdl_id'] = $this->input->post('mdl_title');
		$array['bnd_title'] = $this->input->post('bnd_title');
		$bnd_id = $this->input->post('bnd_id');
		if($this->User_model->updateItem($array,array("bnd_id"=>$bnd_id),'brand')){
			$this->session->set_flashdata('success','Successfully Insert');
		}else{
			$this->session->set_flashdata('usererror2','Error in Insert');
		}
		 
		unset($this->input->post);
		redirect("Superadmin/listbrand");
	}
	   $this->load->view('Superadmin_view/editbrand_view', $data);     
   } 
   function deletebrand(){
		$itm_id = $this->input->post('itm_id');
		if($this->User_model->deleteItem(array("bnd_id"=>$itm_id),'brand')){
			echo 1;
		}else{
			echo 0;
		}
   }
   function getModelsByItem(){
		$response =array();
		if($this->input->post()){
			$itm_id = $this->input->post('itm_id');
			$categories = $this->User_model->getModelbyitmId($itm_id);
			$arrayCat = array();
			if(count($categories)>0){
				foreach($categories as $cat){
				$arrayCat[$cat->mdl_id]=$cat->mdl_title;
			}
			}
			
			$response['data']= $arrayCat ;

		}
		echo  json_encode($response);	
   }
}



