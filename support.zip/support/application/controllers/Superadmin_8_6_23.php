<?php
defined('BASEPATH') || exit('No direct script access allowed');

class Superadmin extends CI_Controller {
 public function __construct()
	{
		parent::__construct();
		$this->load->model('User_model');
		$customer;
	}
	public function index()
	{ $this->session->set_flashdata('success','');
	
		$this->load->view('Login_Registration/home');
	}

	public function nextpage()
	{ $this->session->set_flashdata('success','');
		$this->session->set_flashdata('emailerror','');
		$this->load->view('Login_Registration/home');
	}

	


function logout()
	{
		session_destroy();
		//redirect(base_url('indexpage#login'));
		redirect('https://oriontechnologies.co.in/');
	}
	public function ticketview()  
	{  
	  
         $this->load->model('User_model');  
         //load the method of model  
         $data['h']=$this->User_model->select();  
         //return the data in view  
         $this->load->view('Superadmin_view/tickets', $data); 
	} 
		public function adminapproval()  
	{  
        
         if($_SERVER['REQUEST_METHOD']=='POST')
    	{
    	    	$companyid = $this->input->post('company');
    	    	 $this->load->model('User_model');  
         
         $this->User_model->changestatus($companyid);  
    	}
    	 $this->load->model('User_model');  
        
         $data['h']=$this->User_model->pending();  
         
         $this->load->view('Superadmin_view/adminapproval', $data); 
	} 
	function myticketview()
	{
		$this->load->model('User_model');  
		//load the method of model  
		$data['h']=$this->User_model->select();  
		//return the data in view  
		$this->load->view('Superadmin_view/myticket', $data); 
	}
	function viewmyoverduetickets()
	{
		$this->load->model('User_model');  
		//load the method of model  
		$data['h']=$this->User_model->select();  
		//return the data in view  
		$this->load->view('Superadmin_view/myoverdue', $data); 
	}
	function viewmyduetoday()
	{	$this->load->model('User_model');  
		//load the method of model  
		$data['h']=$this->User_model->select();  
		//return the data in view  
		$this->load->view('Superadmin_view/myduetoday', $data); 
	}
	function viewmypending()
	{	$this->load->model('User_model');  
		//load the method of model  
		$data['h']=$this->User_model->select();  
		//return the data in view  
		$this->load->view('Superadmin_view/mypending', $data); 
	
	}
	function viewopentickets()
	{	$this->load->model('User_model');  
		//load the method of model  
		$data['h']=$this->User_model->select();  
		//return the data in view  
		$this->load->view('Superadmin_view/opentickets', $data); 

	}
	function viewoverduetickets()
	{$this->load->model('User_model');  
		//load the method of model  
		$data['h']=$this->User_model->select();  
		//return the data in view  
		$this->load->view('Superadmin_view/overduetickets', $data); 
	}
	function viewunassigned()
	{	$this->load->model('User_model');  
		//load the method of model  
		$data['h']=$this->User_model->select();  
		//return the data in view  
		$this->load->view('Superadmin_view/unassigned', $data); 

	}
	function viewunanswered()
	{	$this->load->model('User_model');  
		//load the method of model  
		$data['h']=$this->User_model->select();  
		//return the data in view  
		$this->load->view('Superadmin_view/unanswered', $data); 
	}
		function viewallcompany()
	{	$this->load->model('User_model');  
		//load the method of model  
		$data['h']=$this->User_model->viewallcompany();  
		//return the data in view  
		$this->load->view('Superadmin_view/viewallcompany', $data); 
	}
	function userrecords(){
	    $data['d']=$this->User_model->getdistinct();
	    $data['t']=$this->User_model->gettickets();
	    $this->load->view('Superadmin_view/userrecords', $data); 
	}
	function usertickets($phone){
	     $data['d']=$this->User_model->getticks($phone);
	     $this->load->view('Superadmin_view/userticks', $data); 
	}
	function registercomplaint(){
	     	if($_SERVER['REQUEST_METHOD']=='POST')
	{
   
    
     date_default_timezone_set('Asia/Kolkata');
            $companyname='test_company2';
            $companyid='2';
		
			$name= $this->input->post('name');
			$email =  $this->input->post('email');
			$phone =  $this->input->post('phone');
			$address =  $this->input->post('address');
			$item =  $this->input->post('item');
			$model =  $this->input->post('model');
			$brand =  $this->input->post('brand');
			$prodetail =  $this->input->post('prodetail');
			$comdetail =  $this->input->post('comdetail');
			$remark =  $this->input->post('remark');
				$date=date("Y/m/d");
			$time=date("H:i:s");
$companyid='2' ;
            $companyname='test_company2' ;
		
		
			$cemail = $email;
		
			$password_1 = 'password';
			$referalid = '-';
			$pincode = '-';
            $designation ="Customer";
           
			$userdata = array(
				'username'=>$name,
				'companyid'=>$companyid,
				'companyname'=>$companyname,
				'designation'=>$designation,
				'email'=>$email,
				'cemail'=>$cemail,
				'phone'=>$phone,
				
				'password_1'=>$password_1,
					'profile_img'=>NULL,
				'referalid'=>$referalid,
				'pincode'=>$pincode,
				'status'=>'1',
				'address'=>$address,
				'role'=>'Customer'
			);

			$this->load->model('User_model');
			$this->User_model->insertuser($userdata,$phone);
		$status=	$this->User_model->getbyphone($phone);
		$data1 = array(
			    'companyname'=>$companyname,
			    'companyid'=>$companyid,
			    'customername'=>$name,
				'customerid'=>$status->id,
				
				'email'=>$email,
				'phone'=>$phone,
				'address'=>$address,
				'item'=>$item,
				'model'=>$model,
				'brand'=>$brand,
				'prodetail'=>$prodetail,
				'rqr'=>$comdetail,
				'remark'=>$remark,
				'status'=>'0',
				'date'=>$date,
				'time'=>$time,
				'view_status'=>'0',
				'staffid'=>'0',
				'staff'=>'-',
				'assign_status'=>'0',
			);

			$this->load->model('User_model');
			$this->User_model->registerticket($data1);
			$this->session->set_flashdata('ticketsuccess','Complaint has been Registered.');
		$data['flag']=1;
			$data['tick']=	$this->User_model->getticketid($phone,$status->id);
		$this->load->view('Superadmin_view/complaint',$data);   

	
		
	
		
	}
	else{
	    	$data['flag']=0;
	    	$this->session->set_flashdata('ticketsuccess','');
         $this->load->view('Superadmin_view/complaint',$data); 
	} 
	}
		function resolvedtickets(){
		$data=array();
		$menu = explode('::',__METHOD__);
		$data['active']=trim($menu[1]);

	   	$data['h']=$this->User_model->resolved();  
	
		$this->load->view('Superadmin_view/resolved', $data);  
	}
		function viewbill($id){
	 	$data['tick']=$this->User_model->getbill($id);  
	    $data['flag']=1;
		$this->load->view('Superadmin_view/bill', $data);     
	}
		function viewbill1($id){
	 	$data['tick']=$this->User_model->getbill($id);  
	    $data['flag']=2;
		$this->load->view('Superadmin_view/bill', $data);     
	}
	function viewUbill1($id){
	 	$data['tick']=$this->User_model->getbill($id);  
	    $data['flag']=2;
		$this->load->view('Superadmin_view/billu', $data);     
	}
	
	function editComplaint($eid){
	    $data['tick']=$this->User_model->getticketWidNew($eid);  
	    
		$this->load->view('Superadmin_view/complaintedit', $data);   
	}
	
	function editedComplaintUpdt(){
	    if($_SERVER['REQUEST_METHOD']=='POST'){
   
            $cid= $this->input->post('cid');
            $cusid= $this->input->post('cusid');
   
			$name= $this->input->post('name');
			$email =  $this->input->post('email');
			$phone =  $this->input->post('phone');
			$address =  $this->input->post('address');
			$item =  $this->input->post('item');
			$model =  $this->input->post('model');
			$brand =  $this->input->post('brand');
			$prodetail =  $this->input->post('prodetail');
			$comdetail =  $this->input->post('comdetail');
			$remark =  $this->input->post('remark');
			$orgname =  $this->input->post('orgname');
		$data1 = array(
			    'customername'=>$name,
				'customerid'=>$cusid,
				'orgname'=>$orgname,
				'email'=>$email,
				'phone'=>$phone,
				'address'=>$address,
				'item'=>$item,
				'model'=>$model,
				'brand'=>$brand,
				'prodetail'=>$prodetail,
				'rqr'=>$comdetail,
				'remark'=>$remark
			);

			$this->load->model('User_model');
			$this->User_model->updateTicket($data1,$cid);
			$this->session->set_flashdata('ticketsuccess','Complaint updated success.');
		    redirect(base_url('Admin/allticketview'));
		
	}
	else{
	    	$data['flag']=0;
	    	$this->session->set_flashdata('ticketsuccess','');
         redirect(base_url('Admin/allticketview'));
	}
	}
	function viewbillNew($id){
		$data['tick']=$this->User_model->getbill($id);  
	   $data['flag']=3;
	   $this->load->view('Superadmin_view/bill', $data);     
   }
	function viewbillNewM($id){
		$data['tick']=$this->User_model->getbill($id);  
	   $data['flag']=4;
	   $this->load->view('Superadmin_view/bill', $data);     
   }function changePassword(){
	
	$data = array(); 
	if($this->input->post()){
		$username = $this->input->post('email');
		$password = $this->input->post('pwd');
		$npwd = $this->input->post('npwd');
		$cnpwd = $this->input->post('cnpwd');
		$userdata =  $this->session->userdata('UserLoginSession') ;
		$usr_id = $userdata['userid'];
		$result= $this->User_model->getpassword($usr_id,$password);
		if($result == null){
			$this->session->set_flashdata('usererror2','Current password is incorrect');
		}
		else{
			if($npwd != $cnpwd){
				$this->session->set_flashdata('usererror2','Both new passwords are not same');
			}else{
				$result = $this->User_model->updateUser(array('password_1'=>$npwd),array('id'=>$usr_id));
				if($result){
					$this->session->set_flashdata('ticketsuccess','Password successfully changed');
				}
			}
		}
		unset($this->input->post);
	}
	   $this->load->view('Superadmin_view/changepassword_view', $data);     
   }
}



