<?php defined('BASEPATH') OR exit('No direct script access allowed');
class members extends CI_Controller
{
    function  __construct() {
        parent::__construct();
        $this->load->model('Member');
        $udata = $this->session->userdata('UserLoginSession');
    }
    
    function add(){
        if($this->input->post('membersubmit')){
            
            //Check whether Member upload profile_img
            if(!empty($_FILES['profile_img']['name'])){
                $config['upload_path'] = 'uploads/images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif';
                $config['file_name'] = $_FILES['profile_img']['name'];
                
                //Load upload library and initialize here configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('profile_img')){
                    $uploadData = $this->upload->data();
                    $profile_img = $uploadData['file_name'];
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->session->set_flashdata('success_msg', NULL);
                    $profile_img = '';
                    redirect(base_url('members/displayimage'));
                }
            }else{
                $profile_img = '';
            }
            
         
                
                $email=$udata['email'] ;
      
       
            
            //Pass Member data to model
            $insertMemberData = $this->Member->insert($email,$profile_img);
            
            //Storing insertion status message.
            if($insertMemberData){
                $this->session->set_flashdata('success_msg', 'Image updated successfully.');
            }else{
                $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
            }
        }
        //Form for adding Member data
        $data['image'] = $this->Member->getImage($email);
        $this->session->set_flashdata('error_msg', NULL);
            $this->session->set_flashdata('proimg', '$image');
            $this->load->view('add',$data);
    }
    function displayimage(){
        var_dump("hi");die;
             $email=$udata['email'] ;
            $data['image'] = $this->Member->getImage($email);
            $this->session->set_flashdata('proimg', '$image');
            $this->load->view('add',$data);
          
               }
}