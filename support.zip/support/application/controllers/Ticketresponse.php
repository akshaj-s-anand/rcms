<?php
defined('BASEPATH') || exit('No direct script access allowed');

class Ticketresponse extends CI_Controller {
	 public function __construct()
	{
		parent::__construct();
		$this->load->model('User_model');
	
	}


function opencomp($id){

	    	$data['tick'] = $this->User_model->getticket($id);
	    		$data['mess'] = $this->User_model->getresponse($id);
	    		$data['ticketid']=$id;
	    	  $this->load->view('Staff_view/complaint',$data);
}
function changeticketstatus(){
  	if($_SERVER['REQUEST_METHOD']=='POST')
		{
		    	$tickid = $this->input->post('ticketid');
		    	$status = $this->input->post('status');
		    	date_default_timezone_set('Asia/Kolkata');
    						 	$date=date("Y/m/d");
			$time=date("h:i:sa");
		    		$this->User_model->changestatusofticket($tickid,$status,$time,$date);
		    		
		    			redirect('Ticketresponse/opencomp/'.$tickid);
		}  
}
function inputmess(){
    	$tickid = $this->input->post('tickid');
    		$sendfromid = $this->input->post('sendfromid');
    			$sendfromname = $this->input->post('sendfromname');
    				$sendtoname = $this->input->post('sendtoname');
    					$sendtoid = $this->input->post('sendtoid');
    						$message = $this->input->post('message');
    						 date_default_timezone_set('Asia/Kolkata');
    						 	$date=date("Y/m/d");
			$time=date("h:i:sa");
				$data = array(
                        'tickid'=>$tickid,
						'sendfromid'=>$sendfromid,
						'sendfromname' => $sendfromname,
						'sendtoname' => $sendtoname,
						'sendtoid' => $sendtoid,
						'message'=> $message,
						'date' => $date,
						'time' => $time,
						'vstatus'=>0
					);
						$this->User_model->response($data);
						redirect('Ticketresponse/opencomp/'.$tickid);
				
}
function inputcmess(){
    	$tickid = $this->input->post('tickid');
    		$sendfromid = $this->input->post('sendfromid');
    			$sendfromname = $this->input->post('sendfromname');
    				$sendtoname = $this->input->post('sendtoname');
    					$sendtoid = $this->input->post('sendtoid');
    						$message = $this->input->post('message');
    						 date_default_timezone_set('Asia/Kolkata');
    						 	$date=date("Y/m/d");
			$time=date("h:i:sa");
				$data = array(
                        'tickid'=>$tickid,
						'sendfromid'=>$sendfromid,
						'sendfromname' => $sendfromname,
						'sendtoname' => $sendtoname,
						'sendtoid' => $sendtoid,
						'message'=> $message,
						'date' => $date,
						'time' => $time,
						'vstatus'=>0
					);
						$this->User_model->response($data);
						$udata=$this->session->userdata('UserLoginSession');
						$chatflag=$udata['chatflag'];
						if($chatflag==1){
						   	redirect('Ticketresponse/viewticket/'.$tickid); 
						}else{
						    	redirect('Ticketresponse/chat/'.$tickid);
						}
					
				
}
function cuscomplaint(){
    	if($_SERVER['REQUEST_METHOD']=='POST')
		{
		  	$tickid = $this->input->post('tickid');
		   	$tick = $this->User_model->getticket($tickid);
		    $udata = $this->session->userdata('UserLoginSession');
        
             $cid=$udata['userid'] ;
             $cusid=$tick->customerid;
             if($cid==$cusid){
                
                		redirect('Ticketresponse/viewticket/'.$tickid);	
             }
             else{
                 	redirect(base_url('Customer/homepage'));	
             }
		}
    
}
function viewticket($id){
     $udata = $this->session->userdata('UserLoginSession');
    	$cusid = $udata['userid'] ;
	 	$data['h']=$this->User_model->selectcustomertickets($cusid);  
    	$data['tick'] = $this->User_model->getticket($id);
	    		$data['mess'] = $this->User_model->getresponse($id);
	    	  $this->load->view('Customer_View/viewticket',$data);
}
function complaintstatus(){
  if($_SERVER['REQUEST_METHOD']=='POST')
		{
		  	$tickid = $this->input->post('tickid'); 
		  	 $phone = $this->input->post('phone');
		  		$data['tick'] = $this->User_model->getticketdet($tickid,$phone);
		  		if($data['tick']!=NULL){
		  		    	$data['flag']='1';
		  		 $this->load->view('Customer_View/complaintstatus',$data);
		  		}
		  		else{
		  		   	$data['flag']='5';
		  		 $this->load->view('Customer_View/complaintstatus',$data); 
		  		}
		  	
		}  
}
function viewall() {
    if($_SERVER['REQUEST_METHOD']=='POST')
		{
		 $phone = $this->input->post('phone');
			$data['tick']=$this->User_model->selectcustomertickets($phone);  
				$data['flag']='2';
				 $this->load->view('Customer_View/complaintstatus',$data);
		} 
    
}
function chat($id){
     $session_data = array(
                        'userid'=>'',
						'username'=>'',
						'email' => '',
						'phone' =>'',
				'chatflag' =>0,
					
					);
  $data['tick'] = $this->User_model->getticket($id);
    
    $session_data = array(
                        'userid'=>$data['tick']->customerid,
						'username'=>$data['tick']->customername,
						'email' => $data['tick']->email,
						'phone' => $data['tick']->phone,
					    'chatflag' =>0,
					
					);
				
					$this->session->set_userdata('UserLoginSession',$session_data);
	    		$data['mess'] = $this->User_model->getresponse($id);
	    	  $this->load->view('Customer_View/chat',$data);  
}
function change_sts(){
		 $id = $this->input->post('id');
		 $status = $this->input->post('status');
        $data = array("assign_status"=>$status);
        $id_array = array("id"=>$id);

        $result=$this->User_model->updateadmintickets($id_array, $data); 
        if($result){echo 1;}else{ echo 0;}
        

}
}



