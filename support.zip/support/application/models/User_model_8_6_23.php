<?php 

class User_model extends CI_Model {

	function insertuser($data,$phone)
	{
	    
	    	$query = $this->db->query("SELECT * FROM users WHERE  phone='$phone'");
	    if($query->num_rows()==0)
		{
		   	$this->db->insert('users',$data); 
		}
	
	}
	function insertdealer($data,$phone)
	{
	    
	    	$query = $this->db->query("SELECT * FROM dealer WHERE  phone='$phone'");
	    if($query->num_rows()==0)
		{
		   	$this->db->insert('dealer',$data); 
		}
	
	}
	function getbyphone($phone){
	  	$query = $this->db->query("SELECT * FROM users WHERE  phone='$phone'");
	
			return $query->row();
	  
	}
	function insertresponse($data,$tickid){
	    	$query = $this->db->query("SELECT * FROM engresponse WHERE  tickid='$tickid'");
	    if($query->num_rows()==0)
		{
		   $this->db->insert('engresponse',$data);   
		}else{
		   $this->db->query("DELETE FROM engresponse WHERE  tickid='$tickid'");
		    $this->db->insert('engresponse',$data);   
		}
        //echo $this->db->last_query(); 
	 
	}
	function getbill($tickid){
	    	$query = $this->db->query("SELECT * FROM engresponse WHERE  tickid='$tickid'");
	   return $query->row();
	}
	function registerfaq($companyname,$companyid,$question,$answer,$status)
	{
		$this->db->query("INSERT INTO `faq`(`companyname`, `companyid`, `question`, `answer`, `status`) VALUES ('$companyname', '$companyid', '$question', '$answer', '$status')");
	}
	
	function insertcompany($data)
	{
		$this->db->insert('company',$data);
	}
	function response($data){
	   	$this->db->insert('response',$data); 
	}
	function checkPassword($password_1,$email)
	{
		$query = $this->db->query("SELECT * FROM users WHERE (password_1='$password_1' AND email='$email' AND status='1') OR (password_1='$password_1' AND phone='$email' AND status='1') OR (password_1='$password_1' AND id='$email' AND status='1')");
		if($query->num_rows()==1)
		{
			return $query->row();
		}
		else
		{
			return false;
		}

	}
	function checkcompany($password_1,$email)
	{
		$query = $this->db->query("SELECT * FROM company WHERE password='$password_1' AND companymail='$email'");
		if($query->num_rows()==1)
		{
			return $query->row();
		}
		else
		{
			return false;
		}

	}
	function checkEmail($email)
	{
		$query = $this->db->query("SELECT * FROM users WHERE email='$email' AND status='1'");
		if($query->num_rows()==1)
		{
			return $query->row();
		}
		else
		{
			return false;
		}

	}
	
	function checkDealerEmail($email)
	{
		$query = $this->db->query("SELECT * FROM dealer WHERE email='$email' AND status='1'");
		if($query->num_rows()==1)
		{
			return $query->row();
		}
		else
		{
			return false;
		}

	}
		function getstaff($email)
	{
		$query = $this->db->query("SELECT * FROM users WHERE (email='$email') OR (id='$email') ");
	
			return $query->row();
	

	}
	
	function getdealer($email)
	{
		$query = $this->db->query("SELECT * FROM dealer WHERE (email='$email') OR (dealerid='$email') ");
	
			return $query->row();
	

	}
	function getstaffdet($id){
	  $query = $this->db->query("SELECT * FROM users WHERE id='$id' ");
	
			return $query;  
	}
	
	function getdealerdet($id){
	  $query = $this->db->query("SELECT * FROM dealer WHERE dealerid='$id' ");
	
			return $query;  
	}
	function editstaffdetails($id,$username,$email,$cemail,$phone,$designation,$password_1,$pincode,$address){
	   $this->db->query("UPDATE users SET username='$username',email='$email' ,cemail='$cemail',phone='$phone',designation='$designation',password_1='$password_1',pincode='$pincode',address= '$address' WHERE id='$id' "); 
	}
	
	function editdealerdetails($id,$username,$email,$cemail,$phone,$designation,$password_1,$pincode,$address){
	   $this->db->query("UPDATE dealer SET username='$username',email='$email' ,cemail='$cemail',phone='$phone',designation='$designation',password_1='$password_1',pincode='$pincode',address= '$address' WHERE dealerid='$id' "); 
	}
	
	function editstaffpro($id,$image1){
	 $this->db->query("UPDATE users SET profile_img='$image1' WHERE id='$id' ");   
	}
	
	function editdealerpro($id,$image1){
	 $this->db->query("UPDATE dealer SET profile_img='$image1' WHERE dealerid='$id' ");   
	}
		function editstaffid($id,$image2){
	 $this->db->query("UPDATE users SET id_proof='$image2' WHERE id='$id' ");   
	}
	
	function editdealerid($id,$image2){
	 $this->db->query("UPDATE dealer SET id_proof='$image2' WHERE dealerid='$id' ");   
	}
    function deleteticket($id){
	 if($this->db->query("UPDATE ticket SET is_delete='1' WHERE id='$id' ")){
        return true;
     }  else{
        return false;
     }
	}

    
	function select()  
      {  
         
		$query = $this->db->get(" ticket");  
		return $query;   
      }  
      function selectallticket($companyid){  
       
		$query = $this->db->query("SELECT * FROM ticket WHERE companyid='$companyid' 
         AND is_delete='0' ORDER BY `ticket`.`id` DESC ");  
		return $query;   
      }  
      function  selectbyorder($companyid){
         	$query = $this->db->query("SELECT * FROM ticket WHERE status='1' AND is_delete='0' AND companyid='$companyid' ORDER BY  view_status ASC,date DESC LIMIT 3 ");  
  
         	return $query;
      }
      function  selectall($companyid){
         	$query = $this->db->query("SELECT * FROM ticket WHERE status='1' AND is_delete='0' AND view_status='not_viewed' AND companyid='$companyid'  ORDER BY view_status DESC,date DESC  ");  
  
         	return $query;
      }
      function pending()  
      {  
         
		$query = $this->db->query("SELECT * FROM company WHERE status='0'");  
		return $query;   
      }  
       function changestatus($companyid)  
      {  
         
		 $this->db->query("UPDATE company SET `status`='1' WHERE `companyid`='$companyid'");  
	
      }  
      function selectstaff($companyid)  
      {  
         
			$query = $this->db->query("SELECT * FROM users WHERE role='Staff' AND companyid='$companyid'");  
		return $query;   
      }  
      
      function selectdealer($companyid)  
      {  
         
			$query = $this->db->query("SELECT * FROM dealer WHERE role='Staff' AND companyid='$companyid'");  
		return $query;   
      }  
     function removestaff($email)
     {
         $this->db->query("DELETE FROM users WHERE email='$email' AND role='Staff'");  
         
     }
     function removedealer($email)
     {
         $this->db->query("DELETE FROM dealer WHERE email='$email' AND role='Staff'");  
         
     }
      function selectuser($companyid)  
      {  
         
			$query = $this->db->query("SELECT * FROM users WHERE companyid='$companyid' AND role='Customer'");  
		return $query;   
      }  
     function removeuser($email)
     {
         $this->db->query("DELETE FROM users WHERE email='$email' AND role='Customer'");  
         
     }
     function selectuserdetails($id)
     {
         $query=$this->db->query("SELECT * FROM users WHERE id='$id' role='Customer'");  
		return $query;   
     }
      
    function registerticket($data){
      	$this->db->insert('ticket',$data);  
    }
    function changeviewstatus($id){
        $this->db->query("UPDATE ticket SET `view_status`='viewed' WHERE id='$id' ");  
    }
    function selectticket($companyid){
         $query=$this->db->query("SELECT * FROM ticket WHERE assign_status='0' AND is_delete='0' AND companyid='$companyid' ORDER BY id DESC ");  
		return $query;   
    }
    function staffdetails($staff){
        $query=$this->db->query("SELECT * FROM users WHERE id='$staff' AND role='Staff' ");  
		return $query;   
    }
    function assignticket($staff,$staffname,$temp){
        $this->db->query("UPDATE ticket SET `staffid`='$staff',`staff`='$staffname',`assign_status`='1', status='1' WHERE `id`='$temp'");  
    }
    function selectcompany($id){
        	$query = $this->db->query("SELECT * FROM company WHERE companyid='$id'");  
		return $query;   
    }
    function viewallcompany(){
        $query = $this->db->query("SELECT * FROM company ");  
		return $query;  
    }
    function view_faq($companyid){
        $query = $this->db->query("SELECT * FROM faq WHERE `companyid`='$companyid' ORDER BY faqid ");  
		return $query; 
    }
  function faq_delete($id){
      $this->db->query("DELETE FROM faq WHERE faqid='$id' ");
  }
   public function insert($email,$profile_img){
        
        $insert =  $this->db->query("UPDATE users SET `profile_img`='$profile_img' WHERE `email`='$email'");  
        if($insert){
            return $this->db->insert_id();
        }else{
            return false;    
        }
    }
    
    
    
    
    
    public function editimage($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome SET image='$image' WHERE id='1'");  
    
       
    }
    
     public function editimage2($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome SET image2='$image' WHERE id='1'");  
    
       
    }
    
     public function editimage3($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome SET image3='$image' WHERE id='1'");  
    
       
    }
    
    
    
     public function editimage4($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome2 SET image='$image' WHERE id='1'");  
    
       
    }
    
    
    
     public function editimage5($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome2 SET image2='$image' WHERE id='1'");  
    
       
    }
    
    
     public function editimage6($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome2 SET image3='$image' WHERE id='1'");  
    
       
    }
    
    public function editimage7($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome3 SET image='$image' WHERE id='1'");  
    
       
    }
    
    
     public function editimage8($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome5 SET image='$image' WHERE id='1'");  
    
       
    }
    
    
    
    public function editimage9($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome5 SET image2='$image' WHERE id='1'");  
    
       
    }
    
    
    public function editimage10($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome5 SET image3='$image' WHERE id='1'");  
    
       
    }
    
    
    public function editimage11($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome5 SET image4='$image' WHERE id='1'");  
    
       
    }
    
    
    public function editimage12($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome5 SET image5='$image' WHERE id='1'");  
    
       
    }
    
    
    
    public function editimage13($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome5 SET image6='$image' WHERE id='1'");  
    
       
    }
    
    
    
    public function editimage14($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome5 SET image7='$image' WHERE id='1'");  
    
       
    }
    
    
    
    public function editimage15($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome5 SET image8='$image' WHERE id='1'");  
    
       
    }
    
    
    
    public function editimage16($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome5 SET image9='$image' WHERE id='1'");  
    
       
    }
    
    
    
    public function editimage17($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome5 SET image10='$image' WHERE id='1'");  
    
       
    }
    
    
    public function editimage18($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome5 SET image11='$image' WHERE id='1'");  
    
       
    }
    
    
    public function editimage19($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome5 SET image12='$image' WHERE id='1'");  
    
       
    }
    
    
     public function editimage20($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome6 SET image='$image' WHERE id='1'");  
    
       
    }
    
    
     public function editimage21($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome6 SET image2='$image' WHERE id='1'");  
    
       
    }
    
    
    
     public function editimage22($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome6 SET image3='$image' WHERE id='1'");  
    
       
    }
    
    
     public function editimage23($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome6 SET image4='$image' WHERE id='1'");  
    
       
    }
    
    
     public function editimage24($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome7 SET image='$image' WHERE id='1'");  
    
       
    }
    
    
     public function editimage25($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome7 SET image2='$image' WHERE id='1'");  
    
       
    }
    
    
     public function editimage26($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome7 SET image3='$image' WHERE id='1'");  
    
       
    }
    
    
     public function editimage27($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome7 SET image4='$image' WHERE id='1'");  
    
       
    }
    
    
     public function editimage28($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome7 SET image5='$image' WHERE id='1'");  
    
       
    }
    
     public function editimage29($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome7 SET image6='$image' WHERE id='1'");  
    
       
    }
    
    
     public function editimage30($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome7 SET image7='$image' WHERE id='1'");  
    
       
    }
    
    
     public function editimage31($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome7 SET image8='$image' WHERE id='1'");  
    
       
    }
    
     public function editimage32($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome7 SET image9='$image' WHERE id='1'");  
    
       
    }
    
    
     public function editimage33($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome7 SET image10='$image' WHERE id='1'");  
    
       
    }
    
    
     public function editimage34($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome8 SET image='$image' WHERE id='1'");  
    
       
    }
    
     public function editimage35($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome8 SET image2='$image' WHERE id='1'");  
    
       
    }
    
    
     public function editimage36($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome8 SET image3='$image' WHERE id='1'");  
    
       
    }
    
    
     public function editimage37($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome9 SET image='$image' WHERE id='1'");  
    
       
    }
    
     public function editimage38($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome9 SET image2='$image' WHERE id='1'");  
    
       
    }
    
     public function editimage39($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome9 SET image3='$image' WHERE id='1'");  
    
       
    }
    
    
     public function editimage40($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome9 SET image4='$image' WHERE id='1'");  
    
       
    }
    
    
     public function editimage41($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome9 SET image5='$image' WHERE id='1'");  
    
       
    }
    
    
     public function editimage42($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome9 SET image6='$image' WHERE id='1'");  
    
       
    }
    
    
     public function editimage43($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome9 SET image7='$image' WHERE id='1'");  
    
       
    }
    
    
     public function editimage44($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome9 SET image8='$image' WHERE id='1'");  
    
       
    }
    
    
     public function editimage45($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome9 SET image9='$image' WHERE id='1'");  
    
       
    }
    
    
     public function editimage46($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome9 SET image10='$image' WHERE id='1'");  
    
       
    }
    
      public function editimage47($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome10 SET image='$image' WHERE id='1'");  
    
       
    }
    
     public function editimage48($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome10 SET image2='$image' WHERE id='1'");  
    
       
    }
    
    
 
     public function edittext3($image,$image2,$image3,$image4,$image5,$image6){
     

			 $insert =  $this->db->query("UPDATE sliderhome SET title='$image',stitle='$image2', title2='$image3',stitle2='$image4',title3='$image5',stitle3='$image6' WHERE id='1'");  
    
       
    }
    
    
     public function edittext4($image,$image2,$image3,$image4,$image5,$image6){
     

			 $insert =  $this->db->query("UPDATE sliderhome2 SET title='$image',stitle='$image2', title2='$image3',stitle2='$image4',title3='$image5',stitle3='$image6' WHERE id='1'");  
    
       
    }
    
    
    
     public function edittext5($image){
     

			 $insert =  $this->db->query("UPDATE sliderhome3 SET title='$image' WHERE id='1'");  
    
       
    }
    
    
    
     public function edittext12($image,$image2,$image3,$image4,$image5,$image6,$image7,$image8,$image9,$image10,$image11,$image12){
     

			 $insert =  $this->db->query("UPDATE sliderhome5 SET title='$image',title2='$image2',title3='$image3',title4='$image4',title5='$image5',title6='$image6',title7='$image7',title8='$image8',title9='$image9',title10='$image10',title11='$image11',title12='$image12' WHERE id='1'");  
    
       
    }
    
    
     public function edittext13($image,$image2,$image3,$image4){
     

			 $insert =  $this->db->query("UPDATE sliderhome6 SET title='$image',title2='$image2',title3='$image3',title4='$image4' WHERE id='1'");  
    
       
    }
    
    
      public function edittext14($image,$image2,$image3,$image4,$image5,$image6,$image7,$image8,$image9,$image10){
     

			 $insert =  $this->db->query("UPDATE sliderhome7 SET title='$image',title2='$image2',title3='$image3',title4='$image4',title5='$image5',title6='$image6',title7='$image7',title8='$image8',title9='$image9',title10='$image10'WHERE id='1'");  
    
       
    }
    
     public function edittext15($image,$image2,$image3){
     

			 $insert =  $this->db->query("UPDATE sliderhome8 SET title='$image',title2='$image2',title3='$image3'WHERE id='1'");  
    
       
    }
    
    
     public function edittext17($image,$image2,$image3,$image4,$image5,$image6,$image7,$image8,$image9,$image10){
     

			 $insert =  $this->db->query("UPDATE sliderhome9 SET title='$image',title2='$image2',title3='$image3',title4='$image4',title5='$image5',title6='$image6',title7='$image7',title8='$image8',title9='$image9',title10='$image10'WHERE id='1'");  
    
       
    }
    
    
     public function edittext18($image,$image2){
     

			 $insert =  $this->db->query("UPDATE sliderhome10 SET title='$image',title2='$image2'WHERE id='1'");  
    
       
    }
    
    
    
    
    
    
    
    
     function getImage1(){
       
        $Q = $this->db->query("SELECT * FROM sliderhome WHERE `id`='1' ");
       
        return $Q;
    }
    
     function getImage2(){
       
        $Q = $this->db->query("SELECT * FROM sliderhome2 WHERE `id`='1' ");
       
        return $Q;
    }
    
    function getImage3(){
       
        $Q = $this->db->query("SELECT * FROM sliderhome3 WHERE `id`='1' ");
       
        return $Q;
    }
    
    
    function getImage4(){
       
        $Q = $this->db->query("SELECT * FROM sliderhome4 WHERE `id`='1' ");
       
        return $Q;
    }
    
    
     function getImage5(){
       
        $Q = $this->db->query("SELECT * FROM sliderhome5 WHERE `id`='1' ");
       
        return $Q;
    }
    
    
     function getImage6(){
       
        $Q = $this->db->query("SELECT * FROM sliderhome6 WHERE `id`='1' ");
       
        return $Q;
    }
    
    function getImage7(){
       
        $Q = $this->db->query("SELECT * FROM sliderhome7 WHERE `id`='1' ");
       
        return $Q;
    }
    
    function getImage8(){
       
        $Q = $this->db->query("SELECT * FROM sliderhome8 WHERE `id`='1' ");
       
        return $Q;
    }
    
    
    function getImage9(){
       
        $Q = $this->db->query("SELECT * FROM sliderhome9 WHERE `id`='1' ");
       
        return $Q;
    }
    
    
    function getImage10(){
       
        $Q = $this->db->query("SELECT * FROM sliderhome10 WHERE `id`='1' ");
       
        return $Q;
    }
    
     function gettxt(){
       
        $Q = $this->db->query("SELECT * FROM sliderhome WHERE `id`='1' ");
       
        return $Q;
    }
    
    
     function gettxt2(){
       
        $Q = $this->db->query("SELECT * FROM sliderhome2 WHERE `id`='1' ");
       
        return $Q;
    }
    
    function gettxt3(){
       
        $Q = $this->db->query("SELECT * FROM sliderhome3 WHERE `id`='1' ");
       
        return $Q;
    }
    
    function gettxt4(){
       
        $Q = $this->db->query("SELECT * FROM sliderhome4 WHERE `id`='1' ");
       
        return $Q;
    }
    
    
    function gettxt5(){
       
        $Q = $this->db->query("SELECT * FROM sliderhome5 WHERE `id`='1' ");
       
        return $Q;
    }
    
    
    
    
    function gettxt6(){
       
        $Q = $this->db->query("SELECT * FROM sliderhome6 WHERE `id`='1' ");
       
        return $Q;
    }
    
    function gettxt14(){
       
        $Q = $this->db->query("SELECT * FROM sliderhome7 WHERE `id`='1' ");
       
        return $Q;
    }
    
     function gettxt15(){
       
        $Q = $this->db->query("SELECT * FROM sliderhome8 WHERE `id`='1' ");
       
        return $Q;
    }
    
    
     function gettxt16(){
       
        $Q = $this->db->query("SELECT * FROM sliderhome9 WHERE `id`='1' ");
       
        return $Q;
    }
    
    
     function gettxt17(){
       
        $Q = $this->db->query("SELECT * FROM sliderhome10 WHERE `id`='1' ");
       
        return $Q;
    }
    
    
    
    
    
    
    
    
    
    
    function getImage($email){
       
        $Q = $this->db->query("SELECT * FROM users WHERE `email`='$email' ");
       
        return $Q;
    }
    function selectticketsofstaff($staffid){
      $query = $this->db->query("SELECT * FROM ticket WHERE `staffid`='$staffid' AND is_delete='0' ORDER BY id ");  
		return $query;    
    }
    function getticketdet($id,$phone){
         $query = $this->db->query("SELECT * FROM ticket WHERE `id`='$id' AND is_delete='0' AND phone='$phone' ");
         
          return $query->row();     
         
		
    }
     function getticketWid($id){
         $query = $this->db->query("SELECT * FROM ticket WHERE `id`='$id' AND is_delete='0' ");
         
          return $query->result(); 
    }
    
    function getticket($id){
         $query = $this->db->query("SELECT * FROM ticket WHERE `id`='$id' AND is_delete='0' ");
         
          return $query->row();     
         
		
    }
    
    function getticketbyid($cusid){
         $query = $this->db->query("SELECT * FROM ticket WHERE `customerid`='$cusid' AND is_delete='0' ");
         
          return $query;     
    }
    function getresponse($id){
         $query = $this->db->query("SELECT * FROM response WHERE `tickid`='$id' ORDER BY id ");  
		return $query;  
        
    }
    function selectcustomertickets($cusid){
         $query = $this->db->query("SELECT * FROM ticket WHERE ((`customerid`='$cusid') OR (phone='$cusid')) AND is_delete='0' ORDER BY id ");  
		return $query;    
    }
    function getpro($cusid){
         $query = $this->db->query("SELECT * FROM users WHERE `id`='$cusid' ");  
		return $query->row();    
    }
    function editpro($id,$username,$email,$phone,$address,$password,$pincode){
        $this->db->query("UPDATE users SET `username`='$username',email='$email',phone='$phone', address='$address',password_1='$password', pincode='$pincode'   WHERE `id`='$id'");  
    }
    function revokestaff($id){
        $query = $this->db->query("SELECT * FROM users WHERE `id`='$id' ");  
		$q= $query->row();
		$stat=$q->status;
		if($stat==0){
		    $this->db->query("UPDATE users SET `status`='1' WHERE `id`='$id'");   
		}else{
		     $this->db->query("UPDATE users SET `status`='0' WHERE `id`='$id'");   
		}
    }
    function revokedealer($id){
        $query = $this->db->query("SELECT * FROM dealer WHERE `dealerid`='$id' ");  
		$q= $query->row();
		$stat=$q->status;
		if($stat==0){
		    $this->db->query("UPDATE dealer SET `status`='1' WHERE `dealerid`='$id'");   
		}else{
		     $this->db->query("UPDATE dealer SET `status`='0' WHERE `dealerid`='$id'");   
		}
    }
    function getusers(){
         $query = $this->db->query("SELECT * FROM users WHERE `role`='Customer' ORDER BY id ");  
		return $query;     
    }
     function gettickets(){
         $query = $this->db->query("SELECT * FROM ticket  WHERE  is_delete='0' ORDER BY id ");  
		return $query;     
    }
    function getdistinct(){ 
     $query = $this->db->query("SELECT DISTINCT phone, customername FROM `ticket` WHERE  is_delete='0'");  
		return $query;    
    }
    function getticks($phone){
          $query = $this->db->query("SELECT * FROM `ticket` WHERE phone='$phone' AND is_delete='0'");  
		return $query;    
    }
    function changestatusofticket($tickid,$status,$time,$date){
       $this->db->query("UPDATE ticket SET `status`='$status',resolvedtime='$time',resolveddate='$date' WHERE `id`='$tickid'");   
    }
    function selectresolved($staffid){
           $query = $this->db->query("SELECT * FROM ticket WHERE ((status='2' AND staffid='$staffid') OR (status='3' AND staffid='$staffid')) AND is_delete='0' ORDER BY id ");  
		return $query;    
    }
     function resolved(){
           $query = $this->db->query("SELECT * FROM ticket WHERE ((status='2') OR (status='3')) AND is_delete='0' ORDER BY id ");  
		return $query;    
    }
    function getticketid($phone,$cusid){
     $query = $this->db->query("SELECT * FROM ticket WHERE phone='$phone' AND customerid='$cusid' AND is_delete='0' ORDER BY id DESC LIMIT 1 ");  
		return $query->row();  
}
function getproducts(){
       $query = $this->db->query("SELECT * FROM `products` ");  
		return $query; 
}
function getproductbyid($id){
     $query = $this->db->query("SELECT * FROM `products` WHERE id='$id' ");  
		return $query->row(); 
}

function selectStfCret($uid){
	$query = $this->db->query("SELECT * FROM users WHERE adusr='$uid' AND role='Customer'");  
	return $query;   
} 

public function updateTicket($data1,$cid){
         $this->db->where('id',$cid);
          if($this->db->update('ticket', $data1)){
          return true;
      } else {
        return false;
      }
  }
  public function selectstaffWork($staff,$dates){
    $data =array(); 
    if($staff !=null && $staff !="ALL"){
        $sql = "SELECT ticket.*,users.username  FROM ticket
         left join users on users.id=ticket.staffid AND ticket.staffid !=0
          WHERE staffid='$staff' AND 
        resolveddate=$dates AND is_delete='0' ORDER BY id DESC ";
        
        $query = $this->db->query($sql);  
		return $data = $query->result(); 
        
        
      } else  if($staff !=null && $staff =="ALL"){
        $sql = "SELECT ticket.*,users.username FROM ticket
        left join users on users.id=ticket.staffid AND ticket.staffid !=0
         WHERE  
        resolveddate=$dates AND is_delete='0' ORDER BY id DESC ";
   
        $query = $this->db->query($sql);  
		return $data = $query->result(); 
      }else{
        return $data;
      }
  }    
   public function selectstaffWorkMonthly($staff,$newdateFrom,$newdateTo){
    $data =array(); 
    if($staff !=null && $staff !="ALL"){
        $sql = "SELECT ticket.*,users.username FROM ticket 
         left join users on users.id=ticket.staffid AND ticket.staffid !=0
        WHERE staffid='$staff' AND is_delete='0' AND 
        resolveddate BETWEEN  $newdateFrom  AND $newdateTo ORDER BY id DESC ";
        $query = $this->db->query($sql);  
		return $data = $query->result(); 
        
        
      }else  if($staff !=null && $staff =="ALL"){ 
        $sql = "SELECT ticket.*,users.username FROM ticket 
          left join users on users.id=ticket.staffid AND ticket.staffid !=0
          WHERE   is_delete='0' AND 
        resolveddate BETWEEN  $newdateFrom  AND $newdateTo ORDER BY id DESC ";
        $query = $this->db->query($sql);  
		return $data = $query->result(); 
      }
      else {
        return $data;
      }
  }
  public function sendsms($phone=null,$sms=null){

    $sm =urldecode($sms);
    $sms="http://bhashsms.com/api/sendmsg.php?user=NOVAITPARKotp&pass123456sender=BHASH&phone=".$phone."&text=".$sms."&priority=Priority&stype=smstype";
    //$sms="http://sms.novaitpark.com/api/sendmsg.php?user=ORIONTECH&pass=123456&sender=NOVAIT&phone=".$phone."&text=".$sms."&priority=ndnd&stype=normal";
    //$sms = "http://bhashsms.com/api/sendmsg.php?user=NOVAITPARK&pass=123456&sender=CSTARF&phone=".$phone."&text=".$sms."&priority=ndnd&stype=normal";
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => $sms,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_HTTPHEADER => array(
          "cache-control: no-cache",
          "postman-token: a619664f-d66e-9517-b381-adf196c2378b"
        ),
        ));
       $response = curl_error($curl);
         $response = curl_exec($curl);  
       return $response;

}  
function getticketWidNew($id){
    $query = $this->db->query("SELECT * FROM ticket WHERE `id`='$id'  AND is_delete='0' ");
    
     return $query->result(); 
}
     
public function getpassword($usr_id,$usr_pwd){
        
    if(($usr_id != null)){
        $builder = $this->db->select('id')
                    ->from('users')
                    ->where('id',$usr_id)
                    ->where('password_1',$usr_pwd)
                    
                    ->get();
                    
        $result = $builder->row();
        
            return $result;
       
         
    }
    
}
public function updateUser($data,$condition){
    $builder =  $this->db->set($data)
                         ->where($condition)
                         ->update('users');
//print_r($this->db->last_query());exit();
    if($builder){
        return true;
    }
    else{
        return false;
    }
}
}
