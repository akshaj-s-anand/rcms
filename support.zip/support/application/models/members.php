<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class member extends CI_Model{
    function __construct() {
        $this->tableName = 'users';
        $this->primaryKey = 'id';
    }
    
    public function insert($email,$profile_img){
        
        $insert =  $this->db->query("UPDATE users SET `profile_img`='$profile_img' WHERE `email`='$email'");  
        if($insert){
            return $this->db->insert_id();
        }else{
            return false;    
        }
    }
    function getImage($email){
       
        $Q = $this->db->query("SELECT * FROM users WHERE `email`='$email ");
       
        return $Q;
    }
}
      