<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Engineer Page</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <link rel="stylesheet" href="<?=base_url('plugins/fontawesome-free/css/all.min.css')?>">

  <link rel="stylesheet" href="<?=base_url('dist/css/adminlte.min.css')?>">
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
 
<style>
    table {
        background-color:white;
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}
thead,th{
   border: 1px solid #ddd;
  padding: 8px;  
  background-color:#27a143;
}
td {
  border: 1px solid #ddd;
  padding: 8px;
}





th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #04AA6D;
  color: white;
}
.button1 {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 5px 20px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  transition-duration: 0.4s;
  cursor: pointer;
}

.button2 {
  background-color: white; 
  color: black; 
  border: 2px solid #007FFF;
}

.button2:hover {
  background-color: #007FFF;
  color: white;
}
.container1 {
  border: 2px solid #dedede;
  background-color: #f1f1f1;
  border-radius: 5px;
  padding: 10px;
  margin: 10px 0;
}

.darker {
  border-color: #ccc;
  background-color: #ddd;
}

.container1::after {
  content: "";
  clear: both;
  display: table;
}

.container1 label {
  float: left;
  max-width: 60px;
  width: 100%;
  margin-right: 20px;
  border-radius: 50%;
}

.container1 label.right {
  float: right;
  margin-left: 20px;
  margin-right:0;
}

.time-right {
  float: right;
  color: #aaa;
}

.time-left {
  float: left;
  color: #999;
}
#overflowC {
 
  padding: 15px;
 
  height: 300px;
  overflow: auto;
  border: 1px solid #ccc;
}
</style>
</head>
<body class="hold-transition sidebar-mini" style="width:auto;min-width:174px">
<div class="wrapper">

  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-green navbar-light"style="width:auto;min-width:174px">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" class="sidebar-toggle" data-toggle="offcanvas" role="button"><i class="fas fa-bars"></i></a>
      </li>
    
    </ul>

   
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
   
    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
      <i class="fa fa-user " style="color:white;padding:4.7%"></i>
        <div class="info">
          <a href="#" class="d-block" style="font-size:20px"> <?php 
if($this->session->userdata('UserLoginSession'))
{
    $udata = $this->session->userdata('UserLoginSession');
    echo $udata['username'] ;
}
else
{
    redirect(base_url('Login_Registration/login'));
}



 ?></a>
   <a  href="<?=base_url('Staff/logout')?>"><b class="try" style="font-size:15px;color:#ff4d4d">LogOut</b></a>
  
        </div>
      </div>

     

      <!-- Sidebar Menu -->
              <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
               <li class="nav-item ">
       <a href="<?=base_url('Staff/ticketview')?>" class="nav-link ">
         <i class="fas fa-home"></i>
         <p>
          Home
          
         </p>
       </a>
        <li class="nav-item ">
       <a href="<?=base_url('Staff/registeruser')?>" class="nav-link ">
         <i class="fas fa-folder"></i>
         <p>
          Register User
          
         </p>
       </a>
        <li class="nav-item ">
       <a href="<?=base_url('Staff/removeuser')?>" class="nav-link ">
         <i class="fas fa-folder"></i>
         <p>
          Remove User
          
         </p>
       </a>
               <li class="nav-item ">
       <a href="<?=base_url('Staff/myticketview')?>" class="nav-link ">
         <i class="fas fa-folder"></i>
         <p>
          My Complaints
          
         </p>
       </a>
      
     <li class="nav-item">
       <a href="<?=base_url('Staff/viewmyoverduetickets')?>" class="nav-link">
         <i class=" fas fa-folder"></i>
         <p>
          My Overdue Complaints
          
         </p>
       </a>
     </li>
     <li class="nav-item">
       <a href="<?=base_url('Staff/viewmyduetoday')?>" class="nav-link">
         <i class="fas fa-folder"></i>
         <p>
          My Due Today Complaints
         </p>
       </a>
           </li>
     <li class="nav-item">
       <a href="<?=base_url('Staff/viewmypending')?>" class="nav-link">
         <i class="fas fa-folder"></i>
         <p>
           My Pending Complaints
         
         </p>
       </a>
     </li>
    
      <li class="nav-item">
       <a href="<?=base_url('Staff/myresolvedtickets')?>" class="nav-link">
         <i class="fas fa-folder"></i>
         <p>
           My Resolved Complaints
         
         </p>
       </a>
     </li>
    
    
       <li class="nav-item ">
       <a href="<?=base_url('Staff/view_faq')?>" class="nav-link ">
         <i class="fas fa-folder"></i>
         <p>
           FAQs 
          
         </p>
       </a>
     </li>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2"> <?php 
                        $d1=new DateTime();
                        $d2 = date_create($tick->date);
                        $tick->diff=date_diff($d2,$d1);
                        $tick->d=(int)$tick->diff->format("%R%a");
                        ?> 
          <div class="col-sm-6">
                <div style="display:flex;flex-directon:row">
                    <p> <h1 class="m-0" style="padding-top:12px;">Complaint Id: <?php echo $tick->id ?> </h1></p>
       <button class="button1 button2" onclick="myFunction1()"  id="cusbtn"><b>Customer Detail</b></button>    <button class="button1 button2" onclick="myFunction2()"  id="itbtn"><b>Item Detail</b></button>  
    </div>
          <div style="display:flex;flex-directon:row">
               <p><b>Registered on : </b><?php echo $tick->date?> <?php echo $tick->time?></p>
              <p style="margin-left:15px"><b>Overdue Status : </b><?php if(($tick->d)>8){ ?><label style="color:red">Overdue</label> <?php }else{ ?><label style="color:green">In Time</label> <?php }  ?></p>
          
          </div> 
           <?php if(($tick->status)==0){ ?><p style="color:red"><b style="black">Status : </b> Open </p><?php } ?><?php if(($tick->status)==1){ ?><p style="color:#a63d05"><b style="black">Status : </b> Working </p><?php } ?><?php if(($tick->status)==2){ ?><p style="color:#bf762c"><b style="black">Status : </b> Temporarly Closed </p><?php } ?><?php if(($tick->status)==3){ ?><p style="color:green"><b style="black">Status : </b> Closed </p><?php } ?> 
          <form method="post" autocomplete="off" action="<?=base_url('Ticketresponse/changeticketstatus')?>">
              <input type="text" name="ticketid" value="<?php echo $ticketid;?>" hidden > 
          <div style="display:flex">
              <label class="form-label" for="cars" style="width:170px">Change Status</label>  <select class="form-control" name="status" id="cars">
    <option value="1">..Change Status..</option>
    <option value="2">Temporarly Closed</option>
    <option value="3">Closed</option>
   
  </select>
  <button class="button1 button2" type="submit" style="height:37px;margin-top:-0.3px" >Change</button>
          </div>  
              
          </form>
           <?php if(($tick->status==3)||($tick->status==2)){ ?>   <button id="generatebtn"  type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Generate Bill</button> <?php } ?>
       
          </div><!-- /.col -->
         
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
 <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
            <h3>Generate Bill</h3>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          
        </div>
        <div class="modal-body">
        <form method="post" autocomplete="off" onsubmit="submitForm(event)" action="<?=base_url('Staff/generatebill')?>">
            <h5>Contact Details</h5>
         <table>
             <tbody>
                 <tr><td><b>Customer Name</b></td>
                 <td> <input type="text" value="<?php echo $tick->customername ?>" name="customername" class="form-control" id="tickidnum" aria-describedby="emailHelp" style="background-color: rgba(255,255,255,0.5);border-radius: 5px 0px 0px 5px;height:35px" ></td></tr>
             <tr><td><b>Customer Contact</b></td>
                 <td> <input type="text" value="<?php echo $tick->phone ?>" name="cphone" class="form-control" id="tickidnum" aria-describedby="emailHelp" style="background-color: rgba(255,255,255,0.5);border-radius: 5px 0px 0px 5px;height:35px" ></td></tr>
              <tr><td><b>Engineer Name</b></td>
                 <td> <input type="text" value="<?php  echo $udata['username'] ?>" name="engineer" class="form-control" id="tickidnum" aria-describedby="emailHelp" style="background-color: rgba(255,255,255,0.5);border-radius: 5px 0px 0px 5px;height:35px" ></td></tr>
              <tr><td><b>Engineer Contact</b></td>
                 <td> <input type="text" value="<?php  echo $udata['phone'] ?>" name="ephone" class="form-control" id="tickidnum" aria-describedby="emailHelp" style="background-color: rgba(255,255,255,0.5);border-radius: 5px 0px 0px 5px;height:35px" ></td></tr>
             </tbody>
         </table>     
          <h5>Work Details</h5>
         <table>
             <tbody>
                 <tr><td><b>Ticket Id</b></td>
                 <td> <input type="text" value="<?php echo $tick->id ?>" name="tickid" class="form-control" id="tickidnum" aria-describedby="emailHelp" style="background-color: rgba(255,255,255,0.5);border-radius: 5px 0px 0px 5px;height:35px" ></td></tr>
             <tr><td><b>Item</b></td>
                 <td> <input type="text" value="<?php echo $tick->item ?>" name="item" class="form-control" id="tickidnum" aria-describedby="emailHelp" style="background-color: rgba(255,255,255,0.5);border-radius: 5px 0px 0px 5px;height:35px" ></td></tr>
             <tr><td><b>Model</b></td>
                 <td> <input type="text" value="<?php echo $tick->model ?>" name="model" class="form-control" id="tickidnum" aria-describedby="emailHelp" style="background-color: rgba(255,255,255,0.5);border-radius: 5px 0px 0px 5px;height:35px" ></td></tr>
              <tr><td><b>Brand</b></td>
                 <td> <input type="text" value="<?php echo $tick->brand ?>" name="brand" class="form-control" id="tickidnum" aria-describedby="emailHelp" style="background-color: rgba(255,255,255,0.5);border-radius: 5px 0px 0px 5px;height:35px" ></td></tr>
              <tr><td><b>Customer Complaint</b></td>
                 <td> <textarea  rows="4" cols="50" type="text"  name="rqr" class="form-control" id="tickidnum" aria-describedby="emailHelp" style="background-color: rgba(255,255,255,0.5);border-radius: 5px 0px 0px 5px;height:35px" ><?php echo $tick->rqr ?></textarea></td></tr>
             <tr><td><b>Actual Complaint</b></td>
                 <td>  <textarea  rows="4" cols="50" type="text" placeholder="Actual Complaint" name="complaint" class="form-control" id="tickidnum" aria-describedby="emailHelp" style="background-color: rgba(255,255,255,0.5);border-radius: 5px 0px 0px 5px;height:35px" ></textarea></td></tr>
              <tr><td><b>Work Done</b></td>
                 <td>  <textarea  rows="4" cols="50" type="text" placeholder="Work Done" name="work" class="form-control" id="tickidnum" aria-describedby="emailHelp" style="background-color: rgba(255,255,255,0.5);border-radius: 5px 0px 0px 5px;height:35px" ></textarea></td></tr>
              <tr><td><b>Additional Note</b></td>
                 <td>  <textarea  rows="4" cols="50" type="text" placeholder="Additional Note " name="note" class="form-control" id="tickidnum" aria-describedby="emailHelp" style="background-color: rgba(255,255,255,0.5);border-radius: 5px 0px 0px 5px;height:35px" ></textarea></td></tr>
      </tbody>
         </table> 
            <h5>Payment Details</h5>
         <table>
             <tbody>
                        <tr><td><b>Payment Done By</b></td>
                 <td>  <select class="form-control" name="paymentby" id="cars">
    <option value="By Cash">By Cash</option>
    <option value="UPI Payment">UPI Payment</option>
 </select></td></tr>
 <tr><td><b>Amount to be Paid</b></td>
                 <td><div style="display:flex;flex-direction:row">₹<input type="text" placeholder="Amount to be Paid" name="amount" class="form-control" id="tickidnum" aria-describedby="emailHelp" style="background-color: rgba(255,255,255,0.5);border-radius: 5px 0px 0px 5px;height:35px" ></div></td></tr>
     
          <tr><td><b>Payment Status</b></td>
                 <td> <select class="form-control" name="paystatus" id="cars">
    <option value="1">Completed</option>
    <option value="0">Payment Not Done</option>
 </select></td></tr>
                
             </tbody>
         </table>
       <button  class="button1" type="submit" >Generate Bill</button> 
       
          </form>
        </div>
        <div class="modal-footer">
         
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
    
  </div>
    <!-- Main content -->
    <div class="content">
      
      <div class="container-fluid">
      
     
           
          <script>
function myFunction1() {
  var x = document.getElementById("cus");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}
function myFunction2() {
  var x = document.getElementById("ite");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}

</script>
           

             
             
      
   
               
                  <table id="cus" style="display:none">
                      <tbody>
                          <tr>
                              <td><b>CustomerName : </b><?php echo $tick->customername;?></td> 
                              <td><b>Contact : </b><?php echo $tick->phone;?></td>
                              <td><b>Email : </b><?php echo $tick->email;?></td>
                          </tr>
                          <tr> <td colspan="3"><b>Address : </b><?php echo $tick->address;?></td></tr>
                      </tbody>
                      <br>
                
                  </table>
                  
                   <table id="ite" style="display:none">
                      <tbody>
                          <tr>
                              <td><b>Item : </b><?php echo $tick->item;?></td> 
                              <td><b>Model : </b><?php echo $tick->model;?></td>
                              <td><b>Brand : </b><?php echo $tick->brand;?></td>
                          </tr>
                        <tr> <td colspan="3"><b>Product Detail : </b><?php echo $tick->prodetail;?></td></tr>
                      </tbody>
                  </table> 
               
                  
         
          </div>
 <div class="container-fluid" style="border:1px solid grey">
        <div class="row"> 
        <label><h2>Chat</h2></label>
        <div style="display:flex;flex-directon:row"><p><b>Complaint :</b><?php echo $tick->rqr;?></p><p style="margin-left:10px"><b>Remark : </b><?php echo $tick->remark;?></p></div>
          <div class="col">
              <div id="overflowC">
                   
                 <?php $udata = $this->session->userdata('UserLoginSession');
    $sender= $udata['userid']; foreach($mess->result() as $row){ if($sender!=$row->sendfromid){ ?>
    <div class="container1">
  <label><?php echo $row->sendfromname;?></label>
  <p><?php echo $row->message;?></p>
  <span class="time-right"><?php echo $row->date.' '.$row->time;?></span>
</div><?php }else{ ?>
<div class="container1">
  <label class="right" >You</label>
  <p><?php echo $row->message;?></p>
  <span class="time-right"><?php echo $row->date.' '.$row->time;?></span>
</div><?php } } ?>  
              </div>
        
               <div id="res">
                  
          <form method="post" autocomplete="off" action="<?=base_url('Ticketresponse/inputmess')?>">
               <input type="text" name="sendtoid" value="<?php echo $tick->customerid;?>" hidden >
               <input type="text" name="sendtoname" value="<?php echo $tick->customername;?>" hidden >
               <input type="text" name="sendfromid" value="<?php echo $tick->staffid;?>" hidden >
               <input type="text" name="sendfromname" value="<?php echo $tick->staff;?>" hidden >
               <input type="text" name="tickid" value="<?php echo $tick->id;?>" hidden >
        <div style="display:flex;flex-direction:row"><input type="text" placeholder="Enter You Response" name="message" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" style="background-color: rgba(255,255,255,0.5);border-radius: 5px 0px 0px 5px;border-color:transparent;height:35px" ><button class="button1" type="submit" >Send</button></div>  
          </form>
          
               </div>
          
          </div><!-- /.col -->
         
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
        
        </div>
        <!-- /.row -->
        
      </div><!-- /.container-fluid -->
 
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
    <div class="p-3">
      <h5>Title</h5>
      <p>Sidebar content</p>
    </div>
  </aside>
  <!-- /.control-sidebar -->

  <!-- Main Footer -->
  <footer class="main-footer"style="font-size:8px;margin-left:90%">
    <!-- To the right -->
    
    <!-- Default to the left -->
    <strong>Copyright &copy; 2014-2021 <a href="https://adminlte.io">AdminLTE.io</a>.</strong> All rights reserved.
  </footer>
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->

<!-- jQuery -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.3/jquery.min.js"></script>
  <!-- Bootstrap 3.3.6 -->
 
  <!-- AdminLTE App -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/admin-lte/2.3.11/js/app.min.js"></script>
<script src="<?base_url()?>plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?base_url()?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="<?base_url()?>dist/js/adminlte.min.js"></script>
</body>
</html>
