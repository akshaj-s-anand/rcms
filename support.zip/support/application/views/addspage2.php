<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Solar Section Page2 </title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<div class="m-4">
    <h4>Add Solar Section Page2</h4>
    
    
    
    
    
    
     <div class="w3-half" style="margin-top:10%;margin-left:10%;">
                 <form role="form" method="post" action="<?=base_url('Welcome/addimage34')?>" enctype="multipart/form-data">
                     <?php foreach($image8->result() as $row){ ?>
                      <input type="hidden"  value="<?php echo $row->image; ?>" name="old" class="form-control" id="old"> <?php } ?> 
              <div class="panel">
                <div class="panel-body">
                  <div class="dsp form-group">
                <label>CHOOSE FOR FIRST  IMAGE OF PAGE2</label>
                <input class="form-control" type="file" name="image34" />
            </div>
     
             <div class="dsp form-group">
                <input type="submit" class="btn btn-warning" name="membersubmit34" value="Submit">
            </div>
        </div>
    </div>
</form>
           

               
                
          </div>
          
          
          
          
           <div class="w3-half" style="margin-top:10%;margin-left:10%;">
                 <form role="form" method="post" action="<?=base_url('Welcome/addimage35')?>" enctype="multipart/form-data">
                     <?php foreach($image8->result() as $row){ ?>
                      <input type="hidden"  value="<?php echo $row->image2; ?>" name="old" class="form-control" id="old"> <?php } ?> 
              <div class="panel">
                <div class="panel-body">
                  <div class="dsp form-group">
                <label>CHOOSE FOR SECOND  IMAGE OF PAGE2</label>
                <input class="form-control" type="file" name="image35" />
            </div>
     
             <div class="dsp form-group">
                <input type="submit" class="btn btn-warning" name="membersubmit35" value="Submit">
            </div>
        </div>
    </div>
</form>
           

               
                
          </div>
          
          
          
          
          
          
           <div class="w3-half" style="margin-top:10%;margin-left:10%;">
                 <form role="form" method="post" action="<?=base_url('Welcome/addimage36')?>" enctype="multipart/form-data">
                     <?php foreach($image8->result() as $row){ ?>
                      <input type="hidden"  value="<?php echo $row->image3; ?>" name="old" class="form-control" id="old"> <?php } ?> 
              <div class="panel">
                <div class="panel-body">
                  <div class="dsp form-group">
                <label>CHOOSE FOR THIRD  IMAGE OF PAGE2</label>
                <input class="form-control" type="file" name="image36" />
            </div>
     
             <div class="dsp form-group">
                <input type="submit" class="btn btn-warning" name="membersubmit36" value="Submit">
            </div>
        </div>
    </div>
</form>
           

               
                
          </div>
          
          
          
         
    <form method="post" action="<?=base_url()?>Welcome/addSliderHome15" enctype="multipart/form-data">
       
        
        <div class="mb-3">
            <label class="form-label" for="inputPassword">Add 1st Product's Name</label>
            <input type="text" class="form-control" name="tit1" id="inputPassword" placeholder="Title 1" required>
        </div>
        
     
        
         <div class="mb-3">
            <label class="form-label" for="inputPassword">Add 2nd Product's Name</label>
            <input type="text" class="form-control" name="tit2" id="inputPassword" placeholder="Title 1" required>
        </div>
        
       
        
        
         <div class="mb-3">
            <label class="form-label" for="inputPassword">Add 3rd Product's Name</label>
            <input type="text" class="form-control" name="tit3" id="inputPassword" placeholder="Title 1" required>
        </div>
        
        
       
        
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>
</body>
</html>