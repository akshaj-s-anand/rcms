<!DOCTYPE html>
<html lang="en">
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>Orion Technologies | Best inverter with battery and solar panels in Calicut, Kerala</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- bootstrap css -->
      <link rel="stylesheet" href="<?=base_url()?>css/bootstrap.min.css">
      <!-- style css -->
      <link rel="stylesheet" href="<?=base_url()?>css/style.css">
      <!-- Responsive-->
      <link rel="stylesheet" href="<?=base_url()?>css/responsive.css">
      <!-- fevicon -->
      <link rel="icon" href="<?=base_url()?>images/fevicon.png" type="image/gif" />
      <!-- Scrollbar Custom CSS -->
      <link rel="stylesheet" href="<?=base_url()?>css/jquery.mCustomScrollbar.min.css">
      <!-- Tweaks for older IEs-->
      <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
   
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
      <style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  min-width:auto;

}
.button1 {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 5px 20px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  transition-duration: 0.4s;
  cursor: pointer;
}

.button2 {
  background-color: white; 
  color: black; 
  border: 2px solid #007FFF;
}

.button2:hover {
  background-color: #007FFF;
  color: white;
}
.topnav {
  overflow: hidden;
  background-color: white;
  color:black;
  width:800px;
 
}

.topnav a {
  float: left;
  display: block;
  color: #B10003;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
 
  color: #DD0004 ;
}

.topnav a.active {
 
  color: black;
}

.topnav .icon {
  display: none;
}

@media screen and (max-width: 600px) {
    .topnav {
width:100%;

}
  .topnav a:not(:first-child) {display: none;}
  .topnav a.icon {
    float: right;
    display: block;
  }
 a.complaintbar{
      display:block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative; height:550px;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
}




.ourproject{
	padding: 100px 0;
}

.project-single{
	position: relative;
	margin-bottom: 30px;	
}

.project-overlay{
	position: absolute;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	background: rgba(0,0,0,0.33);
	padding: 30px;
}

.project-overlay h3{
	color: #fff;
	font-size: 18px;
	font-weight: 500;
	font-family: 'Montserrat', sans-serif;
}

.project-overlay p{
	color: #fff;
	font-size: 14px;
	font-weight: 300;
	margin-bottom: 8px;
}

.completed-project{
	position: relative;
	background: url(../images/solara.jpg) no-repeat center center;
	background-size: cover;
	padding: 100px 0 80px;
}

.completed-project:before{
	content: '';
	display: block;
	position: absolute;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	background: rgba(15,36,64,0.84);
}

.completed-title{
	margin-bottom: 60px;
	text-align: center;
}

.completed-title h2{
	font-size: 34px;
	color: #fff;
	text-transform: uppercase;
}

.completed-single{
	text-align: center;
}

.completed-single h3{
	color: #fff;
	font-size: 50px;
	font-family: 'Montserrat', sans-serif;
	margin-bottom: 0;
}

.completed-single p{
	color: #fff;
	font-size: 20px;
}

/*  Request Contact Form area css  */

.request-callback{
	padding: 100px 0;
}

.request-form .form-group{
	margin-bottom: 30px;
}

.request-form .form-control{
	border: none;
	box-shadow: none;
	background: #e7e4e4;
	border-radius: 0;
	height: auto;
	padding: 12px 20px;
}

.btn-request{
	display: block;
	background: #0f2440;	
	color: #fff;
	border: none;
	width: 100%;
	text-transform: uppercase;
	font-weight: 300;
	padding: 12px;
	font-size: 14px;
	letter-spacing: 0.1em;
	transition: all 0.3s;
}

.btn-request:hover{
	background: #000;
}

.contact-information{
	background: #223a5a;
	padding: 30px 0;
}

.contact-single{
	text-align: center;
}

.contact-single p{
	color: #fff;
	font-size: 20px;
	font-weight: 300;
	margin-bottom: 0;
}

.contact-single i{
	margin-right: 10px;
}



.container1 {
  position: relative;
  text-align: center;
  color: white;
}


.centered {
  position: absolute;
 
  left: 50%;
  transform: translate(-50%, -110%);
}
.button28 {
  background-color: #f4511e;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;

  cursor: pointer;
  width:100%;
  -webkit-transition-duration: 0.4s; /* Safari */
transition: all 0.5s ease;
}



.button24:hover {
  box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24),0 17px 50px 0 rgba(0,0,0,0.19);
  margin-left:10px;
 
}
.serv {
 
  border: none;
  color: white;
  padding: 15px 32px;
   text-align: justify;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;

  cursor: pointer;
 
  -webkit-transition-duration: 0.4s; /* Safari */
transition: all 0.5s ease;
}



.serv:hover {
  box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24),0 17px 50px 0 rgba(0,0,0,0.19);
 
 
}
.column2 {
  float: left;
  width: 50%;
  padding: 0 10px;
    margin-bottom: 40px;
}


/* Remove extra left and right margins, due to padding */
.row2 {margin: 0 -5px;}

/* Clear floats after the columns */
.row2:after {
  content: "";
  display: table;
  clear: both;
  margin-left:20px;
}
 #servpara{
    
 line-height: 1.7;
 color:white;
 margin:10px;
 font-size:18px;
 font-family: "Times New Roman", Times, serif;
}
/* Responsive columns */
@media screen and (max-width: 600px) {
  .column2 {
    width: 100%;
    display: block;
    margin-bottom: 40px;

  }
  #servpara{
      font-size:15px;
       line-height: 1.6;
     height: 600px;
     text-align:justify;
  overflow: hidden ;
}
}

/* Style the counter cards */
.card2 {
 
  padding: 16px;
  text-align: center;
   margin-bottom: 20px;
margin-left:5px;
}
@import url(https://fonts.googleapis.com/css?family=Open+Sans);




.container454{
  width:50%;
  min-width:300px;
  min-height:350px;
  margin:0 auto;
  position:relative;
  padding-bottom:30px;
  overflow:hidden;
    background-color:#ec1c25;
  background-size:cover;
}


input[type="radio"] {
position: absolute;
width: 1px; /* Setting this to 0 make it invisible for VoiceOver */
height: 1px; /* Setting this to 0 make it invisible for VoiceOver */
padding: 0;
margin: -1px;
border: 0;
clip: rect(0 0 0 0);
overflow: hidden;
}
label{
  display:block;
  width:32%;
  border: 4px solid white;
  position:absolute;
  bottom:5px;
  cursor: pointer;
  transition: border-color 0.3s linear;
}

label.second{
  left:34%;
}
label.third{
  left:68%;
}

blockquote{
  margin:0;
  padding:30px;
  width:100%;
  min-height:250px;
  background-color: #ec1c25;
  color:white;
  box-shadow: 0 5px 2px rgba(0,0,0,0.1);
  position:relative;
  transition: background-color 0.6s linear;
}

blockquote:after { 
  content: " "; 
  height: 0; 
  width: 0; 
  position: absolute; 
  top: 100%; 
  border: solid transparent; 
  border-top-color: rgba(255,255,255,0.5);
  border-left-color:rgba(255,255,255,0.5);
  border-width: 10px; 
  left: 10%; 
} 
#second:checked ~ .two blockquote {
  background-color:#ec1c25;
}
.two blockquote:after{
  border: solid transparent; 
  border-top-color: rgba(255,255,255,0.5);
  border-left-color:rgba(255,255,255,0.5);
  border-width: 10px;
}
#third:checked ~ .three blockquote{
 background-color:#ec1c25;
}
.three blockquote:after{
  border: solid transparent; 
  border-top-color: rgba(255,255,255,0.5);
  border-left-color: rgba(255,255,255,0.5);
  border-width: 10px;
}
.quotes{
  position:absolute;
  color:rgba(255,255,255,0.5);
  font-size:5em;
}
.leftq{
  top:-25px;
  left:5px;
}
.rightq{
  bottom:-10px;
  right:5px;
}

.slide1{
  position:absolute;
  left:-100%;
  opacity:0;
  transition: all 0.6s ease-in;
}

#first:checked ~ label.first {
  border-width:6px;
  border-color:white;
}
#second:checked ~ label.second {
  border-width:6px;   border-color:white;
}
#third:checked ~ label.third {
  border:6px solid rgba(255,255,255,0.5);
    border-color:white;
}

#first:checked ~ div.one {
  left:0;
  opacity:1;
}
#second:checked ~ div.two {
  left:0;
  opacity:1;
}
#third:checked ~ div.three {
  left:0;
  opacity:1;
}

</style>

<style>
.checked {
  color: orange;
}
</style>
   </head>
   <!-- body -->
   <body class="main-layout">
      <!-- loader  -->
      
      <!-- end loader --> 
      <!-- header -->
      <header>
         <!-- header inner -->
         <div class="header"  style="	box-shadow: 0 5px 5px -5px #333;">
         <div class="container"  style="	box-shadow: 0 5px 5px -5px #333;">
            <div class="row">
               <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
                  <div class="full">
                     <div class="center-desk">
                        <div class="logo"> <a href=""><img src="../images/logo-2.png" alt="logo"/></a> </div>
                     </div>
                  </div>
               </div>
               <div class="col-xl-7 col-lg-7 col-md-9 col-sm-9">
                 




<div class="topnav" id="myTopnav">
   <a class="active" href="#home">Home</a>
  <a href="<?=base_url('Login_Registration/about')?>">About</a>
  <a href="<?=base_url('Welcome/services')?>">Services</a>
  <a href="<?=base_url('Welcome/selectpro')?>">Products</a>
  <a href="<?=base_url('Login_Registration/blog')?>">Brand</a>
  <a href="<?=base_url('Login_Registration/contact')?>">Contact</a>
   
 
      <a class="dropdown-toggle"  data-toggle="dropdown" href="#">Complaint</a>
      <div class="dropdown-menu" style="background-color:white;">
        <a class="dropdown-item" href="<?=base_url('Customer/complaint')?>">Register Complaint</a>
         <a href="#" class="dropdown-item" data-toggle="modal" data-target="#myModal">View Complaint Status</a>
        </div>
    <a  href="<?=base_url('Login_Registration/login')?>">Login</a>
 

  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars"></i>
  </a>
</div>
               </div>
             
            </div>
         </div>
         <!-- end header inner --> 
      </header>
      <!-- end header -->
       <div class="brand_color" style="background-color:#ec1c25;">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="titlepage">
                        <h2>Livguard</h2>
                    </div>
                </div>
            </div>
        </div>

    </div>
      <!-- our product -->
      <div class="product">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <div class="title">
                     
                     <span>Livguard</span>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="product-bg">
         <div class="product-bg-white">
         <div class="container">
            <div class="row">
                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
                  <div class="product-box">
                     <i><img src="../images/3021.jpg"/></i>
                      <h3>LIVGUARD 40 AH SOLAR BATTERY LGTLS4036ST

</h3>


<span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star"></span>
<span class="fa fa-star"></span><br>
                     <span>Read More</span>
                  </div>
               </div>
               <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
                  <div class="product-box">
                     <i><img src="../images/3022.jpg"/></i>
                      <h3>LIVGUARD 75 AH SOLAR BATTERY LGTLS7536ST


</h3>

<span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star"></span>
<span class="fa fa-star"></span><br>
                     <span>Read More</span>
                  </div>
               </div>
               <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
                  <div class="product-box">
                     <i><img src="../images/3023.jpg"/></i>
                      <h3>LIVGUARD INVERTER LG700



</h3>

<span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star"></span>
<span class="fa fa-star"></span><br>
                     <span>Read More</span>
                  </div>
               </div>
               <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
                  <div class="product-box">
                     <i><img src="../images/3024.jpg"/></i>
                      <h3>LIVGUARD INVERTER LGS1100

</h3>

<span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star"></span>
<span class="fa fa-star"></span><br>
                     <span>Read More</span>
                  </div>
               </div>
               
                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
                  <div class="product-box">
                     <i><img src="../images/3025.jpg"/></i>
                      <h3>LIVGUARD INVERTER LGS1700


</h3>

<span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star"></span>
<span class="fa fa-star"></span><br>
                     <span>Read More</span>
                  </div>
               </div>
               
               
                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
                  <div class="product-box">
                     <i><img src="../images/3026.jpg"/></i>
                      <h3>LIVGUARD INVERTER LGS2300



</h3>

<span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star"></span>
<span class="fa fa-star"></span><br>
                     <span>Read More</span>
                  </div>
               </div>
               
               
               
                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
                  <div class="product-box">
                     <i><img src="../images/3027.jpg"/></i>
                      <h3>LIVGUARD INVERTER LGS3500




</h3>

<span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star"></span>
<span class="fa fa-star"></span><br>
                     <span>Read More</span>
                  </div>
               </div>
               
               
               
                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
                  <div class="product-box">
                     <i><img src="../images/3028.jpg"/></i>
                      <h3>LIVGUARD INVERTER LGS5000




</h3>

<span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star"></span>
<span class="fa fa-star"></span><br>
                     <span>Read More</span>
                  </div>
               </div>
               
               
               
                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
                  <div class="product-box">
                     <i><img src="../images/3029.jpg"/></i>
                      <h3>LIVGUARD INVERTER LGS900




</h3>

<span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star"></span>
<span class="fa fa-star"></span><br>
                     <span>Read More</span>
                  </div>
               </div>
               
               
               
                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
                  <div class="product-box">
                     <i><img src="../images/3030.jpg"/></i>
                      <h3>LIVGUARD SOLAR INVERTER LS0G3500




</h3>

<span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star"></span>
<span class="fa fa-star"></span><br>
                     <span>Read More</span>
                  </div>
               </div>
               
               
               
                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
                  <div class="product-box">
                     <i><img src="../images/3031.jpg"/></i>
                      <h3>LIVGUARD SOLAR INVERTER LSOG1150





</h3>

<span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star"></span>
<span class="fa fa-star"></span><br>
                     <span>Read More</span>
                  </div>
               </div>
               
               
               
                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
                  <div class="product-box">
                     <i><img src="../images/3032.jpg"/></i>
                      <h3>LIVGUARD SOLAR INVERTER LSOG1850





</h3>

<span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star"></span>
<span class="fa fa-star"></span><br>
                     <span>Read More</span>
                  </div>
               </div>
               

              
               </div>
            </div>
         </div>
         
         
          <a style=" background-color:white;
  color:black;
  border-color:#f44336;
  padding: 14px 25px;
  text-align: center;
  text-decoration: none;
  display: inline-block;border-style: solid;margin-left:40%;" href="<?=base_url('Welcome/liv')?>" target="_blank">1</a>
  
  
  
   <a style=" background-color:white;
  color:black;
  border-color:#f44336;
  padding: 14px 25px;
  text-align: center;
  text-decoration: none;
  display: inline-block;border-style: solid;" href="<?=base_url('Welcome/liv2')?>" target="_blank">2</a>
         
         
         
          <a style=" background-color: #f44336;
  color:black;
  border-color:#f44336;
  padding: 14px 25px;
  text-align: center;
  text-decoration: none;
  display: inline-block;border-style: solid;" href="<?=base_url('Welcome/liv3')?>" target="_blank">3</a>
  
   <a style=" background-color: white;
  color:black;
  border-color:#f44336;
  padding: 14px 25px;
  text-align: center;
  text-decoration: none;
  display: inline-block;border-style: solid;" href="<?=base_url('Welcome/liv4')?>" target="_blank">4</a>
         
         
         
         
        
         
      <!--  footer --> 
      <footr>
         <div class="footer">
            <div class="container">
               <div class="row">
                  <div class="col-md-6 offset-md-3">
                     <ul class="sociel">
                         <li> <a href="#"><i class="fa fa-facebook-f"></i></a></li>
                         <li> <a href="#"><i class="fa fa-twitter"></i></a></li>
                         <li> <a href="#"><i class="fa fa-instagram"></i></a></li>
                         <li> <a href="#"><i class="fa fa-instagram"></i></a></li>
                     </ul>
                  </div>
            </div>
            <div class="row">
               <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
                  <div class="contact">
                     <h3>conatct us</h3>
                     <span>Building No. 44/3014, Kuniyilkave Road<br/> Ashokapuram, Calicut-673006<br>
                        Mob : +91 9447385870</span>
                  </div>
               </div>
                 <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
                  <div class="contact">
                     <h3>ADDITIONAL LINKS</h3>
                     <ul class="lik">
                         <li> <a href="#">About us</a></li>
                         <li> <a href="#">Terms and conditions</a></li>
                         <li> <a href="#">Privacy policy</a></li>
                         <li> <a href="#">News</a></li>
                          <li> <a href="#">Contact us</a></li>
                     </ul>
                  </div>
               </div>
                 <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
                  <div class="contact">
                     <h3>service</h3>
                      <ul class="lik">
                    <li> <a href="#"> Data recovery</a></li>
                         <li> <a href="#">Computer repair</a></li>
                         <li> <a href="#">Mobile service</a></li>
                         <li> <a href="#">Network solutions</a></li>
                          <li> <a href="#">Technical support</a></li>
                  </div>
               </div>
                 <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
                  <div class="contact">
                     <h3>About lighten</h3>
                     <span>Customercare Services  refers to the assistance an organization offers to its customers before or after they buy or use products or services. Customer service includes actions such as offering product suggestions, troubleshooting issues and complaints, or responding to general questions.</span>
                  </div>
               </div>
            </div>
         </div>
            <div class="copyright" style=" background-color:#1b1b1b;">
               <p>Copyright 2022 All Right Reserved By <a href="http://evaonline.online/">evaonline</a></p>
            </div>
         
      </div>
      </footr>
      <!-- end footer -->
      <!-- Javascript files--> 
      <script src="js/jquery.min.js"></script> 
      <script src="js/popper.min.js"></script> 
      <script src="js/bootstrap.bundle.min.js"></script> 
      <script src="js/jquery-3.0.0.min.js"></script> 
      <script src="js/plugin.js"></script> 
      <!-- sidebar --> 
      <script src="js/jquery.mCustomScrollbar.concat.min.js"></script> 
      <script src="js/custom.js"></script>
      <script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
      <script>
         $(document).ready(function(){
         $(".fancybox").fancybox({
         openEffect: "none",
         closeEffect: "none"
         });
         
         $(".zoom").hover(function(){
         
         $(this).addClass('transition');
         }, function(){
         
         $(this).removeClass('transition');
         });
         });
         
      </script> 
      
      <script>
function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}
</script>
      <!-- end footer -->
      <!-- Javascript files--> 
      <script src="js/jquery.min.js"></script> 
      <script src="js/popper.min.js"></script> 
      <script src="js/bootstrap.bundle.min.js"></script> 
      <script src="js/jquery-3.0.0.min.js"></script> 
      <script src="js/plugin.js"></script> 
      <!-- sidebar --> 
      <script src="js/jquery.mCustomScrollbar.concat.min.js"></script> 
      <script src="js/custom.js"></script>
      <script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
      <script>
         $(document).ready(function(){
         $(".fancybox").fancybox({
         openEffect: "none",
         closeEffect: "none"
         });
         
         $(".zoom").hover(function(){
         
         $(this).addClass('transition');
         }, function(){
         
         $(this).removeClass('transition');
         });
         });
         
      </script> 
   </body>
</html>