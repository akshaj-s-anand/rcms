<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Home Slider</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<div class="m-4">
    <h4>Add Home Slider</h4>
    
    
    
    
    
    
     <div class="w3-half" style="margin-top:10%;margin-left:10%;">
                 <form role="form" method="post" action="<?=base_url('Welcome/addimage')?>" enctype="multipart/form-data">
                     <?php foreach($image1->result() as $row){ ?>
                      <input type="hidden"  value="<?php echo $row->image; ?>" name="old" class="form-control" id="old"> <?php } ?> 
              <div class="panel">
                <div class="panel-body">
                  <div class="dsp form-group">
                <label>CHOOSE FOR FIRST SLIDE IMAGE</label>
                <input class="form-control" type="file" name="image" />
            </div>
     
             <div class="dsp form-group">
                <input type="submit" class="btn btn-warning" name="membersubmit" value="Submit">
            </div>
        </div>
    </div>
</form>
           

               
                
          </div>
          
          
          
          
           <div class="w3-half" style="margin-top:10%;margin-left:10%;">
                 <form role="form" method="post" action="<?=base_url('Welcome/addimage2')?>" enctype="multipart/form-data">
                     <?php foreach($image1->result() as $row){ ?>
                      <input type="hidden"  value="<?php echo $row->image2; ?>" name="old" class="form-control" id="old"> <?php } ?> 
              <div class="panel">
                <div class="panel-body">
                  <div class="dsp form-group">
                <label>CHOOSE FOR SECOND SLIDE IMAGE</label>
                <input class="form-control" type="file" name="image2" />
            </div>
     
             <div class="dsp form-group">
                <input type="submit" class="btn btn-warning" name="membersubmit2" value="Submit">
            </div>
        </div>
    </div>
</form>
           

               
                
          </div>
          
          
          
          
          
          
           <div class="w3-half" style="margin-top:10%;margin-left:10%;">
                 <form role="form" method="post" action="<?=base_url('Welcome/addimage3')?>" enctype="multipart/form-data">
                     <?php foreach($image1->result() as $row){ ?>
                      <input type="hidden"  value="<?php echo $row->image3; ?>" name="old" class="form-control" id="old"> <?php } ?> 
              <div class="panel">
                <div class="panel-body">
                  <div class="dsp form-group">
                <label>CHOOSE FOR THIRD SLIDE IMAGE</label>
                <input class="form-control" type="file" name="image3" />
            </div>
     
             <div class="dsp form-group">
                <input type="submit" class="btn btn-warning" name="membersubmit3" value="Submit">
            </div>
        </div>
    </div>
</form>
           

               
                
          </div>
    
    
    
    <form method="post" action="<?=base_url()?>Welcome/addSliderHome" enctype="multipart/form-data">
       
        
        <div class="mb-3">
            <label class="form-label" for="inputPassword">Title 1</label>
            <input type="text" class="form-control" name="tit1" id="inputPassword" placeholder="Title 1" required>
        </div>
        
        <div class="mb-3">
            <label class="form-label" for="inputPassword">Sub Title 1</label>
            <input type="text" class="form-control" name="subtit1" id="inputPassword" placeholder="Sub Title 1" required>
        </div>
        
         <div class="mb-3">
            <label class="form-label" for="inputPassword">Title 2</label>
            <input type="text" class="form-control" name="tit2" id="inputPassword" placeholder="Title 1" required>
        </div>
        
        <div class="mb-3">
            <label class="form-label" for="inputPassword">Sub Title 2</label>
            <input type="text" class="form-control" name="subtit2" id="inputPassword" placeholder="Sub Title 1" required>
        </div>
        
        
        
         <div class="mb-3">
            <label class="form-label" for="inputPassword">Title 3</label>
            <input type="text" class="form-control" name="tit3" id="inputPassword" placeholder="Title 1" required>
        </div>
        
        <div class="mb-3">
            <label class="form-label" for="inputPassword">Sub Title 3</label>
            <input type="text" class="form-control" name="subtit3" id="inputPassword" placeholder="Sub Title 1" required>
        </div>
        
      
        
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>
</body>
</html>