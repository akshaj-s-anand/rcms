<!DOCTYPE html>
<html lang="en">
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>Orion Technologies | Best inverter with battery and solar panels in Calicut, Kerala</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- bootstrap css -->
      <link rel="stylesheet" href="<?=base_url()?>css/bootstrap.min.css">
      <!-- style css -->
      <link rel="stylesheet" href="<?=base_url()?>css/style.css">
      <!-- Responsive-->
      <link rel="stylesheet" href="<?=base_url()?>css/responsive.css">
      <!-- fevicon -->
      <link rel="icon" href="<?=base_url()?>images/fevicon.png" type="image/gif" />
      <!-- Scrollbar Custom CSS -->
      <link rel="stylesheet" href="<?=base_url()?>css/jquery.mCustomScrollbar.min.css">
      <!-- Tweaks for older IEs-->
        <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
  <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
   
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script src="https://kit.fontawesome.com/yourcode.js" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
      <style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  min-width:auto;

}
.button1 {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 5px 20px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  transition-duration: 0.4s;
  cursor: pointer;
}

.button2 {
  background-color: white; 
  color: black; 
  border: 2px solid #007FFF;
}

.button2:hover {
  background-color: #007FFF;
  color: white;
}
.topnav {
  overflow: hidden;
  background-color: white;
  color:black;
  width:800px;
 
}

.topnav a {
  float: left;
  display: block;
  color: #B10003;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
 
  color: #DD0004 ;
}

.topnav a.active {
 
  color: black;
}

.topnav .icon {
  display: none;
}

@media screen and (max-width: 600px) {
    .topnav {
width:100%;

}
  .topnav a:not(:first-child) {display: none;}
  .topnav a.icon {
    float: right;
    display: block;
  }
 a.complaintbar{
      display:block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative; height:550px;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
}




.ourproject{
	padding: 100px 0;
}

.project-single{
	position: relative;
	margin-bottom: 30px;	
}

.project-overlay{
	position: absolute;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	background: rgba(0,0,0,0.33);
	padding: 30px;
}

.project-overlay h3{
	color: #fff;
	font-size: 18px;
	font-weight: 500;
	font-family: 'Montserrat', sans-serif;
}

.project-overlay p{
	color: #fff;
	font-size: 14px;
	font-weight: 300;
	margin-bottom: 8px;
}

.completed-project{
	position: relative;
	background: url(../images/solara.jpg) no-repeat center center;
	background-size: cover;
	padding: 100px 0 80px;
}

.completed-project:before{
	content: '';
	display: block;
	position: absolute;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	background: rgba(15,36,64,0.84);
}

.completed-title{
	margin-bottom: 60px;
	text-align: center;
}

.completed-title h2{
	font-size: 34px;
	color: #fff;
	text-transform: uppercase;
}

.completed-single{
	text-align: center;
}

.completed-single h3{
	color: #fff;
	font-size: 50px;
	font-family: 'Montserrat', sans-serif;
	margin-bottom: 0;
}

.completed-single p{
	color: #fff;
	font-size: 20px;
}

/*  Request Contact Form area css  */

.request-callback{
	padding: 100px 0;
}

.request-form .form-group{
	margin-bottom: 30px;
}

.request-form .form-control{
	border: none;
	box-shadow: none;
	background: #e7e4e4;
	border-radius: 0;
	height: auto;
	padding: 12px 20px;
}

.btn-request{
	display: block;
	background: #0f2440;	
	color: #fff;
	border: none;
	width: 100%;
	text-transform: uppercase;
	font-weight: 300;
	padding: 12px;
	font-size: 14px;
	letter-spacing: 0.1em;
	transition: all 0.3s;
}

.btn-request:hover{
	background: #000;
}

.contact-information{
	background: #223a5a;
	padding: 30px 0;
}

.contact-single{
	text-align: center;
}

.contact-single p{
	color: #fff;
	font-size: 20px;
	font-weight: 300;
	margin-bottom: 0;
}

.contact-single i{
	margin-right: 10px;
}



.container1 {
  position: relative;
  text-align: center;
  color: white;
}


.centered {
  position: absolute;
 
  left: 50%;
  transform: translate(-50%, -110%);
}
.button28 {
  background-color: #f4511e;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;

  cursor: pointer;
  width:100%;
  -webkit-transition-duration: 0.4s; /* Safari */
transition: all 0.5s ease;
}



.button24:hover {
  box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24),0 17px 50px 0 rgba(0,0,0,0.19);
  margin-left:10px;
 
}
.serv {
 
  border: none;
  color: white;
  padding: 15px 32px;
   text-align: justify;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;

  cursor: pointer;
 
  -webkit-transition-duration: 0.4s; /* Safari */
transition: all 0.5s ease;
}



.serv:hover {
  box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24),0 17px 50px 0 rgba(0,0,0,0.19);
 
 
}
.column2 {
  float: left;
  width: 50%;
  padding: 0 10px;
    margin-bottom: 40px;
}


/* Remove extra left and right margins, due to padding */
.row2 {margin: 0 -5px;}

/* Clear floats after the columns */
.row2:after {
  content: "";
  display: table;
  clear: both;
  margin-left:20px;
}
 #servpara{
    
 line-height: 1.7;
 color:white;
 margin:10px;
 font-size:18px;
 font-family: "Times New Roman", Times, serif;
}
/* Responsive columns */
#headerclass{
height:80px; 
z-index:9999;
}
.logoloc{
    margin-left:-40%;
}#logoa{
    display:none;
}
/* Responsive columns */
@media screen and (max-width: 600px) {
      #logoa{
    margin-top:-25px;
   display: block;  
}
    .logoloc{
   display: none;
}
    #logodiv{
    display:none;
}
    #headerclass{
 margin-top:-40px;
height:110px;
z-index:9999;
}
  .column2 {
    width: 100%;
    display: block;
    margin-bottom: 40px;

  }
  #servpara{
      font-size:15px;
       line-height: 1.6;
     height: 600px;
     text-align:justify;
  overflow: hidden ;
}
}

/* Style the counter cards */
.card2 {
 
  padding: 16px;
  text-align: center;
   margin-bottom: 20px;
margin-left:5px;
}
@import url(https://fonts.googleapis.com/css?family=Open+Sans);




.container454{
  width:50%;
  min-width:300px;
  min-height:350px;
  margin:0 auto;
  position:relative;
  padding-bottom:30px;
  overflow:hidden;
    background-color:#ec1c25;
  background-size:cover;
}


input[type="radio"] {
position: absolute;
width: 1px; /* Setting this to 0 make it invisible for VoiceOver */
height: 1px; /* Setting this to 0 make it invisible for VoiceOver */
padding: 0;
margin: -1px;
border: 0;
clip: rect(0 0 0 0);
overflow: hidden;
}
label{
  display:block;
  width:32%;
  border: 4px solid white;
  position:absolute;
  bottom:5px;
  cursor: pointer;
  transition: border-color 0.3s linear;
}

label.second{
  left:34%;
}
label.third{
  left:68%;
}

blockquote{
  margin:0;
  padding:30px;
  width:100%;
  min-height:250px;
  background-color: #ec1c25;
  color:white;
  box-shadow: 0 5px 2px rgba(0,0,0,0.1);
  position:relative;
  transition: background-color 0.6s linear;
}

blockquote:after { 
  content: " "; 
  height: 0; 
  width: 0; 
  position: absolute; 
  top: 100%; 
  border: solid transparent; 
  border-top-color: rgba(255,255,255,0.5);
  border-left-color:rgba(255,255,255,0.5);
  border-width: 10px; 
  left: 10%; 
} 
#second:checked ~ .two blockquote {
  background-color:#ec1c25;
}
.two blockquote:after{
  border: solid transparent; 
  border-top-color: rgba(255,255,255,0.5);
  border-left-color:rgba(255,255,255,0.5);
  border-width: 10px;
}
#third:checked ~ .three blockquote{
 background-color:#ec1c25;
}
.three blockquote:after{
  border: solid transparent; 
  border-top-color: rgba(255,255,255,0.5);
  border-left-color: rgba(255,255,255,0.5);
  border-width: 10px;
}
.quotes{
  position:absolute;
  color:rgba(255,255,255,0.5);
  font-size:5em;
}
.leftq{
  top:-25px;
  left:5px;
}
.rightq{
  bottom:-10px;
  right:5px;
}

.slide1{
  position:absolute;
  left:-100%;
  opacity:0;
  transition: all 0.6s ease-in;
}

#first:checked ~ label.first {
  border-width:6px;
  border-color:white;
}
#second:checked ~ label.second {
  border-width:6px;   border-color:white;
}
#third:checked ~ label.third {
  border:6px solid rgba(255,255,255,0.5);
    border-color:white;
}

#first:checked ~ div.one {
  left:0;
  opacity:1;
}
#second:checked ~ div.two {
  left:0;
  opacity:1;
}
#third:checked ~ div.three {
  left:0;
  opacity:1;
}
.itemcard {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 250px;
  background-color:white;
  
  margin: auto;
  text-align: center;
  font-family: arial;
}
.itemcard:hover {
 box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24),0 17px 50px 0 rgba(0,0,0,0.19);
 
}

.price1 {
  color: grey;
  font-size: 22px;
}

.itemcard button {
  border: none;
  outline: 0;
  padding: 12px;
  color: white;
 background-color: #ec1c25;
  text-align: center;
  cursor: pointer;
  width: 100%;
  font-size: 18px;
}

.itemcard button:hover {
  opacity: 0.7;
}
.itemcard h6{
    height:60px;
}
div.test {
 margin-left:5px;
color: red;
  animation: dropdownicon 2s infinite;
 animation-direction: alternate;
}

@keyframes dropdownicon {
  from {color: red;}
  to {color: yellow;}
  
}
.dropdown-item{
    background-color:white;
    color:#DD0004;
}
.dropdown-item:hover{
    background-color: #ec1c25;
    color:white;
}
</style>
   </head>
   <!-- body -->
   <body class="main-layout">
      <!-- loader  -->
      
      <!-- end loader --> 
      <!-- header -->
      <header>
         <!-- header inner -->
         <div class="header" id="headerclass"  >
         <div class="container" >
            <div class="row">
               <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section" id="logodiv">
                  <div class="full">
                     <div class="center-desk logoloc">
                        <div class="logo" style="margin-top:10px"> <a href=""><img src="../images/logo-2.png" alt="logo"/></a> </div>
                     </div>
                  </div>
               </div>
               <div class="col-xl-7 col-lg-7 col-md-9 col-sm-9">
                 



<div class="topnav" id="myTopnav" style="z-index:999">
     <a id="logoa" href="<?=base_url()?>"><img src="../images/logo-2.png" alt="logo"/></a>
   <a  href="<?=base_url()?>">Home</a>
  <a href="<?=base_url('Login_Registration/about')?>">About</a>
  <a href="<?=base_url('Welcome/services')?>">Services</a>
 
   
   <a class="active"  data-toggle="modal" data-target="#myModal2" href="#"><div style="display:flex;flex-direction:row">Products<div class="test"><i class='fa fa-caret-down'></i></div> </div></a>
    
 
  <a data-toggle="modal" data-target="#myModal3" href="#"><div style="display:flex;flex-direction:row">Brands<div class="test"><i class='fa fa-caret-down'></i></div> </div></a>
  <a href="<?=base_url('Login_Registration/contact')?>">Contact</a>
   
 
      <a class="dropdown-toggle"  data-toggle="dropdown" href="#">Complaint</a>
      <div class="dropdown-menu" style="background-color:white;z-index:9999">
        <a class="dropdown-item" href="<?=base_url('Customer/complaint')?>">Register Complaint</a>
         <a href="#" class="dropdown-item" data-toggle="modal" data-target="#myModal">View Complaint Status</a>
        </div>
    <a  href="<?=base_url('Login_Registration/login')?>">Login</a>
 

  <a href="javascript:void(0);" class="icon" onclick="myFunction()" >
    <i class="fa fa-bars"></i>
  </a>
</div>
               </div>
             
            </div>
         </div>
         <!-- end header inner --> 
      </header>
      <!-- end header -->
     
      <div class="modal fade" id="myModal3" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
            <h3>Select Product</h3>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          
        </div>
        <div class="modal-body">
         
        <a  class="dropdown-item" href="<?=base_url('Welcome/orion')?>"><img src="../icon/joi.jpg" style="width:100px;height:100px"/>Orion</a>
         <a  class="dropdown-item" href="<?=base_url('Welcome/liv')?>"><img src="../icon/smodelnew.png" style="width:100px;height:100px"/>Liv Guard</a>
           
    
       
        </div>
      
      </div>
      
    </div>
    
  </div>
<div class="modal fade" id="myModal2" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
            <h3>Select Product</h3>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          
        </div>
        <div class="modal-body">
         
        <a  class="dropdown-item" href="<?=base_url('Login_Registration/product')?>"><img src="../icon/bmodel.png" style="width:100px;height:100px"/>Battery</a>
         <a  class="dropdown-item" href="<?=base_url('Welcome/spage1')?>"><img src="../icon/smodelnew.png" style="width:100px;height:100px"/>Solar Products</a>
           <a  class="dropdown-item" href="<?=base_url('Welcome/upage1')?>"><img src="../icon/inmodel.png" style="width:100px;height:100px"/>UPS/Inverter</a>
             <a  class="dropdown-item" href="<?=base_url('Welcome/hpage1')?>"><img src="../icon/wamodel.jpg" style="width:100px;height:100px"/>Solar Water Heaters</a>
    
       
        </div>
      
      </div>
      
    </div>
    
  </div>
 <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
            <h6>Get Your Complaint Status</h6>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          
        </div>
        <div class="modal-body">
        <form method="post" autocomplete="off" onsubmit="submitForm(event)" action="<?=base_url('Ticketresponse/complaintstatus')?>">
         <input value="" id="count" hidden >       
       <input type="text" placeholder="Enter The Complaint Id" name="tickid" class="form-control" id="tickidnum" aria-describedby="emailHelp" style="background-color: rgba(255,255,255,0.5);border-radius: 5px 0px 0px 5px;border-color:transparent;height:35px" >
        <input type="text" placeholder="Your Registered Mobile Number" name="phone" class="form-control"aria-describedby="emailHelp" style="background-color: rgba(255,255,255,0.5);border-radius: 5px 0px 0px 5px;border-color:transparent;height:35px" >
       <button  class="button1" type="submit" >Submit</button> 
       
          </form>
        </div>
        <div class="modal-footer">
             <a style="color:blue" data-toggle="modal" data-target="#myModal1">Forgot Complaint Id?</a>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
    
  </div>
  <div class="modal fade" id="myModal1" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
            <h6>Get Your Complaint Status</h6>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          
        </div>
        <div class="modal-body">
         <form method="post" autocomplete="off" onsubmit="submitForm(event)" action="<?=base_url('Ticketresponse/viewall')?>">
         <input value="" id="count" hidden >       
       <input type="text" placeholder="Your Registered Mobile Number" name="phone" class="form-control"aria-describedby="emailHelp" style="background-color: rgba(255,255,255,0.5);border-radius: 5px 0px 0px 5px;border-color:transparent;height:35px" >
       <button  class="button1" type="submit" >Submit</button> 
       
          </form>
        </div>
        <div class="modal-footer">
            
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
    
  </div>
               </div>
             
            </div>
         </div>
         <!-- end header inner --> 
      </header>
      <!-- end header -->
      
      <!-- our product -->
      <div class="product">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  
                     <span style="color:#7d827e;font-size:12px">Home / Solar Water Heater</span><br>
                     <span style="color:#ec1c25;font-size:30px">Solar Water Heaters </span>
                 
               </div>
            </div>
         </div>
      </div>
      <div >
         <div class="product-bg-white">
         <div class="container">
            <div class="row">
               <?php foreach($p->result() as $row) {$word='Heater';$category = str_replace(' ', '', $row->category); if(($category=='SolarWaterHeater')||(strpos($row->model, $word) !== false)){?> 
               <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12" >
                   <a href="<?php echo base_url('Welcome/viewproduct/'.$row->id)?>">
                        <div class="itemcard ">
  <img src="<? echo base_url()."/images/products/".$row->image; ?>"  style="width:200px;height:160px;margin-top:10px">
  <p style="color:#878787;text-align:left"><?php echo $row->category; ?>/<?php echo $row->brand; ?></p>
  <h6><?php echo $row->model; ?></h6>
  <p class="price1"><span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star"></span><br></p>
 
  <p><button onclick.href="#">Read More</button></p>
</div>
                   </a> 
               </div><?php }} ?>
              
               </div>
            </div>
         </div>
         
         
         
        
      <!--  footer --> 
    <div style="background-image:url(../images/city2.jpg);background-repeat:no-repeat;background-size:cover;width:100%;"  >
             
            <div class="row" style="background: rgba(255,255, 255, 0.96);width:100%;height:100%;margin-left:1px" >
                 <div class="col-sm" id="footer1"  >
                  <div class="contact" >
                     <h3 style="color:black">    <a href=""><img src="../images/logo-2.png" alt="logo"/></a></h3>
                     <span style="color:#878787;font-size:14px;">Do you have any queries or comments about our website, our products or any of our services.?</span>
                       <ul class="sociel">
                         <li> <a style="color:black" href="#"><i class="fa fa-facebook"></i></a></li>
                         <li style="margin-left:-30px"> <a style="color:black" href="#"><i class="fa fa-twitter"></i></a></li>
                         <li style="margin-left:-30px"> <a style="color:black" href="#"><i class="fa fa-instagram"></i></a></li>
                             <li style="margin-left:-30px"> <a style="color:black" href="#"><i class="fa fa-pinterest"></i></a></li>
                              <li style="margin-left:-30px"> <a style="color:black" href="#"><i class="fa fa-linkedin"></i></a></li>
                     </ul>
                     
                  </div>
               </div>
              
                 <div class="col-sm" id="footer2" >
                  <div class="contact">
                     <h3 style="color:#ec1c25;font-weight:700">QUICK LINKS</h3>
                    <ul class="lik">
                         <li> <a style="color:#ec1c25" href="<?=base_url()?>"><i class="fa fa-home"></i>Home</a></li>
                         <li> <a style="color:#ec1c25" href="<?=base_url('Login_Registration/about')?>"><i class="fa fa-tags"></i>About</a></li>
                         <li> <a style="color:#ec1c25" href="<?=base_url('Welcome/services')?>"><i class="material-icons" style="font-size:18px">terrain</i>Services</a></li>
                         <li> <a style="color:#ec1c25" href="<?=base_url('Welcome/selectpro')?>"><i class="fa fa-shopping-cart"></i>Products</a></li>
                       
                     </ul>
                  </div>
                   <div class="row" style="margin-top:-10px">
                         <div class="col"> <p><a href="#"><h5 style="color:#c7c1c1"><i class="fa fa-handshake-o" style="color:red"></i>Orion Power House</h5></a></p></div>
                     </div>
               </div>
               <div class="col-sm" id="footer3" >
                  <div class="contact">
                      <h3 style="color:#ec1c25;font-weight:700">Contact Us</h3>
                      
                    <div class="row">
                         <div class="col"> <table>
                             <tbody>
                                 <tr>
                                     <td><i class="fa fa-address-book" style="color:red"></i></td>
                                     <td style="color:#878787">Building No. 44/3014, Kuniyilkave Road Ashokapuram, Calicut-673006 </td>
                                 </tr>
                                  <tr>
                                     <td><i class="fa fa-mobile-phone" style="color:red"></i></td>
                                     <td style="color:#878787">9447385870 </td>
                                 </tr>
                                  <tr>
                                     <td><i class="fa fa-phone" style="color:red"></i></td>
                                     <td style="color:#878787">0495-2771502</td>
                                 </tr>
                                  <tr>
                                     <td><i class="fa fa-envelope-open" style="color:red"></i></td>
                                     <td style="color:#878787">admin@oriontechnologies.co.in</td>
                                 </tr>
                                  <tr>
                                     <td><i class="fa fa-clock-o" style="color:red"></i></td>
                                     <td style="color:#878787">Open hours: Mon-Sat 9 AM to 7PM</td>
                                 </tr>
                                  <tr>
                                     <td ><i class="material-icons" style="color:red;font-size:18px">watch</i></td>
                                     <td style="color:#878787" >aHappy hours: sat: 2 pm to 4 pm</td>
                                 </tr>
                             </tbody>
                         </table></div>
                     </div>
                        
                   
                        
                  </div>
               </div>
               
                
            </div>
                        <div class="row" style="background: rgba(255,255, 255, 0.96);width:100%;height:100%;margin-left:1px" >
                 <div class="col-sm"  >
                  <div class="contact" >
                    
                     <span style="color:#878787;font-size:14px;">Orion Technologies Copyright ©2022 All rights reserved.</span>
                       
                     
                  </div>
               </div>
              
                  <div class="col-sm"  >
                  <div class="contact" >
                    
                     <span style="color:#878787;font-size:14px;margin-left:50%">Designed by Cpool Digital Learning</span>
                       
                     
                  </div>
               </div>
  
               
                
            </div>
         </div>
      <!-- end footer -->
      <!-- Javascript files--> 
      <script src="js/jquery.min.js"></script> 
      <script src="js/popper.min.js"></script> 
      <script src="js/bootstrap.bundle.min.js"></script> 
      <script src="js/jquery-3.0.0.min.js"></script> 
      <script src="js/plugin.js"></script> 
      <!-- sidebar --> 
      <script src="js/jquery.mCustomScrollbar.concat.min.js"></script> 
      <script src="js/custom.js"></script>
      <script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
      <script>
         $(document).ready(function(){
         $(".fancybox").fancybox({
         openEffect: "none",
         closeEffect: "none"
         });
         
         $(".zoom").hover(function(){
         
         $(this).addClass('transition');
         }, function(){
         
         $(this).removeClass('transition');
         });
         });
         
      </script> 
      
      <script>
function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}
</script>
      <!-- end footer -->
      <!-- Javascript files--> 
      <script src="js/jquery.min.js"></script> 
      <script src="js/popper.min.js"></script> 
      <script src="js/bootstrap.bundle.min.js"></script> 
      <script src="js/jquery-3.0.0.min.js"></script> 
      <script src="js/plugin.js"></script> 
      <!-- sidebar --> 
      <script src="js/jquery.mCustomScrollbar.concat.min.js"></script> 
      <script src="js/custom.js"></script>
      <script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
      <script>
         $(document).ready(function(){
         $(".fancybox").fancybox({
         openEffect: "none",
         closeEffect: "none"
         });
         
         $(".zoom").hover(function(){
         
         $(this).addClass('transition');
         }, function(){
         
         $(this).removeClass('transition');
         });
         });
         
      </script> 
   </body>
</html>