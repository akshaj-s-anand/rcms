<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
	<link rel="stylesheet" type="text/css" href="<?=base_url()?>build/css/demo.css">
	<link rel="stylesheet" type="text/css"  href="<?=base_url()?>build/css/intlTelInput.css">
 	<link rel="stylesheet" href="<?=base_url()?>build/css/intlTelInput.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.3/css/intlTelInput.min.css" rel="stylesheet"/>
<script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.3/js/intlTelInput.min.js"></script>
<a href="<?=base_url('Cforcecontroller/cforceLoginMembers');?>"></a>
    <title>Registration</title>
	<style>
     body{
        
        background-image: 
        linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)),
        url('../images/registration.jpg');
     background-size:cover;
    }
		.passwordbox:focus{
			color:#212529;background-color:#fff;border-color:#86b7fe;outline:0;box-shadow:0 0 0 .25rem rgba(13,110,253,.25)}
      .form-label{
        color:white;
      }
	</style>
  </head>
  <body>

		  <div class="container" style="margin-left:30%;width:50%;height:50%;border-radius:20px">
		  
		    <a class="navbar-brand" style="color: white;margin-left: 25%;font-size: 35px;font-family:'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif;font-weight: bold;" href="#">Welcome </a>
		   
		  </div>

		<div class="container" style="margin-left:32%;width:50%;height:50%;border-radius:20px">
			<div class="row">
			

			<div class="col align-self-center" >
				<div class="card" style="background-color:transparent;margin-top: 30px;border-color:transparent">
					  <div class="card-header text-center" style="color:white;background-color:transparent;border-color:transparent">
						<h3>Register Now</h3>
						Already Registered?<a href="<?=base_url('indexpage#login')?>">Login</a>
					  </div>  
					  	<?php
						if($this->session->flashdata('success')) {	?>
						 <p class="text-success text-center" style="color:white;margin-top: 10px;"> <?=$this->session->flashdata('success')?></p>
						<?php } ?>	
					 <div class="card-body">
					  <form method="POST"  autocomplete="off" action="<?=base_url('Login_Registration/registerNow')?>">
					
					   	<div class="mb-3">
						   <?php
						if($this->session->flashdata('error2')) {	?>
						 <p class="text-success text-center" style="color:white;margin-top: 10px;"> <?=$this->session->flashdata('error2')?></p>
						<?php } ?>
						    <label for="exampleInputEmail1" class="form-label">Company Name</label>
						    <input type="text" placeholder="Company Name" style="border-radius:5px;border-color:transparent;width:357px;height:37px" name="companyname" class="form-control" id="name" aria-describedby="name" required> 
						  </div>
						  
						  <div class="mb-3">
						    <label for="exampleInputEmail1" class="form-label">Email address</label>
						    <input type="email"  placeholder="Email" style="border-radius:5px;border-color:transparent;width:357px;height:37px" name="companymail" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
							<?php
						if($this->session->flashdata('emailerror')) {	?>
						 <p class="text-success text-center" style="color:white;margin-top: 10px;"> <?=$this->session->flashdata('emailerror')?></p>
						<?php } ?>
						</div>
						 
						  <div class="mb-3">
						    <label for="exampleInputEmail1"  class="form-label">Mobile Number</label><br>
						    <input type="tel" style="border-radius:5px;border-color:transparent;width:357px;height:37px" name="companynumber" class="form-control" id="tel"  placeholder="Mobile Number" aria-describedby="name" required>
							<script>
						 var input = document.querySelector("#tel");
    window.intlTelInput(input,({
    }));
	
    $(document).ready(function() {
        $('.iti__flag-container').click(function() { 
          var countryCode = $('.iti__selected-flag').attr('title');
          var countryCode = countryCode.replace(/[^0-9]/g,'')
          $('#tel').val("");
          $('#tel').val("+"+countryCode+" "+ $('#tel').val());
       });
    });
							</script>
						  </div>
						 
						  <div class="mb-3">
						    <label for="exampleInputPassword1" class="form-label">Password</label> <span id="toggle_pwd"class="fa fa-fw fa-eye field_icon" style="color:white;"></span><br>
						    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    				
        					
    						<input type="password" class="passwordbox" name="password_1" placeholder="  Password" style="border-radius:5px;border-color:transparent;width:357px;height:37px"id="exampleInputPassword1" required />
   							
   							 <script type="text/javascript">
								$(function () {
									$("#toggle_pwd").click(function () {
										$(this).toggleClass("fa-eye fa-eye-slash");
									var type = $(this).hasClass("fa-eye-slash") ? "text" : "password";
										$("#exampleInputPassword1").attr("type", type);
									});
								});
							</script>
						  </div>
						  <div class="mb-3">
						    <label for="exampleInputPassword1" class="form-label">Confirm Password</label><span id="toggle_pwd2"class="fa fa-fw fa-eye field_icon"style="color:white;"></span><br>
						    
    						<input type="password" class="passwordbox" name="password_2" placeholder=" Confirm Password" style="border-radius:5px;border-color:transparent;width:357px;height:37px"id="exampleInputPassword2" required />
   							 
   							 <script type="text/javascript">
								$(function () {
									$("#toggle_pwd2").click(function () {
										$(this).toggleClass("fa-eye fa-eye-slash");
									var type = $(this).hasClass("fa-eye-slash") ? "text" : "password";
										$("#exampleInputPassword2").attr("type", type);
									});
								});
							</script>
							<?php
						if($this->session->flashdata('error1')) {	?>
						 <p class="text-success text-center" style="margin-top: 10px;"> <?=$this->session->flashdata('error1')?></p>
						<?php } ?>
						  </div>
						  <div class="mb-3">
						    <label for="exampleInputEmail1" class="form-label">GST Number</label>
						    <input type="text" style="border-radius:5px;border-color:transparent;width:357px;height:37px"  placeholder="GST Number" name="gst" class="form-control" id="name" aria-describedby="exampleInputEmail1">
						  </div>
						  <div class="mb-3">
						    <label for="exampleInputEmail1" class="form-label">Location</label>
						    <input type="text" style="border-radius:5px;border-color:transparent;width:357px;height:37px" placeholder="Location" name="location" class="form-control" id="name" aria-describedby="exampleInputEmail1" required>
						  </div>
						  <div class="mb-3">
						    <label for="exampleInputEmail1" class="form-label">District</label>
						    <input type="text" style="border-radius:5px;border-color:transparent;width:357px;height:37px" placeholder="District" name="district" class="form-control" id="name" aria-describedby="exampleInputEmail1" required>
						  </div>
						  <div class="mb-3">
						    <label for="exampleInputEmail1" class="form-label">State</label>
						    <input type="text" style="border-radius:5px;border-color:transparent;width:357px;height:37px" placeholder="State" name="state" class="form-control" id="name" aria-describedby="exampleInputEmail1" required>
						  </div>
						  <div class="mb-3">
						    <label for="exampleInputEmail1" class="form-label">Country</label>
						    <input type="text" style="border-radius:5px;border-color:transparent;width:357px;height:37px" placeholder="Country" name="country" class="form-control" id="name" aria-describedby="exampleInputEmail1" required>
						  </div>
						  <div class="mb-3">
						    <label for="exampleInputEmail1" class="form-label">Pin Code</label>
						    <input type="text" style="border-radius:5px;border-color:transparent;width:357px;height:37px" placeholder="Pin Code" name="pincode" class="form-control" id="name" aria-describedby="exampleInputEmail1" required>
						  </div>
						 <div class="text-center">
						  <button type="submit" class="btn btn-primary">Register Now</button>
						</div>

						</form>
					  </div>
					</div>
				</div>
				<div class="col-md-4"></div>
			</div>
		</div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>


  </body>
</html>
