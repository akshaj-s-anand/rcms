<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>User Login & Registration</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
	<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"	rel="stylesheet" type="text/css" />
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">

<link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">

<link rel="stylesheet" href="../../plugins/icheck-bootstrap/icheck-bootstrap.min.css">

<link rel="stylesheet" href="../../dist/css/adminlte.min.css">
    
    <style>
      body{
        
            background-image: 
            linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)),
            url('../images/customer.jpg');
         background-size:cover;
        }
	.passwordbox{
		background-color: rgba(255,255,255,0.5);
		border-radius:20px;
		border-color:transparent;
	}
	.passwordbox:focus {
		color:#212529;border-color:#86b7fe;outline:0;box-shadow:0 0 0 .25rem rgba(13,110,253,.25)}
}


      
      </style>
  </head>
  <body>
   <section class="Form my-4 mx-5">
       <div class="container" style=" background-color: rgba(255,255,255,0.5);width:50%;height:50%;border-radius:20px">
           <div class="row">
               <div class="col-lg-5">
               <label  class="form-label"style="font-size: 150%;font-family:'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif;font-weight: bold;">Welcome </label>
</div>
<div class="card-header text-center"style="background-color:transparent;border-color:transparent">
						<h3>Login Now</h3>
						<br>
						New Here?<a href="<?=base_url()?>Login_Registration/nextpage" style="color:blue"> Register</a>
					  </div>
<div class="col align-self-center" >
<form method="post" autocomplete="off" action="<?=base_url('Login_Registration/loginnow')?>">
         <div class="form-row" style="width:100%;margin:auto" >
           
<div class="input-group mb-3">
<input type="email" placeholder="Email" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" style="background-color: rgba(255,255,255,0.5);border-radius: 5px 0px 0px 5px;border-color:transparent;width:50%;height:35px" required>
						
          <div class="input-group-append">
            <div class="input-group-text"style="background-color: rgba(255,255,255,0.5);height:100%;width:90%">
              <span class="fa fa-envelope"></span>
            </div>
          </div>
        </div>
</div>
<div class="form-row" style="width:100%;margin:auto" >
<div class="input-group mb-3">
<input type="password" id="exampleInputPassword1" placeholder="Password" name="password_1" class="form-control"  aria-describedby="emailHelp" style="background-color: rgba(255,255,255,0.5);border-radius: 5px 0px 0px 5px;border-color:transparent;width:50%;height:35px" required>
						
          <div class="input-group-append">
            <div class="input-group-text"style="background-color: rgba(255,255,255,0.5);height:100%;width:90%">
              <span class="fa fa-key"></span>
            </div>
          </div>
        
        </div>
       <div class="input-group-append">
            Show Password <input style="margin-top:5px" type="checkbox" onclick="myFunction()" >
            </div>
</div>
        


         
   	  
                         
<script>
function myFunction() {
  var x = document.getElementById("exampleInputPassword1");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
</script>
                            </div>
</div>
<div class="text-center">
						 <br> <button type="submit" class="btn btn-primary" style="align:center">Login Now</button>
						</div><br>
						<?php
						if($this->session->flashdata('error')) {	?>
						 <p class="text-danger text-center" > <?=$this->session->flashdata('error')?></p>
						<?php } ?>
							<?php
						if($this->session->flashdata('statuserror')) {	?>
						 <p class="text-danger text-center" > <?=$this->session->flashdata('statuserror')?></p>
						<?php } ?>
                        </div>
						</form>
<div>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->
  </body>
</html>