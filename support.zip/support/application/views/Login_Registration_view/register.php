<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
	<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"	rel="stylesheet" type="text/css" />
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">

<link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">

<link rel="stylesheet" href="../../plugins/icheck-bootstrap/icheck-bootstrap.min.css">

<link rel="stylesheet" href="../../dist/css/adminlte.min.css">
    <title>User Login & Registration</title>
    <style>
   
      body{
        min-width:350px;
       
            background-image: 
            linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)),
            url('<?=base_url('images/registration.jpg')?>');
       background-size:cover;
-moz-background-size:cover;
-webkit-background-size:cover;
        background-repeat:no-repeat;
        align-content: center;
        }
	.passwordbox{
		background-color: rgba(255,255,255,0.5);
		border-radius:20px;
		border-color:transparent;
	}
	.passwordbox:focus {
		color:#212529;border-color:#86b7fe;outline:0;box-shadow:0 0 0 .25rem rgba(13,110,253,.25)}
}
.center {
  margin: auto;
  width: 60%;
  border: 3px solid #73AD21;
  padding: 10px;
}

      
      </style>
  </head>
  <body >
   <section class="Form my-4 mx-5 center" >
       <div class="container" style=" background-color: rgba(255,255,255,0.5);width:40%;height:50%;border-radius:20px;min-width:270px; ">
           <div class="row">
           	<?php
						if($this->session->flashdata('registersuccess')) {	?>
						 <p class="text text-center" style="color:green" > <?=$this->session->flashdata('registersuccess')?></p>
						<?php } ?>
<div class="card-header text-center"style="background-color:transparent;border-color:transparent;min-width:250px">
						<h3>Register Now</h3>
						<br>
					
					  </div>
<div class="col align-self-center" style="min-width:150px">
 <form method="POST"  autocomplete="off" action="<?=base_url('Login_Registration/userregistration')?>">
					
					   	<div class="mb-3">
						   <?php
						if($this->session->flashdata('usererror2')) {	?>
						 <p class="text-success text-center" style="color:white;margin-top: 10px;"> <?=$this->session->flashdata('usererror2')?></p>
						<?php } ?>
						    <label for="exampleInputEmail1" class="form-label">Name*</label>
						    <input type="text" placeholder="User Name" style="border-radius:5px;border-color:black;min-width:240px;height:37px" name="username" class="form-control" id="name" aria-describedby="name" required> 
						  </div>
						  <div class="mb-3">
						    <label for="exampleInputEmail1" class="form-label">Email address*</label>
						    <input type="email"  placeholder="Email" style="border-radius:5px;border-color:black;min-width:240px;height:37px" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
							<?php
						if($this->session->flashdata('useremailerror')) {	?>
						 <p class="text-success text-center" style="color:white;margin-top: 10px;"> <?=$this->session->flashdata('useremailerror')?></p>
						<?php } ?>
						</div>
						 
						  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Mobile Number*</label><br>
    <input type="tel" style="border-radius: 5px; border-color: black; min-width: 240px; height: 37px" name="phone" class="form-control" id="tel" placeholder="Mobile Number" aria-describedby="name" required>
</div>

<script>
    document.getElementById('tel').addEventListener('input', function() {
        if (this.value.length > 10) {
            this.value = this.value.slice(0, 10); // Truncate the input to 10 characters
        }
    });
</script>



						 
						  <div class="mb-3">
						    <label for="exampleInputPassword1" class="form-label">Password*</label> <span id="toggle_pwd"class="fa fa-fw fa-eye field_icon" style="color:black;"></span><br>
						    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    				
        					
    						<input type="password" class="passwordbox form-control" name="password_1" placeholder="  Password" style="background-color:white;border-radius:5px;border-color:black;min-width:240px;height:37px"id="exampleInputPassword1" required />
   							
   							 <script type="text/javascript">
								$(function () {
									$("#toggle_pwd").click(function () {
										$(this).toggleClass("fa-eye fa-eye-slash");
									var type = $(this).hasClass("fa-eye-slash") ? "text" : "password";
										$("#exampleInputPassword1").attr("type", type);
									});
								});
							</script>
						  </div>
						  <div class="mb-3">
						    <label for="exampleInputPassword1" class="form-label">Confirm Password*</label><span id="toggle_pwd2"class="fa fa-fw fa-eye field_icon"style="color:black;"></span><br>
						    
    						<input type="password" class="passwordbox form-control" name="password_2" placeholder=" Confirm Password" style="background-color:white;border-radius:5px;border-color:black;min-width:240px;height:37px"id="exampleInputPassword2" required />
   							 
   							 <script type="text/javascript">
								$(function () {
									$("#toggle_pwd2").click(function () {
										$(this).toggleClass("fa-eye fa-eye-slash");
									var type = $(this).hasClass("fa-eye-slash") ? "text" : "password";
										$("#exampleInputPassword2").attr("type", type);
									});
								});
							</script>
							<?php
						if($this->session->flashdata('usererror1')) {	?>
						 <p class="text-success text-center" style="margin-top: 10px;"> <?=$this->session->flashdata('usererror1')?></p>
						<?php } ?>
						  </div>
						  <div class="mb-3">
						    <label for="exampleInputEmail1" class="form-label">Address</label>
						   <textarea class="form-control" id="address" name="address" rows="4" cols="50" placeholder="Your Address"></textarea>
						  </div>
						  
						  <div class="mb-3">
						    <label for="exampleInputEmail1" class="form-label">Pin Code*</label>
						    <input type="text" style="border-radius:5px;border-color:black;min-width:240px;height:37px" placeholder="Pin Code" name="pincode" class="form-control" id="name" aria-describedby="exampleInputEmail1" required>
						  </div>
						    <input type="hidden" style="border-radius:5px;border-color:black;min-width:240px;height:37px"  placeholder="Referral ID" name="referalid" class="form-control" id="name" value="0" aria-describedby="exampleInputEmail1">
						  
						 <div class="text-center">
						  <button type="submit" class="btn btn-primary">Register User</button>
						</div>

						</form>
</div></div> <br><br> <div class="input-group mb-3">
			
   <a href="<?=base_url('indexpage#login')?>" style="color:blue"><h5>Already Registered? Login Now!</h5></a>        
        </div>  </section>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->
  </body>
</html>