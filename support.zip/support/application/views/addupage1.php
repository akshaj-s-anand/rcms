<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Solar Section </title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<div class="m-4">
    <h4>Add Solar Section</h4>
    
    
    
    
    
    
     <div class="w3-half" style="margin-top:10%;margin-left:10%;">
                 <form role="form" method="post" action="<?=base_url('Welcome/addimage37')?>" enctype="multipart/form-data">
                     <?php foreach($image9->result() as $row){ ?>
                      <input type="hidden"  value="<?php echo $row->image; ?>" name="old" class="form-control" id="old"> <?php } ?> 
              <div class="panel">
                <div class="panel-body">
                  <div class="dsp form-group">
                <label>CHOOSE FOR FIRST  IMAGE</label>
                <input class="form-control" type="file" name="image37" />
            </div>
     
             <div class="dsp form-group">
                <input type="submit" class="btn btn-warning" name="membersubmit37" value="Submit">
            </div>
        </div>
    </div>
</form>
           

               
                
          </div>
          
          
          
          
           <div class="w3-half" style="margin-top:10%;margin-left:10%;">
                 <form role="form" method="post" action="<?=base_url('Welcome/addimage38')?>" enctype="multipart/form-data">
                     <?php foreach($image9->result() as $row){ ?>
                      <input type="hidden"  value="<?php echo $row->image2; ?>" name="old" class="form-control" id="old"> <?php } ?> 
              <div class="panel">
                <div class="panel-body">
                  <div class="dsp form-group">
                <label>CHOOSE FOR SECOND  IMAGE</label>
                <input class="form-control" type="file" name="image38" />
            </div>
     
             <div class="dsp form-group">
                <input type="submit" class="btn btn-warning" name="membersubmit38" value="Submit">
            </div>
        </div>
    </div>
</form>
           

               
                
          </div>
          
          
          
          
          
          
           <div class="w3-half" style="margin-top:10%;margin-left:10%;">
                 <form role="form" method="post" action="<?=base_url('Welcome/addimage39')?>" enctype="multipart/form-data">
                     <?php foreach($image9->result() as $row){ ?>
                      <input type="hidden"  value="<?php echo $row->image3; ?>" name="old" class="form-control" id="old"> <?php } ?> 
              <div class="panel">
                <div class="panel-body">
                  <div class="dsp form-group">
                <label>CHOOSE FOR THIRD  IMAGE</label>
                <input class="form-control" type="file" name="image39" />
            </div>
     
             <div class="dsp form-group">
                <input type="submit" class="btn btn-warning" name="membersubmit39" value="Submit">
            </div>
        </div>
    </div>
</form>
           

               
                
          </div>
          
          
          
           <div class="w3-half" style="margin-top:10%;margin-left:10%;">
                 <form role="form" method="post" action="<?=base_url('Welcome/addimage40')?>" enctype="multipart/form-data">
                     <?php foreach($image9->result() as $row){ ?>
                      <input type="hidden"  value="<?php echo $row->image4; ?>" name="old" class="form-control" id="old"> <?php } ?> 
              <div class="panel">
                <div class="panel-body">
                  <div class="dsp form-group">
                <label>CHOOSE FOR 4TH  IMAGE</label>
                <input class="form-control" type="file" name="image40" />
            </div>
     
             <div class="dsp form-group">
                <input type="submit" class="btn btn-warning" name="membersubmit40" value="Submit">
            </div>
        </div>
    </div>
</form>
           

               
                
          </div>
          
          
          
           <div class="w3-half" style="margin-top:10%;margin-left:10%;">
                 <form role="form" method="post" action="<?=base_url('Welcome/addimage41')?>" enctype="multipart/form-data">
                     <?php foreach($image9->result() as $row){ ?>
                      <input type="hidden"  value="<?php echo $row->image5; ?>" name="old" class="form-control" id="old"> <?php } ?> 
              <div class="panel">
                <div class="panel-body">
                  <div class="dsp form-group">
                <label>CHOOSE FOR 5TH  IMAGE</label>
                <input class="form-control" type="file" name="image41" />
            </div>
     
             <div class="dsp form-group">
                <input type="submit" class="btn btn-warning" name="membersubmit41" value="Submit">
            </div>
        </div>
    </div>
</form>
           

               
                
          </div>
          
          
          
          
          <div class="w3-half" style="margin-top:10%;margin-left:10%;">
                 <form role="form" method="post" action="<?=base_url('Welcome/addimage42')?>" enctype="multipart/form-data">
                     <?php foreach($image9->result() as $row){ ?>
                      <input type="hidden"  value="<?php echo $row->image6; ?>" name="old" class="form-control" id="old"> <?php } ?> 
              <div class="panel">
                <div class="panel-body">
                  <div class="dsp form-group">
                <label>CHOOSE FOR 6TH  IMAGE</label>
                <input class="form-control" type="file" name="image42" />
            </div>
     
             <div class="dsp form-group">
                <input type="submit" class="btn btn-warning" name="membersubmit42" value="Submit">
            </div>
        </div>
    </div>
</form>
           

               
                
          </div>
          
          
          
          
           <div class="w3-half" style="margin-top:10%;margin-left:10%;">
                 <form role="form" method="post" action="<?=base_url('Welcome/addimage43')?>" enctype="multipart/form-data">
                     <?php foreach($image9->result() as $row){ ?>
                      <input type="hidden"  value="<?php echo $row->image7; ?>" name="old" class="form-control" id="old"> <?php } ?> 
              <div class="panel">
                <div class="panel-body">
                  <div class="dsp form-group">
                <label>CHOOSE FOR 7TH  IMAGE</label>
                <input class="form-control" type="file" name="image43" />
            </div>
     
             <div class="dsp form-group">
                <input type="submit" class="btn btn-warning" name="membersubmit43" value="Submit">
            </div>
        </div>
    </div>
</form>
           

               
                
          </div>
          
          
          
          
           <div class="w3-half" style="margin-top:10%;margin-left:10%;">
                 <form role="form" method="post" action="<?=base_url('Welcome/addimage44')?>" enctype="multipart/form-data">
                     <?php foreach($image9->result() as $row){ ?>
                      <input type="hidden"  value="<?php echo $row->image8; ?>" name="old" class="form-control" id="old"> <?php } ?> 
              <div class="panel">
                <div class="panel-body">
                  <div class="dsp form-group">
                <label>CHOOSE FOR 8TH  IMAGE</label>
                <input class="form-control" type="file" name="image44" />
            </div>
     
             <div class="dsp form-group">
                <input type="submit" class="btn btn-warning" name="membersubmit44" value="Submit">
            </div>
        </div>
    </div>
</form>
           

               
                
          </div>
          
          
          
          
           <div class="w3-half" style="margin-top:10%;margin-left:10%;">
                 <form role="form" method="post" action="<?=base_url('Welcome/addimage45')?>" enctype="multipart/form-data">
                     <?php foreach($image9->result() as $row){ ?>
                      <input type="hidden"  value="<?php echo $row->image9; ?>" name="old" class="form-control" id="old"> <?php } ?> 
              <div class="panel">
                <div class="panel-body">
                  <div class="dsp form-group">
                <label>CHOOSE FOR 9TH  IMAGE</label>
                <input class="form-control" type="file" name="image45" />
            </div>
     
             <div class="dsp form-group">
                <input type="submit" class="btn btn-warning" name="membersubmit45" value="Submit">
            </div>
        </div>
    </div>
</form>
           

               
                
          </div>
          
          
          
          
          <div class="w3-half" style="margin-top:10%;margin-left:10%;">
                 <form role="form" method="post" action="<?=base_url('Welcome/addimage46')?>" enctype="multipart/form-data">
                     <?php foreach($image9->result() as $row){ ?>
                      <input type="hidden"  value="<?php echo $row->image10; ?>" name="old" class="form-control" id="old"> <?php } ?> 
              <div class="panel">
                <div class="panel-body">
                  <div class="dsp form-group">
                <label>CHOOSE FOR 10TH  IMAGE</label>
                <input class="form-control" type="file" name="image46" />
            </div>
     
             <div class="dsp form-group">
                <input type="submit" class="btn btn-warning" name="membersubmit46" value="Submit">
            </div>
        </div>
    </div>
</form>
           

               
                
          </div>
          
          
          
    <form method="post" action="<?=base_url()?>Welcome/addSliderHome17" enctype="multipart/form-data">
       
        
        <div class="mb-3">
            <label class="form-label" for="inputPassword">Add 1st Product's Name</label>
            <input type="text" class="form-control" name="tit1" id="inputPassword" placeholder="Title 1" required>
        </div>
        
     
        
         <div class="mb-3">
            <label class="form-label" for="inputPassword">Add 2nd Product's Name</label>
            <input type="text" class="form-control" name="tit2" id="inputPassword" placeholder="Title 1" required>
        </div>
        
       
        
        
         <div class="mb-3">
            <label class="form-label" for="inputPassword">Add 3rd Product's Name</label>
            <input type="text" class="form-control" name="tit3" id="inputPassword" placeholder="Title 1" required>
        </div>
        
        
        
         
         <div class="mb-3">
            <label class="form-label" for="inputPassword">Add 4th Product's Name</label>
            <input type="text" class="form-control" name="tit4" id="inputPassword" placeholder="Title 1" required>
        </div>
        
        
        
         
         <div class="mb-3">
            <label class="form-label" for="inputPassword">Add 5th Product's Name</label>
            <input type="text" class="form-control" name="tit5" id="inputPassword" placeholder="Title 1" required>
        </div>
        
        
        
        
         
         <div class="mb-3">
            <label class="form-label" for="inputPassword">Add 6th Product's Name</label>
            <input type="text" class="form-control" name="tit6" id="inputPassword" placeholder="Title 1" required>
        </div>
        
        
        
         
         <div class="mb-3">
            <label class="form-label" for="inputPassword">Add 7th Product's Name</label>
            <input type="text" class="form-control" name="tit7" id="inputPassword" placeholder="Title 1" required>
        </div>
        
        
        
         
         <div class="mb-3">
            <label class="form-label" for="inputPassword">Add 8th Product's Name</label>
            <input type="text" class="form-control" name="tit8" id="inputPassword" placeholder="Title 1" required>
        </div>
        
        
        
         
         <div class="mb-3">
            <label class="form-label" for="inputPassword">Add 9th Product's Name</label>
            <input type="text" class="form-control" name="tit9" id="inputPassword" placeholder="Title 1" required>
        </div>
        
        
        
        
         
         <div class="mb-3">
            <label class="form-label" for="inputPassword">Add 10th Product's Name</label>
            <input type="text" class="form-control" name="tit10" id="inputPassword" placeholder="Title 1" required>
        </div>
        
        
       
        
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>
</body>
</html>