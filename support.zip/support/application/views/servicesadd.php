<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Services Section </title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<div class="m-4">
    <h4>Add Services Section</h4>
    
    
    
    
    
    
     <div class="w3-half" style="margin-top:10%;margin-left:10%;">
                 <form role="form" method="post" action="<?=base_url('Welcome/addimage4')?>" enctype="multipart/form-data">
                     <?php foreach($image2->result() as $row){ ?>
                      <input type="hidden"  value="<?php echo $row->image; ?>" name="old" class="form-control" id="old"> <?php } ?> 
              <div class="panel">
                <div class="panel-body">
                  <div class="dsp form-group">
                <label>CHOOSE FOR FIRST SERVICE IMAGE</label>
                <input class="form-control" type="file" name="image4" />
            </div>
     
             <div class="dsp form-group">
                <input type="submit" class="btn btn-warning" name="membersubmit4" value="Submit">
            </div>
        </div>
    </div>
</form>
           

               
                
          </div>
          
          
          
          
           <div class="w3-half" style="margin-top:10%;margin-left:10%;">
                 <form role="form" method="post" action="<?=base_url('Welcome/addimage5')?>" enctype="multipart/form-data">
                     <?php foreach($image2->result() as $row){ ?>
                      <input type="hidden"  value="<?php echo $row->image2; ?>" name="old" class="form-control" id="old"> <?php } ?> 
              <div class="panel">
                <div class="panel-body">
                  <div class="dsp form-group">
                <label>CHOOSE FOR SECOND SERVICE IMAGE</label>
                <input class="form-control" type="file" name="image5" />
            </div>
     
             <div class="dsp form-group">
                <input type="submit" class="btn btn-warning" name="membersubmit5" value="Submit">
            </div>
        </div>
    </div>
</form>
           

               
                
          </div>
          
          
          
          
          
          
           <div class="w3-half" style="margin-top:10%;margin-left:10%;">
                 <form role="form" method="post" action="<?=base_url('Welcome/addimage6')?>" enctype="multipart/form-data">
                     <?php foreach($image2->result() as $row){ ?>
                      <input type="hidden"  value="<?php echo $row->image3; ?>" name="old" class="form-control" id="old"> <?php } ?> 
              <div class="panel">
                <div class="panel-body">
                  <div class="dsp form-group">
                <label>CHOOSE FOR THIRD SERVICE IMAGE</label>
                <input class="form-control" type="file" name="image6" />
            </div>
     
             <div class="dsp form-group">
                <input type="submit" class="btn btn-warning" name="membersubmit6" value="Submit">
            </div>
        </div>
    </div>
</form>
           

               
                
          </div>
    
    
    
    <form method="post" action="<?=base_url()?>Welcome/addSliderHome2" enctype="multipart/form-data">
       
        
        <div class="mb-3">
            <label class="form-label" for="inputPassword">Add First Service Headline</label>
            <input type="text" class="form-control" name="tit1" id="inputPassword" placeholder="Title 1" required>
        </div>
        
        <div class="mb-3">
            <label class="form-label" for="inputPassword">Description</label>
            <input type="text" class="form-control" name="subtit1" id="inputPassword" placeholder="Sub Title 1" required>
        </div>
        
         <div class="mb-3">
            <label class="form-label" for="inputPassword">Add Second Service Headline</label>
            <input type="text" class="form-control" name="tit2" id="inputPassword" placeholder="Title 1" required>
        </div>
        
        <div class="mb-3">
            <label class="form-label" for="inputPassword">Description</label>
            <input type="text" class="form-control" name="subtit2" id="inputPassword" placeholder="Sub Title 1" required>
        </div>
        
        
        
         <div class="mb-3">
            <label class="form-label" for="inputPassword">Add Third Service Headline</label>
            <input type="text" class="form-control" name="tit3" id="inputPassword" placeholder="Title 1" required>
        </div>
        
        <div class="mb-3">
            <label class="form-label" for="inputPassword">Description</label>
            <input type="text" class="form-control" name="subtit3" id="inputPassword" placeholder="Sub Title 1" required>
        </div>
        
      
        
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>
</body>
</html>