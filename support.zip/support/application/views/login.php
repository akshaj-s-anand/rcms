<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body {
            background-color: #f0f2f5;
            font-family: Arial, sans-serif;
        }

        .container {
            max-width: 400px;
            margin: 20vh auto;
            padding: 50px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .container h3 {
            text-align: center;
            font-size: 24px;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #dddfe2;
            border-radius: 4px;
            font-size: 14px;
        }

        .form-group input[type="submit"] {
            background-color: #1877f2;
            color: #fff;
            font-weight: bold;
            cursor: pointer;
        }

        .form-group input[type="submit"]:hover {
            background-color: #166fe5;
        }

        .form-group .create-account {
            text-align: center;
            font-size: 14px;
            color: #4b4f56;
        }

        .form-group .create-account a {
            color: #1877f2;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <h3>Login</h3>
        <form method="post" autocomplete="off" action="<?=base_url('Login_Registration/loginnow')?>">
            <div class="form-group">
                <input type="text" placeholder="Email" name="email" required>
            </div>
            <div class="form-group">
                <input type="password" placeholder="Password" name="password_1" required>
            </div>
            <div class="form-group">
                <input type="submit" value="Login Now">
            </div>
        </form>
        <p class="create-account">New Member? <a href="<?=base_url()?>Login_Registration/nextpage">Signup</a></p>
    </div>
</body>
</html>
