<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Services Section </title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<div class="m-4">
    <h4>Add Services Section</h4>
    
    
    
    
    
    
     <div class="w3-half" style="margin-top:10%;margin-left:10%;">
                 <form role="form" method="post" action="<?=base_url('Welcome/addimage8')?>" enctype="multipart/form-data">
                     <?php foreach($image5->result() as $row){ ?>
                      <input type="hidden"  value="<?php echo $row->image; ?>" name="old" class="form-control" id="old"> <?php } ?> 
              <div class="panel">
                <div class="panel-body">
                  <div class="dsp form-group">
                <label>CHOOSE FOR FIRST  IMAGE</label>
                <input class="form-control" type="file" name="image8" />
            </div>
     
             <div class="dsp form-group">
                <input type="submit" class="btn btn-warning" name="membersubmit8" value="Submit">
            </div>
        </div>
    </div>
</form>
           

               
                
          </div>
          
          
          
          
           <div class="w3-half" style="margin-top:10%;margin-left:10%;">
                 <form role="form" method="post" action="<?=base_url('Welcome/addimage9')?>" enctype="multipart/form-data">
                     <?php foreach($image5->result() as $row){ ?>
                      <input type="hidden"  value="<?php echo $row->image2; ?>" name="old" class="form-control" id="old"> <?php } ?> 
              <div class="panel">
                <div class="panel-body">
                  <div class="dsp form-group">
                <label>CHOOSE FOR SECOND  IMAGE</label>
                <input class="form-control" type="file" name="image9" />
            </div>
     
             <div class="dsp form-group">
                <input type="submit" class="btn btn-warning" name="membersubmit9" value="Submit">
            </div>
        </div>
    </div>
</form>
           

               
                
          </div>
          
          
          
          
          
          
           <div class="w3-half" style="margin-top:10%;margin-left:10%;">
                 <form role="form" method="post" action="<?=base_url('Welcome/addimage10')?>" enctype="multipart/form-data">
                     <?php foreach($image5->result() as $row){ ?>
                      <input type="hidden"  value="<?php echo $row->image3; ?>" name="old" class="form-control" id="old"> <?php } ?> 
              <div class="panel">
                <div class="panel-body">
                  <div class="dsp form-group">
                <label>CHOOSE FOR THIRD  IMAGE</label>
                <input class="form-control" type="file" name="image10" />
            </div>
     
             <div class="dsp form-group">
                <input type="submit" class="btn btn-warning" name="membersubmit10" value="Submit">
            </div>
        </div>
    </div>
</form>
           

               
                
          </div>
          
          
          
           <div class="w3-half" style="margin-top:10%;margin-left:10%;">
                 <form role="form" method="post" action="<?=base_url('Welcome/addimage11')?>" enctype="multipart/form-data">
                     <?php foreach($image5->result() as $row){ ?>
                      <input type="hidden"  value="<?php echo $row->image4; ?>" name="old" class="form-control" id="old"> <?php } ?> 
              <div class="panel">
                <div class="panel-body">
                  <div class="dsp form-group">
                <label>CHOOSE FOR 4TH  IMAGE</label>
                <input class="form-control" type="file" name="image11" />
            </div>
     
             <div class="dsp form-group">
                <input type="submit" class="btn btn-warning" name="membersubmit11" value="Submit">
            </div>
        </div>
    </div>
</form>
           

               
                
          </div>
          
          
          
           <div class="w3-half" style="margin-top:10%;margin-left:10%;">
                 <form role="form" method="post" action="<?=base_url('Welcome/addimage12')?>" enctype="multipart/form-data">
                     <?php foreach($image5->result() as $row){ ?>
                      <input type="hidden"  value="<?php echo $row->image5; ?>" name="old" class="form-control" id="old"> <?php } ?> 
              <div class="panel">
                <div class="panel-body">
                  <div class="dsp form-group">
                <label>CHOOSE FOR 5TH  IMAGE</label>
                <input class="form-control" type="file" name="image12" />
            </div>
     
             <div class="dsp form-group">
                <input type="submit" class="btn btn-warning" name="membersubmit12" value="Submit">
            </div>
        </div>
    </div>
</form>
           

               
                
          </div>
          
          
          
          
          <div class="w3-half" style="margin-top:10%;margin-left:10%;">
                 <form role="form" method="post" action="<?=base_url('Welcome/addimage13')?>" enctype="multipart/form-data">
                     <?php foreach($image5->result() as $row){ ?>
                      <input type="hidden"  value="<?php echo $row->image6; ?>" name="old" class="form-control" id="old"> <?php } ?> 
              <div class="panel">
                <div class="panel-body">
                  <div class="dsp form-group">
                <label>CHOOSE FOR 6TH  IMAGE</label>
                <input class="form-control" type="file" name="image13" />
            </div>
     
             <div class="dsp form-group">
                <input type="submit" class="btn btn-warning" name="membersubmit13" value="Submit">
            </div>
        </div>
    </div>
</form>
           

               
                
          </div>
          
          
          
          
           <div class="w3-half" style="margin-top:10%;margin-left:10%;">
                 <form role="form" method="post" action="<?=base_url('Welcome/addimage14')?>" enctype="multipart/form-data">
                     <?php foreach($image5->result() as $row){ ?>
                      <input type="hidden"  value="<?php echo $row->image7; ?>" name="old" class="form-control" id="old"> <?php } ?> 
              <div class="panel">
                <div class="panel-body">
                  <div class="dsp form-group">
                <label>CHOOSE FOR 7TH  IMAGE</label>
                <input class="form-control" type="file" name="image14" />
            </div>
     
             <div class="dsp form-group">
                <input type="submit" class="btn btn-warning" name="membersubmit14" value="Submit">
            </div>
        </div>
    </div>
</form>
           

               
                
          </div>
          
          
          
          
           <div class="w3-half" style="margin-top:10%;margin-left:10%;">
                 <form role="form" method="post" action="<?=base_url('Welcome/addimage15')?>" enctype="multipart/form-data">
                     <?php foreach($image5->result() as $row){ ?>
                      <input type="hidden"  value="<?php echo $row->image8; ?>" name="old" class="form-control" id="old"> <?php } ?> 
              <div class="panel">
                <div class="panel-body">
                  <div class="dsp form-group">
                <label>CHOOSE FOR 8TH  IMAGE</label>
                <input class="form-control" type="file" name="image15" />
            </div>
     
             <div class="dsp form-group">
                <input type="submit" class="btn btn-warning" name="membersubmit15" value="Submit">
            </div>
        </div>
    </div>
</form>
           

               
                
          </div>
          
          
          
          
           <div class="w3-half" style="margin-top:10%;margin-left:10%;">
                 <form role="form" method="post" action="<?=base_url('Welcome/addimage16')?>" enctype="multipart/form-data">
                     <?php foreach($image5->result() as $row){ ?>
                      <input type="hidden"  value="<?php echo $row->image9; ?>" name="old" class="form-control" id="old"> <?php } ?> 
              <div class="panel">
                <div class="panel-body">
                  <div class="dsp form-group">
                <label>CHOOSE FOR 9TH  IMAGE</label>
                <input class="form-control" type="file" name="image16" />
            </div>
     
             <div class="dsp form-group">
                <input type="submit" class="btn btn-warning" name="membersubmit16" value="Submit">
            </div>
        </div>
    </div>
</form>
           

               
                
          </div>
          
          
          
          
          <div class="w3-half" style="margin-top:10%;margin-left:10%;">
                 <form role="form" method="post" action="<?=base_url('Welcome/addimage17')?>" enctype="multipart/form-data">
                     <?php foreach($image5->result() as $row){ ?>
                      <input type="hidden"  value="<?php echo $row->image10; ?>" name="old" class="form-control" id="old"> <?php } ?> 
              <div class="panel">
                <div class="panel-body">
                  <div class="dsp form-group">
                <label>CHOOSE FOR 10TH  IMAGE</label>
                <input class="form-control" type="file" name="image17" />
            </div>
     
             <div class="dsp form-group">
                <input type="submit" class="btn btn-warning" name="membersubmit17" value="Submit">
            </div>
        </div>
    </div>
</form>
           

               
                
          </div>
          
          
          
          
           <div class="w3-half" style="margin-top:10%;margin-left:10%;">
                 <form role="form" method="post" action="<?=base_url('Welcome/addimage18')?>" enctype="multipart/form-data">
                     <?php foreach($image5->result() as $row){ ?>
                      <input type="hidden"  value="<?php echo $row->image11; ?>" name="old" class="form-control" id="old"> <?php } ?> 
              <div class="panel">
                <div class="panel-body">
                  <div class="dsp form-group">
                <label>CHOOSE FOR 11TH  IMAGE</label>
                <input class="form-control" type="file" name="image18" />
            </div>
     
             <div class="dsp form-group">
                <input type="submit" class="btn btn-warning" name="membersubmit18" value="Submit">
            </div>
        </div>
    </div>
</form>
           

               
                
          </div>
          
          
          
          
           <div class="w3-half" style="margin-top:10%;margin-left:10%;">
                 <form role="form" method="post" action="<?=base_url('Welcome/addimage19')?>" enctype="multipart/form-data">
                     <?php foreach($image5->result() as $row){ ?>
                      <input type="hidden"  value="<?php echo $row->image12; ?>" name="old" class="form-control" id="old"> <?php } ?> 
              <div class="panel">
                <div class="panel-body">
                  <div class="dsp form-group">
                <label>CHOOSE FOR 12TH  IMAGE</label>
                <input class="form-control" type="file" name="image19" />
            </div>
     
             <div class="dsp form-group">
                <input type="submit" class="btn btn-warning" name="membersubmit19" value="Submit">
            </div>
        </div>
    </div>
</form>
           

               
                
          </div>
          
          
          
    
    
    
    <form method="post" action="<?=base_url()?>Welcome/addSliderHome12" enctype="multipart/form-data">
       
        
        <div class="mb-3">
            <label class="form-label" for="inputPassword">Add 1st Product's Name</label>
            <input type="text" class="form-control" name="tit1" id="inputPassword" placeholder="Title 1" required>
        </div>
        
     
        
         <div class="mb-3">
            <label class="form-label" for="inputPassword">Add 2nd Product's Name</label>
            <input type="text" class="form-control" name="tit2" id="inputPassword" placeholder="Title 1" required>
        </div>
        
       
        
        
         <div class="mb-3">
            <label class="form-label" for="inputPassword">Add 3rd Product's Name</label>
            <input type="text" class="form-control" name="tit3" id="inputPassword" placeholder="Title 1" required>
        </div>
        
        
        
         
         <div class="mb-3">
            <label class="form-label" for="inputPassword">Add 4th Product's Name</label>
            <input type="text" class="form-control" name="tit4" id="inputPassword" placeholder="Title 1" required>
        </div>
        
        
        
         
         <div class="mb-3">
            <label class="form-label" for="inputPassword">Add 5th Product's Name</label>
            <input type="text" class="form-control" name="tit5" id="inputPassword" placeholder="Title 1" required>
        </div>
        
        
        
        
         
         <div class="mb-3">
            <label class="form-label" for="inputPassword">Add 6th Product's Name</label>
            <input type="text" class="form-control" name="tit6" id="inputPassword" placeholder="Title 1" required>
        </div>
        
        
        
         
         <div class="mb-3">
            <label class="form-label" for="inputPassword">Add 7th Product's Name</label>
            <input type="text" class="form-control" name="tit7" id="inputPassword" placeholder="Title 1" required>
        </div>
        
        
        
         
         <div class="mb-3">
            <label class="form-label" for="inputPassword">Add 8th Product's Name</label>
            <input type="text" class="form-control" name="tit8" id="inputPassword" placeholder="Title 1" required>
        </div>
        
        
        
         
         <div class="mb-3">
            <label class="form-label" for="inputPassword">Add 9th Product's Name</label>
            <input type="text" class="form-control" name="tit9" id="inputPassword" placeholder="Title 1" required>
        </div>
        
        
        
        
         
         <div class="mb-3">
            <label class="form-label" for="inputPassword">Add 10th Product's Name</label>
            <input type="text" class="form-control" name="tit10" id="inputPassword" placeholder="Title 1" required>
        </div>
        
        
        
        
         
         <div class="mb-3">
            <label class="form-label" for="inputPassword">Add 11th Product's Name</label>
            <input type="text" class="form-control" name="tit11" id="inputPassword" placeholder="Title 1" required>
        </div>
        
        
        
        
         
         <div class="mb-3">
            <label class="form-label" for="inputPassword">Add 12th Product's Name</label>
            <input type="text" class="form-control" name="tit12" id="inputPassword" placeholder="Title 1" required>
        </div>
      
      
        
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>
</body>
</html>