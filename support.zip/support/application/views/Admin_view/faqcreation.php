<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Admin Page</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">

  <link rel="stylesheet" href="../dist/css/adminlte.min.css">

</head>
<body class="hold-transition sidebar-mini" style="width:auto;min-width:600px">
<div class="wrapper" style="width:auto;min-width:600px">

<?php include_once('admin_header.php'); ?>
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Create FAQs</h1>
          </div><!-- /.col -->
         
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
       <div class="card-body" style="margin-right:5%">
                  	<?php
						if($this->session->flashdata('faqsuccess')) {	?>
						 <p class="text-success text-center" style="color:white;margin-top: 10px;"> <?=$this->session->flashdata('faqsuccess')?></p>
						<?php } ?>	
             
              <form method="POST"  autocomplete="off" action="<?=base_url('Admin/faqcreation')?>">
					
					   	<div class="mb-3">
						   <?php
						if($this->session->flashdata('usererror2')) {	?>
						 <p class="text-success text-center" style="color:white;margin-top: 10px;"> <?=$this->session->flashdata('usererror2')?></p>
						<?php } ?>
						    <label for="exampleInputEmail1" class="form-label">Question*</label>
						    <input type="text" placeholder="Question" style="border-radius:5px;border-color:black;width:357px;height:37px" name="question" class="form-control" id="question" aria-describedby="question" required> 
						  </div>
						  <div class="mb-3">
						    <label for="exampleInputEmail1" class="form-label">Answer*</label>
						    <textarea  placeholder="Enter the answer" style="border-radius:5px;border-color:black;width:357px" rows="8" cols="30" font-align:"left" name="answer" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required></textarea>  </div>
					
<div class="mb-3">
     <button type="submit" class="btn btn-primary">Submit</button>
</div>
						</form>
         
            
        
        
      </div><!-- /.container-fluid -->
     

    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
    <div class="p-3">
      <h5>Title</h5>
      <p>Sidebar content</p>
    </div>
  </aside>
  <!-- /.control-sidebar -->

  <!-- Main Footer -->
  
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->

<!-- jQuery -->
 
<!-- Bootstrap 4 -->
<script src="../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="../dist/js/adminlte.min.js"></script>
 
</body>
</html>











 