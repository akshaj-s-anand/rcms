<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Admin Page</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">

  <link rel="stylesheet" href="../dist/css/adminlte.min.css">

</head>
<body class="hold-transition sidebar-mini" style="width:auto;min-width:600px">
<div class="wrapper" style="width:auto;min-width:600px">

  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-green navbar-light"style="width:auto;min-width:174px">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
   
    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      <!-- Navbar Search -->
      <li class="nav-item">
        <a class="nav-link" data-widget="navbar-search" href="#" role="button">
          <i class="fas fa-search"></i>
        </a>
        <div class="navbar-search-block">
          <form class="form-inline">
            <div class="input-group input-group-sm">
              <input class="form-control form-control-navbar" type="search" placeholder="Search" aria-label="Search">
              <div class="input-group-append">
                <button class="btn btn-navbar" type="submit">
                  <i class="fas fa-search"></i>
                </button>
                <button class="btn btn-navbar" type="button" data-widget="navbar-search">
                  <i class="fas fa-times"></i>
                </button>
              </div>
            </div>
          </form>
        </div>
      </li>

      <!-- Messages Dropdown Menu -->
      <li class="nav-item dropdown">
        <a class="nav-link" data-toggle="dropdown" href="#">
          <i class="far fa-bell"></i>
          <span class="badge badge-danger navbar-badge"> <?php echo $j->num_rows() ?></span>
        </a>
        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
              <?php                           foreach ($i->result() as $row)  
                          {  
                              ?>
          <a href="#" class="dropdown-item">
            
            <!-- Message Start -->
            <div class="media">
             
              <div class="media-body">
                <h3 class="dropdown-item-title">
                  <?php echo $row->customername;?>
                  
                </h3>
                <p class="text-sm">Ticket booked:<?php echo $row->rqr;?></p>
                <p class="text-sm text-muted"><i class="far fa-clock mr-1"></i><?php echo $row->time;?><?php echo $row->date;?><form style="color:grey"><?php if(($row->view_status)=='viewed'){ echo $row->view_status ;}else{echo "not viewed" ;} ?></form></p>
              </div>
            </div>
            <!-- Message End -->
          </a>
          <div class="dropdown-divider"></div>
     
        <?php }?>
          <a href="<?=base_url('Admin/notification')?>" class="dropdown-item">
            
            <!-- Message Start -->
            <div class="media">
             
              <div class="media-body">
                <h3 class="dropdown-item-title">
                  See All Notifications
                  
                </h3>
               
              </div>
            </div>
            <!-- Message End -->
          </a>
        </div>
      </li>
   
      <li class="nav-item">
        <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="#" role="button">
          <i class="fa fa-gear fa-spin "></i>
        </a>
      </li>
    </ul>
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="index3.html" class="brand-link">
      <img src="../dist/img/AdminLTELogo.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
      <span class="brand-text font-weight-light"><?php  $udata = $this->session->userdata('UserLoginSession');
    echo $udata['role'] ;?></span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
      <i class="fa fa-user " style="color:white;padding:4.7%"></i>
        <div class="info">
          <a href="#" class="d-block" style="font-size:20px"> <?php 
if($this->session->userdata('UserLoginSession'))
{
    $udata = $this->session->userdata('UserLoginSession');
    echo $udata['username'] ;
}
else
{
    redirect(base_url('Login_Registration/login'));
}



 ?></a>
   <a  href="<?=base_url('Admin/logout')?>"><b class="try" style="font-size:15px;color:#ff4d4d">LogOut</b></a>
  
        </div>
      </div>

     

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
               <li class="nav-item ">
       <a href="<?=base_url('Admin/ticketview')?>" class="nav-link ">
         <i class="fas fa-home"></i>
         <p>
          Home
          
         </p>
       </a>
       
             <li class="nav-item ">
       <a href="<?=base_url('Admin/registerstaff')?>" class="nav-link ">
         <i class="fas fa-folder"></i>
         <p>
          Register Staff
          
         </p>
       </a>
        <li class="nav-item ">
       <a href="<?=base_url('Admin/removestaff')?>" class="nav-link ">
         <i class="fas fa-folder"></i>
         <p>
          Remove Staff
          
         </p>
       </a>
        <li class="nav-item ">
       <a href="<?=base_url('Admin/faqcreation')?>" class="nav-link ">
         <i class="fas fa-folder"></i>
         <p>
          Create FAQs 
          
         </p>
       </a>
        <li class="nav-item ">
       <a href="<?=base_url('Admin/view_faq')?>" class="nav-link ">
         <i class="fas fa-folder"></i>
         <p>
          View/Delete FAQs 
          
         </p>
       </a>
               <li class="nav-item ">
       <a href="<?=base_url('Admin/myticketview')?>" class="nav-link ">
         <i class="fas fa-folder"></i>
         <p>
          My Tickets
          
         </p>
       </a>
        <li class="nav-item ">
       <a href="<?=base_url('Admin/assignstaff')?>" class="nav-link ">
         <i class="fas fa-folder"></i>
         <p>
          Assign Staff 
          
         </p>
       </a>
      
     <li class="nav-item">
       <a href="<?=base_url('Admin/viewmyoverduetickets')?>" class="nav-link">
         <i class=" fas fa-folder"></i>
         <p>
          My Overdue Tickets
          
         </p>
       </a>
     </li>
     <li class="nav-item">
       <a href="<?=base_url('Admin/viewmyduetoday')?>" class="nav-link">
         <i class="fas fa-folder"></i>
         <p>
          My Due Today Tickets
         </p>
       </a>
           </li>
     <li class="nav-item">
       <a href="<?=base_url('Admin/viewmypending')?>" class="nav-link">
         <i class="fas fa-folder"></i>
         <p>
           My Pending Approvals
         
         </p>
       </a>
     </li>
     <li class="nav-item">
       <a href="<?=base_url('Admin/viewopentickets')?>" class="nav-link">
         <i class="fas fa-folder"></i>
         <p>
          Open Tickets
          
         </p>
       </a>  
     </li>
     <li class="nav-item">
       <a href="<?=base_url('Admin/viewoverduetickets')?>" class="nav-link">
         <i class="fas fa-folder"></i>
         <p>
          Overdue Tickets
          
         </p>
       </a>  
     </li>
     <li class="nav-item">
       <a href="<?=base_url('Admin/viewunassigned')?>" class="nav-link">
         <i class="fas fa-folder"></i>
         <p>
          Unassigned Tickets
        
         </p>
       </a>  
     </li>
     <li class="nav-item">
       <a href="<?=base_url('Admin/viewunanswered')?>" class="nav-link">
         <i class="fas fa-folder"></i>
         <p>
          Unanswered Tickets
         
         </p>
       </a>  
     </li>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Notification</h1>
          </div><!-- /.col -->
         
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      
         <div class="row">
            
                      <div class="col">
           
            <div class="card"style="width:100%; background-color: rgb(224, 210, 170);min-width:450px">
          
              <div class="card-body">
       <div style="width:100%; height:50%; overflow:auto;margin-top: -3%;">
         <table style="width:100%" >
           <thead>
             <tr>
               
             </tr>
           <tr style="width:100%;color:white;background-color:grey">
                             <th>Username</th>  
                              <th>Ticket</th>
                               <th>Detail</th>
                              <th>Date</th>
                              <th>Time</th>  
         </tr>
           </thead>
 <?php  
                          foreach ($h->result() as $row)  
                          {  
                              ?><tr>  
                              <td><?php echo $row->customername;?></td>  
                              <td><?php echo $row->rqr;?></td>
                               <td><?php echo $row->details;?></td>
                              <td><?php echo $row->date?></td>
                              <td> <?php echo $row->time?></td>   
                             
                              </tr>  
                          <?php }  
                          ?>  
    
</table>
              </div>
            </div><!-- /.card -->
            </div>
          </div>
          <!-- /.col-md-6 -->
     
            
            
            
        
       
        </div>
        <!-- /.row -->
        
      </div><!-- /.container-fluid -->
     

    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
    <div class="p-3">
      <h5>Title</h5>
      <p>Sidebar content</p>
    </div>
  </aside>
  <!-- /.control-sidebar -->

  <!-- Main Footer -->
  <footer class="main-footer"style="font-size:8px;margin-left:90%">
    <!-- To the right -->
    
    <!-- Default to the left -->
    <strong>Copyright &copy; 2014-2021 <a href="https://adminlte.io">AdminLTE.io</a>.</strong> All rights reserved.
  </footer>
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->

<!-- jQuery -->
<script src="../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="../dist/js/adminlte.min.js"></script>
</body>
</html>
