<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>All Complaints</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">

  <link rel="stylesheet" href="../dist/css/adminlte.min.css">
<style>
    table {
        background-color:white;
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td,th {
  border: 1px solid #ddd;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2;}

tr:hover {background-color: #ddd;}

th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #04AA6D;
  color: white;
}
</style>
</head>
<body class="hold-transition sidebar-mini" style="width:auto;min-width:174px">
<div class="wrapper">

<?php include_once('admin_header.php'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">All Complaints</h1>
          </div><!-- /.col -->
         
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      
      <div class="container-fluid">
      
     
           
            <div class="card card-primary card-outline"style="width:100%;min-width:374px; background-color: rgb(224, 210, 170)">
           
    
             
             
            <div class="table-responsive">
                                            <table class="table align-middle table-nowrap mb-0" id="datatable-buttons">
           <thead>
               <tr>
                    <th>DL Num</th>
                    <th>Date</th>
                   <th>Customer</th>
                   <th>Mob</th>
                   <th>Item</th>
                   <th>Assigned</th>
                   <th>Status</th>
                   <th>Bill</th>
                   <th>Remarks</th>
                   <th>Action</th>
                    <!--<th>Complaint</th>-->
                    <!-- <th>Overdue</th>-->
                    <!--  <th>Date-Time</th>-->
                     
                     
                      
                       
               </tr>
           </thead>
                      
                  </table>
              </div>
            </div><!-- /.card -->
          </div>
          <!-- /.col-md-6 -->
        
        </div>
        <!-- /.row -->
        
      </div><!-- /.container-fluid -->
 
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
    <div class="p-3">
      <h5>Title</h5>
      <p>Sidebar content</p>
    </div>
  </aside>
  <!-- /.control-sidebar -->

  <!-- Main Footer -->
  
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->

<!-- jQuery -->
 
<!-- Bootstrap 4 -->
<script src="../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="../dist/js/adminlte.min.js"></script>
  
</body>
</html>
<script>

function deleteTicket(id){
  if (confirm("Do you want to delete")){
       $.ajax({
            url: '<?php echo base_url()?>admin/deleteticket/',
            type: "POST",
            data:{'id':id},
            dataType: "json",
            success: function(response)
            {	
                if(parseInt(response) == 1){
                   alert('Complaint Deleted');
                   $('#datatable-buttons').DataTable().ajax.reload(null,false);
                }else{
                  alert('Error in Complaint Deletion')
                }

                 
            }
            
        });
     
    }
    return false;
 
}
$(document).ready(function() { 

$('#datatable-buttons').DataTable({
    dom: 'Bfrtip',
    "ordering": false,
         
    "ajax": {
        url : "<?php echo base_url()?>admin/getticket/",
        type : 'GET',
    
        error: function(){  
            $("#datatable-buttons tbody tr").css("display","none");
            $("#datatable-buttons").append('<tr><th colspan="5" style="margin:10px auto;">No results.</th></tr>');
        }
    },
});

} );
</script>
<style>
  .table-responsive{
background-color: #fff;
  }
  .table>thead{
    background-color: #27a143;
  }
  .dataTables_wrapper .dataTables_filter{
    margin-right: 10px;
  }
</style>