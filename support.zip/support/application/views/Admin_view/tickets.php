<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Admin Page</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">

  <link rel="stylesheet" href="../dist/css/adminlte.min.css">

</head>
<body class="hold-transition sidebar-mini" style="width:auto;min-width:600px">
<div class="wrapper" style="width:auto;min-width:600px">

  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-green navbar-light"style="width:auto;min-width:174px">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
   
    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      <!-- Navbar Search -->
      <li class="nav-item">
        <a class="nav-link" data-widget="navbar-search" href="#" role="button">
          <i class="fas fa-search"></i>
        </a>
        <div class="navbar-search-block">
          <form class="form-inline">
            <div class="input-group input-group-sm">
              <input class="form-control form-control-navbar" type="search" placeholder="Search" aria-label="Search">
              <div class="input-group-append">
                <button class="btn btn-navbar" type="submit">
                  <i class="fas fa-search"></i>
                </button>
                <button class="btn btn-navbar" type="button" data-widget="navbar-search">
                  <i class="fas fa-times"></i>
                </button>
              </div>
            </div>
          </form>
        </div>
      </li>





   
    
    </ul>
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="index3.html" class="brand-link">
      <img src="../dist/img/AdminLTELogo.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
      <span class="brand-text font-weight-light"><?php  $udata = $this->session->userdata('UserLoginSession');
    echo $udata['role'] ;?></span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
      <i class="fa fa-user " style="color:white;padding:4.7%"></i>
        <div class="info">
          <a href="#" class="d-block" style="font-size:20px"> <?php 
if($this->session->userdata('UserLoginSession'))
{
    $udata = $this->session->userdata('UserLoginSession');
    echo $udata['username'] ;
}
else
{
    redirect(base_url('Login_Registration/login'));
}



 ?></a>
   <a  href="<?=base_url('Admin/logout')?>"><b class="try" style="font-size:15px;color:#ff4d4d">LogOut</b></a>
  
        </div>
      </div>

     

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
               <li class="nav-item ">
       <a href="<?=base_url('Admin/ticketview')?>" class="nav-link ">
         <i class="fas fa-home"></i>
         <p>
          Home
          
         </p>
       </a>
       
             <li class="nav-item ">
       <a href="<?=base_url('Admin/registerstaff')?>" class="nav-link ">
         <i class="fas fa-folder"></i>
         <p>
          Register Staff
          
         </p>
       </a>
        <li class="nav-item ">
       <a href="<?=base_url('Admin/removestaff')?>" class="nav-link ">
         <i class="fas fa-folder"></i>
         <p>
          Remove Staff
          
         </p>
       </a>
        <li class="nav-item ">
       <a href="<?=base_url('Admin/faqcreation')?>" class="nav-link ">
         <i class="fas fa-folder"></i>
         <p>
          Create FAQs 
          
         </p>
       </a>
        <li class="nav-item ">
       <a href="<?=base_url('Admin/view_faq')?>" class="nav-link ">
         <i class="fas fa-folder"></i>
         <p>
          View/Delete FAQs 
          
         </p>
       </a>
               <li class="nav-item ">
       <a href="<?=base_url('Admin/allticketview')?>" class="nav-link ">
         <i class="fas fa-folder"></i>
         <p>
         All Tickets
          
         </p>
       </a>
       
        <li class="nav-item ">
       <a href="<?=base_url('Admin/assignstaff')?>" class="nav-link ">
         <i class="fas fa-folder"></i>
         <p>
          Assign Staff 
          
         </p>
       </a>
     <li class="nav-item">
       <a href="<?=base_url('Admin/viewopentickets')?>" class="nav-link">
         <i class="fas fa-folder"></i>
         <p>
          Open Tickets
          
         </p>
       </a>  
     </li>
     <li class="nav-item">
       <a href="<?=base_url('Admin/viewmyduetoday')?>" class="nav-link">
         <i class="fas fa-folder"></i>
         <p>
           Due Today Tickets
         </p>
       </a>
           </li>
    
   
     <li class="nav-item">
       <a href="<?=base_url('Admin/viewoverduetickets')?>" class="nav-link">
         <i class="fas fa-folder"></i>
         <p>
          Overdue Tickets
          
         </p>
       </a>  
     </li>
     <li class="nav-item">
       <a href="<?=base_url('Admin/viewunassigned')?>" class="nav-link">
         <i class="fas fa-folder"></i>
         <p>
          Unassigned Tickets
        
         </p>
       </a>  
     </li>
      <li class="nav-item">
       <a href="<?=base_url('Admin/viewassigned')?>" class="nav-link">
         <i class="fas fa-folder"></i>
         <p>
          Assigned Tickets
        
         </p>
       </a>  
     </li>
    
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Home Page</h1>
          </div><!-- /.col -->
         
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      
         <div class="row">
            
                      <div class="col">
           
            <div class="card"style="width:40%; background-color: rgb(224, 210, 170);min-width:500px">
            <div class="card-header">
            <i class="fa fa-warning" style="font-size:25px;color:red;margin-right: 10px;"></i>Requires Immediate Action  <button class=btn1><i class="fa fa-question-circle" style="font-size:25px;color:rgb(43, 43, 175)"></i></button>

              </div>
              <div class="card-body">
       <div style="width:100%; overflow:auto;margin-top: -3%;">
         <table style="width:100%" >
           <thead>
             <tr>
               
             </tr>
           <tr style="color:white;background-color:grey">
                             <th>Username</th>  
                              <td>Item</td>  
                              <th>Ticket</th>
                              <th>Date</th>
                              <th>Time</th>  
         </tr>
           </thead>
 <?php  
                          foreach ($h->result() as $row)  
                          {  
                              ?><tr>  
                              <td><?php echo $row->customername;?></td>
                               <td><?php echo $row->item;?></td>  
                              <td><?php echo $row->rqr;?></td>
                              <td><?php echo $row->date?></td>
                              <td> <?php echo $row->time?></td>   
                             
                              </tr>  
                          <?php }  
                          ?>  
    
</table>
              </div>
            </div><!-- /.card -->
            </div>
          </div>
          <!-- /.col-md-6 -->
     
            
            
            
        
         <div class="col " >
           <div class="nav-right">
            <div class="card p-3 text-center "style="background-color:#aac3c9;width:40%;height:auto;border-radius: 10px;min-width:350px" >
           
              <div class="card-body" >
              <div class="btn-group-horizontal">
          <div class="btn-group-vertical"style="margin-right:10%">
                        <button type="button" onclick="location.href='<?=base_url('Admin/allticketview')?>'" class="btn btn-primary" style="margin-top:15%;border-radius: 5px;width: 110px;height: 90px;background-color:green"><em class="fa fa-folder"style="font-size: 20px;"></em><br><a style="font-size: 12px;">All tickets</a> <br><br></button>
                      
                        <button type="button" onclick="location.href='<?=base_url('Admin/viewopentickets')?>'" class="btn btn-primary" style="margin-top:15%;border-radius: 5px;width: 110px;height: 90px;background-color:green"><em class="fa fa-folder"style="font-size: 20px;"></em><br><a style="font-size: 12px">Open tickets</a></button>
                        <button type="button" onclick="location.href='<?=base_url('Admin/viewmyduetoday')?>'" class="btn btn-primary" style="margin-top:15%;border-radius: 5px;width: 110px;height: 90px;background-color:green"><em class="fa fa-folder"style="font-size: 20px;"></em><br><a style="font-size: 12px">Due Today<br> tickets</a></button>
                    </div>
                    <div class="btn-group-vertical">
                        <button type="button" onclick="location.href='<?=base_url('Admin/viewunassigned')?>'" class="btn btn-primary" style="margin-top:15%;border-radius: 5px;width: 110px;height: 90px;background-color:green"><em class="fa fa-folder"style="font-size: 20px;"></em><br><a style="font-size: 12px">Unassigned tickets</a></button>
                        <button type="button" onclick="location.href='<?=base_url('Admin/viewassigned')?>'" class="btn btn-primary" style="margin-top:15%;border-radius: 5px;width: 110px;height: 90px;background-color:green"><em class="fa fa-folder"style="font-size: 20px;"></em><br><a style="font-size: 12px">Assigned Tickets</a></button>
                        <button type="button" onclick="location.href='<?=base_url('Admin/viewoverduetickets')?>'" class="btn btn-primary" style="margin-top:15%;border-radius: 5px;width: 110px;height: 90px;background-color:green"><em class="fa fa-folder"style="font-size: 20px;"></em><br><a style="font-size: 12px">Overdue tickets</a></button>
                      
                    </div>
          </div>
              </div>
            </div><!-- /.card -->
            </div>
          </div>
          <!-- /.col-md-6 -->
        
        </div>
        <!-- /.row -->
        
      </div><!-- /.container-fluid -->
     

    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
    <div class="p-3">
      <h5>Title</h5>
      <p>Sidebar content</p>
    </div>
  </aside>
  <!-- /.control-sidebar -->

  <!-- Main Footer -->
 
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->

<!-- jQuery -->
<script src="../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="../dist/js/adminlte.min.js"></script>
</body>
</html>
