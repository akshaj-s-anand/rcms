<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    						<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"
        					rel="stylesheet" type="text/css" />
    <title>Home Page</title>
    <style>
        .btn {
  background-color: transparent;
  border: none;
  color: rgb(0, 0, 0);
  padding: 2.5px 4px;
  border-radius: 50%;
  text-align: center;
  transition: 0.3s;
  cursor: pointer;
}
.dropbtn {
  background-color: transparent;
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 100px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #ddd;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {color: teal;}
        </style>
  </head>
  <body>
  </head>
  <body>		
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark" style="height:70px">
		  <div class="container-fluid">
		    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
		      <span class="navbar-toggler-icon"></span>
		    </button>
		    <img src="https://www.highrich.net/assets/frontarea/images/logo.png"width=200px alt='logo.png'>
		    <div class="collapse navbar-collapse" id="navbarTogglerDemo03" style="color:white;margin-left:10px">
            <?php 
if($this->session->userdata('UserLoginSession'))
{
    $udata = $this->session->userdata('UserLoginSession');
    echo 'Welcome'.' '.$udata['username'] ;
}
else
{
    redirect(base_url('Welcome/login'));
}



 ?>
 
		      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
		        <li class="nav-item">
		          <a class="nav-link active" style="margin-left:20px"aria-current="page" href="#">Home</a>
		        </li>
		      
		      </ul>
              <form style="display:inline;"><get action="/search" id="search">
            <input name="q" type="text" size="15" placeholder="Search..." />
            <style>#search {

            }
            
            #search input[type="text"] {
                background: url(search-white.png) no-repeat 10px 6px #fcfcfc;
                border: 1px solid #d1d1d1;
                font: 12px Arial,Helvetica,Sans-serif;
                color: #2b2929;
                width: 150px;
                padding: 6px 15px 6px 35px;
                -webkit-border-radius: 20px;
                -moz-border-radius: 20px;
                border-radius: 20px;
                text-shadow: 0 2px 3px rgba(0, 0, 0, 0.1);
                -webkit-box-shadow: 0 1px 3px rgba(0, 0, 0, 0.15) inset;
                -moz-box-shadow: 0 1px 3px rgba(0, 0, 0, 0.15) inset;
                box-shadow: 0 1px 3px rgba(0, 0, 0, 0.15) inset;
                -webkit-transition: all 0.7s ease 0s;
                -moz-transition: all 0.7s ease 0s;
                -o-transition: all 0.7s ease 0s;
                transition: all 0.7s ease 0s;
                }
            
            #search input[type="text"]:focus {
                width: 200px;
            }</style>
            </form>
            <button class="btn"><em class="fa fa-shopping-cart" style="text-align:left;font-size: 18px;padding-left: 5px;color:white;border-radius:100%"></em></button>
            <button class="btn"></button>
        <div class="dropdown">
  <button class="dropbtn"><em class="fa fa-user" style="text-align:left;font-size: 18px;padding-left: 5px;color:white"></em></button>
  <div class="dropdown-content" style="margin-left:-50px">
  <a href="<?=base_url('Welcome/logout')?>">Logout</a>

  </div>
</div>
		</nav>
		<div class="container"  >
			<div class="row">
	
				<div class="col-md-4">
					<div class="card" >
					  <div class="card-header text-center">
			
						
    						

				
				
		
						</form>
					  </div>
					</div>
				</div>
				<div class="col-md-4"></div>
			</div>
		</div>
    

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

  </body>
</html>

