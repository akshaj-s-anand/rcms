<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Admin Page</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">

  <link rel="stylesheet" href="../dist/css/adminlte.min.css">
<style>
    table {
        background-color:white;
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td,th {
  border: 1px solid #ddd;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2;}

tr:hover {background-color: #ddd;}

th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #04AA6D;
  color: white;
}
</style>
</head>
<body class="hold-transition sidebar-mini" style="width:auto;min-width:174px">
<div class="wrapper">
<?php include_once('admin_header.php'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Daily Reports</h1>
          </div><!-- /.col -->
          
          
        </div><!-- /.row -->
        <form method="post"  >
        <div class="row">
        <div class="col-sm-4">
          <select name='staff' id='staff' class="form-control" style="background-color:#E5E4E2;margin-left:5px;margin-bottom:50px;margin-top:20px"  >  
            <option value="">Select Engineer</option>  
            <option value="ALL" Selected>ALL</option> 
            <?php
                  foreach($staff->result()as $row)
                  {
                    ?>  
                      <option value="<?php echo $row->id;?>"><?php echo $row->username;?></option>  
                      <?php 
                  }
                  ?>
                  </select>
                  
          </div>
          <div class="col-sm-4">
          <input name='dates'  id='dates' value="<?php echo date('Y-m-d')?>" type="date" class="form-control" style="background-color:#E5E4E2;margin-left:5px;margin-bottom:50px;margin-top:20px"   />  
            
                  
          </div>
          <div class="col-sm-4">
<button type="button" onclick="loadreport();" class="btn btn-primary" style="width:100px;background-color:#38ACEC;border-radius:15px; margin-top: 20px;">Report</button>
          </div>
        </div>
        </form>
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      
      <div class="container-fluid">
      
     
           
            <div class="card card-primary card-outline"style="width:100%;min-width:374px; background-color: rgb(224, 210, 170)">
           
    
             
             
       <div style="width:100%; height:70%; overflow:auto;" id="tb1">
       <table id="datatable-buttons">
           <thead>
               <tr>
                    <th>ID Num</th>
                    <th>Date</th>
                   <th>Customer</th>
                   <th>Mob</th>
                   <th>Item</th>
                   <th>Assigned</th>
                   <th>Status</th>
                   <th>Bill</th>
                   <th>Remarks</th>
                   
                     
                     
                      
                       
               </tr>
           </thead>
                      <!-- <tbody>
                      <?php 
                      if(count($report)>0) {
                      foreach ($report as $row)  
                      {   
                        $d1=new DateTime();
                        $d2 = date_create($row->date);
                        $row->diff=date_diff($d2,$d1);
                        $row->d=(int)$row->diff->format("%R%a");
                        ?>
                        <tr>  
                            <td><?php echo $row->id;?></td>  
                            <td>Due Time:<?php echo $row->date?> <?php echo $row->time?></td> 
                            <td><?php echo $row->customername;?></td>  
                            <td><?php echo $row->phone;?></td>  
                            <td><?php echo $row->item;?></td> 
                            <td style="text-alignment:center"><?php echo $row->staffid . ' - ' . $row->staff; ?></td>
                            <td> <?php if(($row->status)==0){ ?><p style="color:red"> Open </p><?php } ?><?php if(($row->status)==1){ ?><p style="color:#a63d05"> Working </p><?php } ?><?php if(($row->status)==2){ ?><p style="color:#bf762c"> Temporarly Closed </p><?php } ?><?php if(($row->status)==3){ ?><p style="color:green"> Closed </p><?php } ?></td>
                            <td> <?php if(($row->status==3)||($row->status==2)){ ?> <p><a href="<?php echo base_url('Superadmin/viewbillNew/'.$row->id)?>" type="link" class="link" >View More</a></p> <?php } ?></td>
                            <td> <?php if(($row->assign_status)==0){ ?><p style="color:red"> Unassigned </p><?php } ?><?php if(($row->assign_status)==1){ ?><p style="color:green"> Assigned </p><?php } ?></td>
                            </tr> 
                      <?php }}
                      else{  
                      ?> 
                       <tr>  
                            <td colspan="9" style="text-align: center;">No data found</td>  
                           </tr> 
                      <?php }
                      ?>
                    </tbody> -->
                  </table>
              
       </div>
       <div style="width:100%; height:70%; overflow:auto; display:none;"  id="tb2">      
                  <table id="datatable-buttons1" >
           <thead>
               <tr>
                    <th>Sl Num</th>
                    <th>Date</th>
                   <th>Customer</th>
                   <th>Mob</th>
                   <th>Item</th>
                   <th>Assigned</th>
                   <th>Status</th>
                   <th>Bill</th>
                   <th>Remarks</th>
                   
                     
                     
                      
                       
               </tr>
           </thead>
                      
                  </table>
               
                </div>
            </div><!-- /.card -->
          </div>
          <!-- /.col-md-6 -->
        
        </div>
        <!-- /.row -->
        
      </div><!-- /.container-fluid -->
 
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
    <div class="p-3">
      <h5>Title</h5>
      <p>Sidebar content</p>
    </div>
  </aside>
  <!-- /.control-sidebar -->

  <!-- Main Footer -->
  
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->

<!-- jQuery -->

<!-- Bootstrap 4 -->
<script src="../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="../dist/js/adminlte.min.js"></script>
 </body>
</html>
<script>
var table ;  
$(document).ready(function() { 
 $('#tb2').css('display','none') ;
var staff = $('#staff').val();
var dates = $('#dates').val();
table = $('#datatable-buttons').DataTable({
        dom: 'Bfrtip',
        "ordering": false,
         
        "ajax": {
            url : "<?php echo base_url()?>admin/getdailyreport/",
            data:{'staff':staff,'dates':dates},
            type : 'POST',
        
            error: function(){  
                $("#datatable-buttons tbody tr").css("display","none");
                $("#datatable-buttons").append('<tr><th colspan="9" style="margin:10px auto;">No results.</th></tr>');
            }
        },
    });
 

} );
function loadreport(){
  var staff = $('#staff').val();
var dates = $('#dates').val();
$('#tb1').css('display','none') ;
$('#tb2').css('display','block') ;
table.destroy();
table= $('#datatable-buttons1').DataTable({
        dom: 'Bfrtip',
        "ordering": false,
         
        "ajax": {
            url : "<?php echo base_url()?>admin/getdailyreport/",
            data:{'staff':staff,'dates':dates},
            type : 'POST',
        
            error: function(){  
                $("#datatable-buttons1 tbody tr").css("display","none");
                $("#datatable-buttons1").append('<tr><th colspan="9" style="margin:10px auto;">No results.</th></tr>');
            }
        },
    });
 
 
}
</script>
