<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Admin Page</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">

  <link rel="stylesheet" href="../dist/css/adminlte.min.css">

	<link rel="stylesheet" type="text/css"  href="<?=base_url()?>build/css/intlTelInput.css">
 	<link rel="stylesheet" href="<?=base_url()?>build/css/intlTelInput.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.3/css/intlTelInput.min.css" rel="stylesheet"/>
<script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.3/js/intlTelInput.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.3/js/intlTelInput.min.js"></script>
</head>
<body class="hold-transition sidebar-mini" style="width:auto;min-width:174px">
<div class="wrapper">

<?php include_once('admin_header.php'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Engineer Registration</h1>
          </div><!-- /.col -->
         
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="column">
           
            <div class="card card-primary card-outline"style="width:auto;height:auto;border-radius: 10px;min-width:174px" >
           
              <div class="card-body" style="margin-right:5%">
                  	<?php
						if($this->session->flashdata('staffsuccess')) {	?>
						 <p class="text-success text-center" style="color:white;margin-top: 10px;"> <?=$this->session->flashdata('staffsuccess')?></p>
						<?php } ?>	
             
              <form method="POST"  autocomplete="off" action="<?=base_url('Login_Registration/staffregister')?>" enctype="multipart/form-data">
					
					   	<div class="mb-3">
						   <?php
						if($this->session->flashdata('error2')) {	?>
						 <p class="text-success text-center" style="color:white;margin-top: 10px;"> <?=$this->session->flashdata('error2')?></p>
						<?php } ?>
						    <label for="exampleInputEmail1" class="form-label">Name*</label>
						    <input type="text" placeholder="User Name" style="border-radius:5px;border-color:black;width:357px;height:37px" name="username" class="form-control" id="name" aria-describedby="name" required> 
						  </div>
						  <div class="mb-3">
						    <label for="exampleInputEmail1" class="form-label">Email address*</label>
						    <input type="email"  placeholder="Email" style="border-radius:5px;border-color:black;width:357px;height:37px" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
							<?php
						if($this->session->flashdata('staffemailerror')) {	?>
						 <p class="text-success text-center" style="color:white;margin-top: 10px;"> <?=$this->session->flashdata('emailerror')?></p>
						<?php } ?>
						</div>
						  <div class="mb-3">
						    <label for="exampleInputEmail1"  class="form-label">Communication Email*</label>
						    <input type="email" style="border-radius:5px;border-color:black;width:357px;height:37px" placeholder="Communication Email" name="cemail" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" >
						  </div>
						  <div class="mb-3">
						    <label for="exampleInputEmail1"  class="form-label">Mobile Number*</label><br>
						    <input  type="tel" pattern="^\d{10}$" style="border-radius:5px;border-color:black;width:357px;height:37px" name="phone" class="form-control" id="tel"  placeholder="Mobile Number" aria-describedby="name" required>
						
						  </div>
						  <div class="mb-3">
						    <label for="exampleInputEmail1"  class="form-label">Designation*</label>
						    <input class="form-control" type="text" style="border-radius:5px;border-color:black;width:357px;height:37px" placeholder="Designation" name="designation" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
						  </div>
						  <div class="mb-3">
						    <label for="exampleInputPassword1" class="form-label">Password*</label> <span id="toggle_pwd"class="fa fa-fw fa-eye field_icon" style="color:black;"></span><br>
						    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    				
        					
    						<input class="form-control" type="password" class="passwordbox" name="password_1" placeholder="  Password" style="border-radius:5px;border-color:black;width:357px;height:37px"id="exampleInputPassword1" required />
   							
   							 <script type="text/javascript">
								$(function () {
									$("#toggle_pwd").click(function () {
										$(this).toggleClass("fa-eye fa-eye-slash");
									var type = $(this).hasClass("fa-eye-slash") ? "text" : "password";
										$("#exampleInputPassword1").attr("type", type);
									});
								});
							</script>
						  </div>
						  <div class="mb-3">
						    <label for="exampleInputPassword1" class="form-label">Confirm Password*</label><span id="toggle_pwd2"class="fa fa-fw fa-eye field_icon"style="color:black;"></span><br>
						    
    						<input class="form-control" type="password" class="passwordbox" name="password_2" placeholder=" Confirm Password" onChange="checkPasswordMatch();" style="border-radius:5px;border-color:black;width:357px;height:37px"id="exampleInputPassword2" required />
   							  <div class="registrationFormAlert" id="divCheckPasswordMatch" style="color:red;">
</div>
   							 <script type="text/javascript">
								$(function () {
									$("#toggle_pwd2").click(function () {
										$(this).toggleClass("fa-eye fa-eye-slash");
									var type = $(this).hasClass("fa-eye-slash") ? "text" : "password";
										$("#exampleInputPassword2").attr("type", type);
									});
								});
							</script>
							<?php
						if($this->session->flashdata('stafferror1')) {	?>
						 <p class="text-success text-center" style="margin-top: 10px;"> <?=$this->session->flashdata('error1')?></p>
						<?php } ?>
						  </div>
						  <div class="mb-3">
						    <label for="exampleInputEmail1" class="form-label">Referral ID</label>
						    <input class="form-control" type="text" style="border-radius:5px;border-color:black;width:357px;height:37px"  placeholder="Referral ID" name="referalid" class="form-control" id="name" aria-describedby="exampleInputEmail1">
						  </div>
						  <div class="mb-3">
						    <label for="exampleInputEmail1" class="form-label">Address</label>
						    <textarea class="form-control" id="w3review" name="address" rows="4" cols="50" placeholder="Address"></textarea>
						  </div>
						  <div class="mb-3">
						    <label for="exampleInputEmail1" class="form-label">Pin Code*</label>
						    <input class="form-control" type="text" style="border-radius:5px;border-color:black;width:357px;height:37px" placeholder="Pin Code" name="pincode" class="form-control" id="name" aria-describedby="exampleInputEmail1" >
						  </div>
						  <div class="mb-3">
						  <label for="maintext" class="form-label">Upload Photo </label>
                        <input class="form-control" style="border-radius:5px;border-color:black;width:357px;height:37px" name="image" type="file" id="image"   onchange="checkextension()" >

  <span id='message1'></span>
						  </div>
						  <div class="mb-3">
						        <td> <label for="maintext" class="form-label">Upload ID Proof </label></td>
                        <td> <input class="form-control" style="border-radius:5px;border-color:black;width:357px;height:37px" name="imge" type="file" id="image1"   onchange="checkextension1()" >

  <span id='message2'></span></td>
						     </div>
						 <div class="text-center">
						  <button type="submit" class="btn btn-primary">Register Now</button>
						</div>

						</form>
             
              </div>
            </div><!-- /.card -->
          </div>
          <!-- /.col-md-6 -->
        
        </div>
        <!-- /.row -->
                        <script>
    function checkextension() {
          $('#image').css('display', 'block'); 
          
  var file = document.querySelector("#image");
  if ( /\.(jpe?g|png|gif|jpg|jpeg)$/i.test(file.files[0].name) === false ) {   $('#message1').html('Not an Image').css('color', 'red'); }else{
       $('#message1').html('Ready to Upload').css('color', 'green');
  }
}
</script>    
 <script>
    function checkextension1() {
          $('#image1').css('display', 'block'); 
         
  var file = document.querySelector("#image1");
  if ( /\.(jpe?g|png|gif|jpg|jpeg)$/i.test(file.files[0].name) === false ) {   $('#message2').html('Not an Image').css('color', 'red'); }else{
       $('#message2').html('Ready to Upload').css('color', 'green');
  }
}
</script> 
      </div><!-- /.container-fluid -->
    
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
    <div class="p-3">
      <h5>Title</h5>
      <p>Sidebar content</p>
    </div>
  </aside>
  <!-- /.control-sidebar -->

  <!-- Main Footer -->
  
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->

 
<!-- Bootstrap 4 -->
<script src="../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="../dist/js/adminlte.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
 
<script>
  

function checkPasswordMatch() {
    var password = $("#exampleInputPassword1").val();
    var confirmPassword = $("#exampleInputPassword2").val();

    if (password != confirmPassword){
        $("#divCheckPasswordMatch").html("Passwords do not match!");
    }
    else{
        $("#divCheckPasswordMatch").html("");
    }
}

$(document).ready(function () {
   $("#exampleInputPassword1, #exampleInputPassword2").keyup(checkPasswordMatch);
});

</script>
</body>
</html>
