<style>



body {
 background-image: url("https://enviragallery.com/wp-content/uploads/2020/01/How-to-make-a-background-white.png");
 background-color: #cccccc;
 background-size:cover;
}
    
    
    
</style>
      
      <div class="w3-container w3-light-grey" style="padding:128px 16px" id="login">
          
          
          
          
          
          
          
  <h3 class="w3-center" style="margin-left:50%;margin-top:5%;">LOGIN</h3>
  <div style="margin-top:-50px">
      	<?php
						if($this->session->flashdata('error')) {	?>
						 <p class="text-danger text-center" style="margin-left:50%;margin-top:5%;color:red" > <?=$this->session->flashdata('error')?></p>
						<?php } ?>
    <br>
   <form method="post" autocomplete="off" action="<?=base_url('Login_Registration/loginnow')?>" style="margin-left:40%;">
      <p><input type="text" placeholder="Email" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" style="background-color: rgba(255,255,255,0.5);border-radius: 5px 0px 0px 5px;border-color:black;width:50%;height:35px" required></p>
      <p><input type="password" id="exampleInputPassword1" placeholder="Password" name="password_1" class="form-control"  aria-describedby="emailHelp" style="background-color: rgba(255,255,255,0.5);border-radius: 5px 0px 0px 5px;border-color:black;width:50%;height:35px" required>
</p>
      <p> <div class="input-group-append">
            Show Password <input style="margin-top:5px" type="checkbox" onclick="myFunction()" >
            </div></p>
      <script>
function myFunction() {
  var x = document.getElementById("exampleInputPassword1");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
</script>
        <button class="w3-button w3-black" type="submit">
          Login Now
        </button>
      </p>
    </form>
    
   <p style="margin-left:40%;">New Member?</p> <a style="margin-left:40%;" href="<?=base_url()?>Login_Registration/nextpage"> Signup</a>
    
							<?php
						if($this->session->flashdata('statuserror')) {	?>
						 <p class="text-danger text-center" > <?=$this->session->flashdata('statuserror')?></p>
						<?php } ?>
  </div>
</div>
      
      
      