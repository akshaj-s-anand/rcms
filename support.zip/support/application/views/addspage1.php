<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Solar Section </title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<div class="m-4">
    <h4>Add Solar Section</h4>
    
    
    
    
    
    
     <div class="w3-half" style="margin-top:10%;margin-left:10%;">
                 <form role="form" method="post" action="<?=base_url('Welcome/addimage24')?>" enctype="multipart/form-data">
                     <?php foreach($image7->result() as $row){ ?>
                      <input type="hidden"  value="<?php echo $row->image; ?>" name="old" class="form-control" id="old"> <?php } ?> 
              <div class="panel">
                <div class="panel-body">
                  <div class="dsp form-group">
                <label>CHOOSE FOR FIRST  IMAGE</label>
                <input class="form-control" type="file" name="image24" />
            </div>
     
             <div class="dsp form-group">
                <input type="submit" class="btn btn-warning" name="membersubmit24" value="Submit">
            </div>
        </div>
    </div>
</form>
           

               
                
          </div>
          
          
          
          
           <div class="w3-half" style="margin-top:10%;margin-left:10%;">
                 <form role="form" method="post" action="<?=base_url('Welcome/addimage25')?>" enctype="multipart/form-data">
                     <?php foreach($image7->result() as $row){ ?>
                      <input type="hidden"  value="<?php echo $row->image2; ?>" name="old" class="form-control" id="old"> <?php } ?> 
              <div class="panel">
                <div class="panel-body">
                  <div class="dsp form-group">
                <label>CHOOSE FOR SECOND  IMAGE</label>
                <input class="form-control" type="file" name="image25" />
            </div>
     
             <div class="dsp form-group">
                <input type="submit" class="btn btn-warning" name="membersubmit25" value="Submit">
            </div>
        </div>
    </div>
</form>
           

               
                
          </div>
          
          
          
          
          
          
           <div class="w3-half" style="margin-top:10%;margin-left:10%;">
                 <form role="form" method="post" action="<?=base_url('Welcome/addimage26')?>" enctype="multipart/form-data">
                     <?php foreach($image7->result() as $row){ ?>
                      <input type="hidden"  value="<?php echo $row->image3; ?>" name="old" class="form-control" id="old"> <?php } ?> 
              <div class="panel">
                <div class="panel-body">
                  <div class="dsp form-group">
                <label>CHOOSE FOR THIRD  IMAGE</label>
                <input class="form-control" type="file" name="image26" />
            </div>
     
             <div class="dsp form-group">
                <input type="submit" class="btn btn-warning" name="membersubmit26" value="Submit">
            </div>
        </div>
    </div>
</form>
           

               
                
          </div>
          
          
          
           <div class="w3-half" style="margin-top:10%;margin-left:10%;">
                 <form role="form" method="post" action="<?=base_url('Welcome/addimage27')?>" enctype="multipart/form-data">
                     <?php foreach($image7->result() as $row){ ?>
                      <input type="hidden"  value="<?php echo $row->image4; ?>" name="old" class="form-control" id="old"> <?php } ?> 
              <div class="panel">
                <div class="panel-body">
                  <div class="dsp form-group">
                <label>CHOOSE FOR 4TH  IMAGE</label>
                <input class="form-control" type="file" name="image27" />
            </div>
     
             <div class="dsp form-group">
                <input type="submit" class="btn btn-warning" name="membersubmit27" value="Submit">
            </div>
        </div>
    </div>
</form>
           

               
                
          </div>
          
          
          
           <div class="w3-half" style="margin-top:10%;margin-left:10%;">
                 <form role="form" method="post" action="<?=base_url('Welcome/addimage28')?>" enctype="multipart/form-data">
                     <?php foreach($image7->result() as $row){ ?>
                      <input type="hidden"  value="<?php echo $row->image5; ?>" name="old" class="form-control" id="old"> <?php } ?> 
              <div class="panel">
                <div class="panel-body">
                  <div class="dsp form-group">
                <label>CHOOSE FOR 5TH  IMAGE</label>
                <input class="form-control" type="file" name="image28" />
            </div>
     
             <div class="dsp form-group">
                <input type="submit" class="btn btn-warning" name="membersubmit28" value="Submit">
            </div>
        </div>
    </div>
</form>
           

               
                
          </div>
          
          
          
          
          <div class="w3-half" style="margin-top:10%;margin-left:10%;">
                 <form role="form" method="post" action="<?=base_url('Welcome/addimage29')?>" enctype="multipart/form-data">
                     <?php foreach($image7->result() as $row){ ?>
                      <input type="hidden"  value="<?php echo $row->image6; ?>" name="old" class="form-control" id="old"> <?php } ?> 
              <div class="panel">
                <div class="panel-body">
                  <div class="dsp form-group">
                <label>CHOOSE FOR 6TH  IMAGE</label>
                <input class="form-control" type="file" name="image29" />
            </div>
     
             <div class="dsp form-group">
                <input type="submit" class="btn btn-warning" name="membersubmit29" value="Submit">
            </div>
        </div>
    </div>
</form>
           

               
                
          </div>
          
          
          
          
           <div class="w3-half" style="margin-top:10%;margin-left:10%;">
                 <form role="form" method="post" action="<?=base_url('Welcome/addimage30')?>" enctype="multipart/form-data">
                     <?php foreach($image7->result() as $row){ ?>
                      <input type="hidden"  value="<?php echo $row->image7; ?>" name="old" class="form-control" id="old"> <?php } ?> 
              <div class="panel">
                <div class="panel-body">
                  <div class="dsp form-group">
                <label>CHOOSE FOR 7TH  IMAGE</label>
                <input class="form-control" type="file" name="image30" />
            </div>
     
             <div class="dsp form-group">
                <input type="submit" class="btn btn-warning" name="membersubmit30" value="Submit">
            </div>
        </div>
    </div>
</form>
           

               
                
          </div>
          
          
          
          
           <div class="w3-half" style="margin-top:10%;margin-left:10%;">
                 <form role="form" method="post" action="<?=base_url('Welcome/addimage31')?>" enctype="multipart/form-data">
                     <?php foreach($image7->result() as $row){ ?>
                      <input type="hidden"  value="<?php echo $row->image8; ?>" name="old" class="form-control" id="old"> <?php } ?> 
              <div class="panel">
                <div class="panel-body">
                  <div class="dsp form-group">
                <label>CHOOSE FOR 8TH  IMAGE</label>
                <input class="form-control" type="file" name="image31" />
            </div>
     
             <div class="dsp form-group">
                <input type="submit" class="btn btn-warning" name="membersubmit31" value="Submit">
            </div>
        </div>
    </div>
</form>
           

               
                
          </div>
          
          
          
          
           <div class="w3-half" style="margin-top:10%;margin-left:10%;">
                 <form role="form" method="post" action="<?=base_url('Welcome/addimage32')?>" enctype="multipart/form-data">
                     <?php foreach($image7->result() as $row){ ?>
                      <input type="hidden"  value="<?php echo $row->image9; ?>" name="old" class="form-control" id="old"> <?php } ?> 
              <div class="panel">
                <div class="panel-body">
                  <div class="dsp form-group">
                <label>CHOOSE FOR 9TH  IMAGE</label>
                <input class="form-control" type="file" name="image32" />
            </div>
     
             <div class="dsp form-group">
                <input type="submit" class="btn btn-warning" name="membersubmit32" value="Submit">
            </div>
        </div>
    </div>
</form>
           

               
                
          </div>
          
          
          
          
          <div class="w3-half" style="margin-top:10%;margin-left:10%;">
                 <form role="form" method="post" action="<?=base_url('Welcome/addimage33')?>" enctype="multipart/form-data">
                     <?php foreach($image7->result() as $row){ ?>
                      <input type="hidden"  value="<?php echo $row->image10; ?>" name="old" class="form-control" id="old"> <?php } ?> 
              <div class="panel">
                <div class="panel-body">
                  <div class="dsp form-group">
                <label>CHOOSE FOR 10TH  IMAGE</label>
                <input class="form-control" type="file" name="image33" />
            </div>
     
             <div class="dsp form-group">
                <input type="submit" class="btn btn-warning" name="membersubmit33" value="Submit">
            </div>
        </div>
    </div>
</form>
           

               
                
          </div>
          
          
          
    <form method="post" action="<?=base_url()?>Welcome/addSliderHome14" enctype="multipart/form-data">
       
        
        <div class="mb-3">
            <label class="form-label" for="inputPassword">Add 1st Product's Name</label>
            <input type="text" class="form-control" name="tit1" id="inputPassword" placeholder="Title 1" required>
        </div>
        
     
        
         <div class="mb-3">
            <label class="form-label" for="inputPassword">Add 2nd Product's Name</label>
            <input type="text" class="form-control" name="tit2" id="inputPassword" placeholder="Title 1" required>
        </div>
        
       
        
        
         <div class="mb-3">
            <label class="form-label" for="inputPassword">Add 3rd Product's Name</label>
            <input type="text" class="form-control" name="tit3" id="inputPassword" placeholder="Title 1" required>
        </div>
        
        
        
         
         <div class="mb-3">
            <label class="form-label" for="inputPassword">Add 4th Product's Name</label>
            <input type="text" class="form-control" name="tit4" id="inputPassword" placeholder="Title 1" required>
        </div>
        
        
        
         
         <div class="mb-3">
            <label class="form-label" for="inputPassword">Add 5th Product's Name</label>
            <input type="text" class="form-control" name="tit5" id="inputPassword" placeholder="Title 1" required>
        </div>
        
        
        
        
         
         <div class="mb-3">
            <label class="form-label" for="inputPassword">Add 6th Product's Name</label>
            <input type="text" class="form-control" name="tit6" id="inputPassword" placeholder="Title 1" required>
        </div>
        
        
        
         
         <div class="mb-3">
            <label class="form-label" for="inputPassword">Add 7th Product's Name</label>
            <input type="text" class="form-control" name="tit7" id="inputPassword" placeholder="Title 1" required>
        </div>
        
        
        
         
         <div class="mb-3">
            <label class="form-label" for="inputPassword">Add 8th Product's Name</label>
            <input type="text" class="form-control" name="tit8" id="inputPassword" placeholder="Title 1" required>
        </div>
        
        
        
         
         <div class="mb-3">
            <label class="form-label" for="inputPassword">Add 9th Product's Name</label>
            <input type="text" class="form-control" name="tit9" id="inputPassword" placeholder="Title 1" required>
        </div>
        
        
        
        
         
         <div class="mb-3">
            <label class="form-label" for="inputPassword">Add 10th Product's Name</label>
            <input type="text" class="form-control" name="tit10" id="inputPassword" placeholder="Title 1" required>
        </div>
        
        
       
        
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>
</body>
</html>