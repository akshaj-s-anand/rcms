<?php echo $this->session->flashdata('success_msg'); ?>
<?php echo $this->session->flashdata('error_msg'); ?>
<form role="form" method="post" action="<?=base_url('Customer/add')?>" enctype="multipart/form-data">
    <div class="panel">
        <div class="panel-body">
            <div class="dsp form-group">
                <label>Insert Image</label>
                <input class="form-control" type="file" name="profile_img" />
            </div>
     
             <div class="dsp form-group">
                <input type="submit" class="btn btn-warning" name="membersubmit" value="Submit">
            </div>
        </div>
    </div>
</form>
<div class="row">
<?php
						foreach($image->result() as $row) {?>
                            
                                <div class="column">

                         <?php   echo '<img style="width:200px;height:200px" src="../uploads/images/'.$row->profile_img.'" />'; ?> <br>
                         <?php echo $row->email;?> <br>
                         <?php echo $row->username;?> 
                        </div>
                   
<?php } ?>

</div>
 <div>
                <a href="<?=base_url('Customer/homepage')?>">Back</a>
            </div>
						