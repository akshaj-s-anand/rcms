<!DOCTYPE html>
<html lang="en">
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>Orion Technologies | Best inverter with battery and solar panels in Calicut, Kerala</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- bootstrap css -->
      <link rel="stylesheet" href="<?=base_url()?>css/bootstrap.min.css">
      <!-- style css -->
      <link rel="stylesheet" href="<?=base_url()?>css/style.css">
      <!-- Responsive-->
      <link rel="stylesheet" href="<?=base_url()?>css/responsive.css">
      <!-- fevicon -->
      <link rel="icon" href="<?=base_url()?>images/fevicon.png" type="image/gif" />
      <!-- Scrollbar Custom CSS -->
      <link rel="stylesheet" href="<?=base_url()?>css/jquery.mCustomScrollbar.min.css">
      <!-- Tweaks for older IEs-->
      <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
   
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
      <style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  min-width:500px;

}
.button1 {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 5px 20px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  transition-duration: 0.4s;
  cursor: pointer;
}

.button2 {
  background-color: white; 
  color: black; 
  border: 2px solid #007FFF;
}

.button2:hover {
  background-color: #007FFF;
  color: white;
}
.topnav {
  overflow: hidden;
  background-color: white;
  color:black;
  width:800px;
}

.topnav a {
  float: left;
  display: block;
  color: black;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: yellow;
  color: black;
}

.topnav a.active {
  background-color: yellow;
  color: black;
}

.topnav .icon {
  display: none;
}

@media screen and (max-width: 600px) {
    .topnav {
width:100%;

}
  .topnav a:not(:first-child) {display: none;}
  .topnav a.icon {
    float: right;
    display: block;
  }
 a.complaintbar{
      display:block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
}




.ourproject{
	padding: 100px 0;
}

.project-single{
	position: relative;
	margin-bottom: 30px;	
}

.project-overlay{
	position: absolute;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	background: rgba(0,0,0,0.33);
	padding: 30px;
}

.project-overlay h3{
	color: #fff;
	font-size: 18px;
	font-weight: 500;
	font-family: 'Montserrat', sans-serif;
}

.project-overlay p{
	color: #fff;
	font-size: 14px;
	font-weight: 300;
	margin-bottom: 8px;
}

.completed-project{
	position: relative;
	background: url(../images/solara.jpg) no-repeat center center;
	background-size: cover;
	padding: 100px 0 80px;
}

.completed-project:before{
	content: '';
	display: block;
	position: absolute;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	background: rgba(15,36,64,0.84);
}

.completed-title{
	margin-bottom: 60px;
	text-align: center;
}

.completed-title h2{
	font-size: 34px;
	color: #fff;
	text-transform: uppercase;
}

.completed-single{
	text-align: center;
}

.completed-single h3{
	color: #fff;
	font-size: 50px;
	font-family: 'Montserrat', sans-serif;
	margin-bottom: 0;
}

.completed-single p{
	color: #fff;
	font-size: 20px;
}

/*  Request Contact Form area css  */

.request-callback{
	padding: 100px 0;
}

.request-form .form-group{
	margin-bottom: 30px;
}

.request-form .form-control{
	border: none;
	box-shadow: none;
	background: #e7e4e4;
	border-radius: 0;
	height: auto;
	padding: 12px 20px;
}

.btn-request{
	display: block;
	background: #0f2440;	
	color: #fff;
	border: none;
	width: 100%;
	text-transform: uppercase;
	font-weight: 300;
	padding: 12px;
	font-size: 14px;
	letter-spacing: 0.1em;
	transition: all 0.3s;
}

.btn-request:hover{
	background: #000;
}

.contact-information{
	background: #223a5a;
	padding: 30px 0;
}

.contact-single{
	text-align: center;
}

.contact-single p{
	color: #fff;
	font-size: 20px;
	font-weight: 300;
	margin-bottom: 0;
}

.contact-single i{
	margin-right: 10px;
}



.container1 {
  position: relative;
  text-align: center;
  color: white;
}


.centered {
  position: absolute;
 
  left: 50%;
  transform: translate(-50%, -110%);
}
.button28 {
  background-color: #f4511e;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;

  cursor: pointer;
  width:100%;
  -webkit-transition-duration: 0.4s; /* Safari */
transition: all 0.5s ease;
}



.button24:hover {
  box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24),0 17px 50px 0 rgba(0,0,0,0.19);
  margin-left:10px;
 
}
.serv {
 
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
height:400px;
  cursor: pointer;
 
  -webkit-transition-duration: 0.4s; /* Safari */
transition: all 0.5s ease;
}



.serv:hover {
  box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24),0 17px 50px 0 rgba(0,0,0,0.19);
 
 
}
.column2 {
  float: left;
  width: 50%;
  padding: 0 10px;
    margin-bottom: 40px;
}

/* Remove extra left and right margins, due to padding */
.row2 {margin: 0 -5px;}

/* Clear floats after the columns */
.row2:after {
  content: "";
  display: table;
  clear: both;
  margin-left:20px;
}
 
/* Responsive columns */
@media screen and (max-width: 600px) {
  .column2 {
    width: 100%;
    display: block;
    margin-bottom: 40px;
    margin-left:20px;
  }
 

/* Style the counter cards */
.card2 {
 
  padding: 16px;
  text-align: center;
   margin-bottom: 20px;
margin-left:5px;
}

</style>
   </head>
   <!-- body -->
   <body class="main-layout">
      <!-- loader  -->
      
      <!-- end loader --> 
      <!-- header -->
      <header>
         <!-- header inner -->
         <div class="header">
         <div class="container">
            <div class="row">
               <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
                  <div class="full">
                     <div class="center-desk">
                        <div class="logo"> <a href=""><img src="images/logo-2.png" alt="logo"/></a> </div>
                     </div>
                  </div>
               </div>
               <div class="col-xl-7 col-lg-7 col-md-9 col-sm-9">
                 




<div class="topnav" id="myTopnav">
   <a class="active" href="#home">Home</a>
  <a href="<?=base_url('Login_Registration/about')?>">About</a>
  <a href="<?=base_url('Welcome/services')?>">Services</a>
  <a href="<?=base_url('Welcome/selectpro')?>">Products</a>
  <a href="<?=base_url('Login_Registration/blog')?>">Brand</a>
  <a href="<?=base_url('Login_Registration/contact')?>">Contact</a>
   
 
      <a class="dropdown-toggle"  data-toggle="dropdown" href="#">Complaint</a>
      <div class="dropdown-menu" style="background-color:white;margin-top:50px">
        <a class="dropdown-item" href="<?=base_url('Customer/complaint')?>">Register Complaint</a>
         <a class="dropdown-item" data-toggle="modal" data-target="#myModal">View Complaint Status</a>
        </div>
    <a  href="<?=base_url('Login_Registration/login')?>">Login</a>
 

  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars"></i>
  </a>
</div>
               </div>
             
            </div>
         </div>
         <!-- end header inner --> 
      </header>
      <!-- end header -->
      <section class="slider_section"   >
         <div id="main_slider" class="carousel slide banner-main" data-ride="carousel" >
             
             
            

            <div class="carousel-inner" style="min-height:500px;">
               <div class="carousel-item active">
                  <img class="first-slide" src="<?php foreach($image1->result() as $row){ echo base_url()."/images/".$row->image; } ?>" alt="First slide"><br>
                  <div class="container">
                     <div class="carousel-caption relative">
                        <h1>  <?php foreach($a->result() as $row) {?> <?php echo $row->title; ?> <?php  } ?><br> <strong class="black_bold">  <?php foreach($a->result() as $row) {?> <?php echo $row->stitle; ?> <?php  } ?></strong></h1><br>
                           <h1><strong class="yellow_bold">  <?php foreach($a->result() as $row) {?> <?php echo $row->title2; ?> <?php  } ?></strong></h1>
                        
                        <a  href="#">see more Products</a>
                     </div>
                  </div>
               </div>
               <div class="carousel-item" style="min-height:500px;">
                  <img class="second-slide" src="<?php foreach($image1->result() as $row){ echo base_url()."/images/".$row->image2; } ?>" alt="Second slide">
                  <div class="container">
                     <div class="carousel-caption relative">
                        <h1>  <?php foreach($a->result() as $row) {?> <?php echo $row->title; ?> <?php  } ?><br> <strong class="black_bold">  <?php foreach($a->result() as $row) {?> <?php echo $row->stitle; ?> <?php  } ?></strong></h1><br>
                           <h1><strong class="yellow_bold">  <?php foreach($a->result() as $row) {?> <?php echo $row->title2; ?> <?php  } ?></strong></h1>
                        
                        <a  href="#">see more Products</a>
                     </div>
                  </div>
               </div>
               <div class="carousel-item" style="min-height:500px;">
                  <img class="third-slide" src="<?php foreach($image1->result() as $row){ echo base_url()."/images/".$row->image3; } ?>" alt="Third slide">
                  <div class="container">
                    <div class="carousel-caption relative">
                        <h1>  <?php foreach($a->result() as $row) {?> <?php echo $row->title; ?> <?php  } ?><br> <strong class="black_bold">  <?php foreach($a->result() as $row) {?> <?php echo $row->stitle; ?> <?php  } ?></strong></h1><br>
                           <h1><strong class="yellow_bold">  <?php foreach($a->result() as $row) {?> <?php echo $row->title2; ?> <?php  } ?></strong></h1>
                            <h1><strong class="yellow_bold">  <?php foreach($a->result() as $row) {?> <?php echo $row->title2; ?> <?php  } ?></strong></h1>
                        
                        <a  href="#">see more Products</a>
                     </div>
                  </div>
               </div>

            </div>
            <a class="carousel-control-prev" href="#main_slider" role="button" data-slide="prev">
            <i class='fa fa-angle-right'></i>
            </a>
            <a class="carousel-control-next" href="#main_slider" role="button" data-slide="next">
            <i class='fa fa-angle-left'></i>
            </a>
            
         </div>

      </section>

 <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
            <h6>Get Your Complaint Status</h6>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          
        </div>
        <div class="modal-body">
        <form method="post" autocomplete="off" onsubmit="submitForm(event)" action="<?=base_url('Ticketresponse/complaintstatus')?>">
         <input value="" id="count" hidden >       
       <input type="text" placeholder="Enter The Complaint Id" name="tickid" class="form-control" id="tickidnum" aria-describedby="emailHelp" style="background-color: rgba(255,255,255,0.5);border-radius: 5px 0px 0px 5px;border-color:transparent;height:35px" >
        <input type="text" placeholder="Your Registered Mobile Number" name="phone" class="form-control"aria-describedby="emailHelp" style="background-color: rgba(255,255,255,0.5);border-radius: 5px 0px 0px 5px;border-color:transparent;height:35px" >
       <button  class="button1" type="submit" >Submit</button> 
       
          </form>
        </div>
        <div class="modal-footer">
             <a style="color:blue" data-toggle="modal" data-target="#myModal1">Forgot Complaint Id?</a>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
    
  </div>
  <div class="modal fade" id="myModal1" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
            <h6>Get Your Complaint Status</h6>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          
        </div>
        <div class="modal-body">
         <form method="post" autocomplete="off" onsubmit="submitForm(event)" action="<?=base_url('Ticketresponse/viewall')?>">
         <input value="" id="count" hidden >       
       <input type="text" placeholder="Your Registered Mobile Number" name="phone" class="form-control"aria-describedby="emailHelp" style="background-color: rgba(255,255,255,0.5);border-radius: 5px 0px 0px 5px;border-color:transparent;height:35px" >
       <button  class="button1" type="submit" >Submit</button> 
       
          </form>
        </div>
        <div class="modal-footer">
            
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
    
  </div>

<!-- CHOOSE  -->
      <div class="whyschose">
         <div class="container">

            <div class="row">
               <div class="col-md-7 offset-md-3">
                  <div class="title">
                     <h2> <strong class="black">ORION TECHNOLOGIES SERVICES</strong></h2>
                     <span>We provide the perfect service for you.</span>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="choose_bg">
         <div class="container">
            <div class="white_bg">
            <div class="row">
               <dir class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
                  <div class="for_box">
                     <i><img src="<?php foreach($image2->result() as $row){ echo base_url()."/images/".$row->image; } ?>"/></i>
                     <h3><?php foreach($b->result() as $row) {?> <?php echo $row->title; ?> <?php  } ?></h3>
                     <p><?php foreach($b->result() as $row) {?> <?php echo $row->stitle; ?> <?php  } ?></p>
                  </div>
               </dir>
               <dir class="col-xl-3 col-lg-3 col-md-6 col-sm-12" style="margin-left:10%;">
                  <div class="for_box">
                     <i><img src="<?php foreach($image2->result() as $row){ echo base_url()."/images/".$row->image2; } ?>"/></i>
                     <h3><?php foreach($b->result() as $row) {?> <?php echo $row->title2; ?> <?php  } ?></h3>
<p><?php foreach($b->result() as $row) {?> <?php echo $row->stitle2; ?> <?php  } ?></p>                  </div>
               </dir>
               <dir class="col-xl-3 col-lg-3 col-md-6 col-sm-12" style="margin-left:10%;">
                  <div class="for_box">
                     <i><img src="<?php foreach($image2->result() as $row){ echo base_url()."/images/".$row->image3; } ?>"/></i>
                     <h3><?php foreach($b->result() as $row) {?> <?php echo $row->title3; ?> <?php  } ?></h3>
<p><?php foreach($b->result() as $row) {?> <?php echo $row->stitle3; ?> <?php  } ?></p>                  </div>
               </dir>
              
               <div class="col-md-12">
                  <a class="read-more">Read More</a>
               </div>
            </div>
         </div>
       </div>
      </div>
<!-- end CHOOSE -->
  <div class="service">
         <div class="container">
           
           	<section class="banner" id="home">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="about-company">
						<div class="row no-gutters">
						  		<div class="col-md-4" style="margin-left:0%;">
								<!-- About Description start -->
								<div class="about-description">
									<div class="row2">
  <div class="column2 serv">
    <div class="card2">
        <img   src="../images/b1.png">
     <h3><b>Inverter Load Calculator</b></h3>
    <h6 style="color:#9ba39d">How to choose a reliable Inverter and battery or inverter with battery for your home and office?, Calculate your load.</h6>
    </div>
  </div>

  <div class="column2 serv">
    <div class="card2">
    <img  src="../images/b2.png">
       <h3 style="margin-top:10px"  ><b>Dealer Locator</b></h3>
     <h6 style="color:#9ba39d">Locate the nearest inverter, battery and solar product dealer in your city...! Your nearest car battery dealer, inverter battery dealer, exide battery dealers, find all here. Your one stop dealer hub</h6>
    </div>
  </div>
  
  <div class="column2 serv">
    <div class="card2">
    <img   src="../images/b3.png">
    <h3><b>Service Support</b></h3>
      <h6 style="color:#9ba39d">If you have any Product related doubts/queries, just click on the link below and we will be happy to revert back to you. Our help centre is open for 24x7. Dedicated customer service team for live support rescue.</h6>
    </div>
  </div>
  
  <div class="column2 serv">
    <div class="card2">
    <img  src="../images/b4.png">
         <h3 style="margin-top:10px"  ><b>Enquire Now</b></h3>
        <h6 style="color:#9ba39d">Dear Customer, welcome to Orion Technologies Customer Care Section!! We value our customer and will be happy to assist you. Enrol now for instant assistance.</h6>
    </div>
  </div>
</div>
							
									
								
								</div>
								<!-- About Description end -->
							</div>  
						   
						 
							<div class="col-md-7" style="margin-left:20px">
								<!-- About image start -->
								<div class="container12" style="  position: relative;color: white;">
								    
								<img style="height:900px;" src="<?php foreach($image3->result() as $row){ echo base_url()."/images/".$row->image; } ?>"	>
								 <div class="centered" style="position: absolute;top: 6%;left: 6%;transform: translate(-2%, -0%);background: rgba(0, 0, 0, 0.6)">
						
                 
                    <div style="display:flex;flex-direction:row"><div style="height:16px;width:50px; border-bottom: 4px solid red;margin-right:15px"  ></div> <h6 style="color:white">ABOUT ORION TECHNOLOGIES</h6></div>
                    <h4 style="color:white"><b>Orion Technologies Is The Leading Power Backup Solution Company In Kerala.</b></h4> 
                    <p  style="line-height: 1.6;color:white;margin:10px;font-size:17px;font-family: "Times New Roman", Times, serif;">Orion technologies is a company established in the year 1999. We are the main dealers of Inverter, UPS and Batteries, 
                    power backup systems and solar system, different types of solar panels, solar on grid system and off grid system etc., across Calicut (Kozhikode), 
                    Wayanad, Malappuram, Palakkad. Orion is the authorised dealers of best class quality automobile batteries, best inverter battery, inverter with battery, best water heater, 
                    solar system, and ups dealers. Available automobile batteries for all vehicles. The best car battery dealers near you, we have dealers and service support all over Kerala.
                    For solar panel installation and services, choosing best types of solar panels for your home. Years of successful experience in installation of solar panels and in solar system projects.
                    Orion technologies head-quartered at Calicut, India. Presently we have a team of 30+ skilled professionals. We are specialized and mastered in installation, 
                    configuration and maintenance of all types of power backup systems (Inverter, UPS, Batteries, Solar Products…) available in the market today.</p>
               <button class="button28 button24" onclick="location.href='<?=base_url('Login_Registration/about')?>'" >Read More</button>
               
						
								</div>
								<!-- About image end -->
							</div>
							
					
							
						
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
         </div>
      </div>
      <!-- service --> 
      <div class="service">
         <div class="container">
            <div class="row">
               <div class="col-md-8 offset-md-2">
                  <div class="title">
                     <h2><strong class="black">ABOUT ORION TECHNOLOGIES</strong></h2>
                     <span>Orion Technologies Is The Leading Power Backup Solution Company In Kerala.</span>
                  </div>
               </div>
            </div>
           	<section class="banner" id="home">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="about-company">
						<div class="row no-gutters">
						    
						   
							<div class="col-md-8">
								<!-- About image start -->
								<div class="about-image">
								<img src="<?php foreach($image3->result() as $row){ echo base_url()."/images/".$row->image; } ?>"	>
								</div>
								<!-- About image end -->
							</div>
							
							<div class="col-md-4" style="margin-left:0%;">
								<!-- About Description start -->
								<div class="about-description">
									
									<p><b><?php foreach($c->result() as $row) {?> <?php echo $row->title; ?> <?php  } ?></b></p>
									
								
								</div>
								<!-- About Description end -->
							</div>
							
						
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
         </div>
      </div>
      <!-- end service -->
      
      
      
      	<section class="completed-project">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="completed-title">
						<h2>Installation & Project Development</h2>
					</div>
				</div>
			</div>
			
			<div class="row" style="margin-left:30%;">
				<div class="col-md-3 col-sm-6">
					<!-- State Counter Single start -->
					<div class="completed-single">
						<h3 class="counter">+150</h3>
						<p>Projects</p>
					</div>
					<!-- State Counter Single end -->
				</div>
				
				<div class="col-md-3 col-sm-6">
					<!-- State Counter Single start -->
					<div class="completed-single">
						<h3 class="counter">+5</h3>
						<p>Cities</p>
					</div>
					<!-- State Counter Single end -->
				</div>
				
			
			</div>
		</div>
	</section>
      
      
      
      
      

      <!-- our product -->
     
         <!-- testimonial section starts-->
         
         <!-- testimonial section ends-->

         <div class="container">
            <div class="yellow_bg">
            <div class="row">
               <div class="col-xl-7 col-lg-7 col-md-7 col-sm-12">
                  <div class="yellow-box">
                     <h3>REQUEST A FREE QUOTE<i><img src="icon/calll.png"/></i></h3>
                     
                     <p>Get answers and advice from people you want it from.</p>
                  </div>
               </div>
                <div class="col-xl-5 col-lg-5 col-md-5 col-sm-12">
                  <div class="yellow-box">
                     <a href="#">Get  Quote</a>
                  </div>
               </div>
            </div>
         </div>
         </div>
      </div>
      
      

      <!-- end our product -->
      <!-- map -->
      <div class="container-fluid padi">
         <div class="map">
            <img src="images/mapimg.jpg" alt="img"/>
         </div>
      </div>
      <!-- end map --> 
      <!--  footer --> 




      <footr>
         <div class="footer">
            <div class="container">
               <div class="row">
                  <div class="col-md-6 offset-md-3">
                     <ul class="sociel">
                         <li> <a href="#"><i class="fa fa-facebook-f"></i></a></li>
                         <li> <a href="#"><i class="fa fa-twitter"></i></a></li>
                         <li> <a href="#"><i class="fa fa-instagram"></i></a></li>
                         <li> <a href="#"><i class="fa fa-instagram"></i></a></li>
                     </ul>
                  </div>
            </div>
            <div class="row">
               <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
                  <div class="contact">
                     <h3>conatct us</h3>
                     <span>Building No. 44/3014, Kuniyilkave Road<br/> Ashokapuram, Calicut-673006<br>
                        Mob : +91 9447385870</span>
                  </div>
               </div>
                 <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
                  <div class="contact">
                     <h3>ADDITIONAL LINKS</h3>
                     <ul class="lik">
                         <li> <a href="#">About us</a></li>
                         <li> <a href="#">Terms and conditions</a></li>
                         <li> <a href="#">Privacy policy</a></li>
                         <li> <a href="#">News</a></li>
                          <li> <a href="#">Contact us</a></li>
                     </ul>
                  </div>
               </div>
                 <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
                  <div class="contact">
                     <h3>service</h3>
                      <ul class="lik">
                    <li> <a href="#"> Data recovery</a></li>
                         <li> <a href="#">Computer repair</a></li>
                         <li> <a href="#">Mobile service</a></li>
                         <li> <a href="#">Network solutions</a></li>
                          <li> <a href="#">Technical support</a></li>
                  </div>
               </div>
                 <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
                  <div class="contact">
                     <h3>About lighten</h3>
                     <span>Customercare Services  refers to the assistance an organization offers to its customers before or after they buy or use products or services. Customer service includes actions such as offering product suggestions, troubleshooting issues and complaints, or responding to general questions.</span>
                  </div>
               </div>
            </div>
         </div>
            <div class="copyright">
               <p>Copyright 2022 All Right Reserved By <a href="http://evaonline.online/">evaonline</a></p>
            </div>
         
      </div>
      </footr>
      <!-- end footer -->
      <!-- Javascript files--> 
      <script src="js/jquery.min.js"></script> 
      <script src="js/popper.min.js"></script> 
      <script src="js/bootstrap.bundle.min.js"></script> 
      <script src="js/jquery-3.0.0.min.js"></script> 
      <script src="js/plugin.js"></script> 
      <!-- sidebar --> 
      <script src="js/jquery.mCustomScrollbar.concat.min.js"></script> 
      <script src="js/custom.js"></script>
      <script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
      <script>
         $(document).ready(function(){
         $(".fancybox").fancybox({
         openEffect: "none",
         closeEffect: "none"
         });
         
         $(".zoom").hover(function(){
         
         $(this).addClass('transition');
         }, function(){
         
         $(this).removeClass('transition');
         });
         });
         
      </script> 
      
      <script>
function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}
</script>
   </body>
</html>