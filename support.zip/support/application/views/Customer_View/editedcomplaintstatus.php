<!DOCTYPE html>
<html lang="en">
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>Orion Technologies | Best inverter with battery and solar panels in Calicut, Kerala</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- bootstrap css -->
      <link rel="stylesheet" href="<?=base_url()?>css/bootstrap.min.css">
      <!-- style css -->
      <link rel="stylesheet" href="<?=base_url()?>css/style.css">
      <!-- Responsive-->
      <link rel="stylesheet" href="<?=base_url()?>css/responsive.css">
      <!-- fevicon -->
      <link rel="icon" href="<?=base_url()?>images/fevicon.png" type="image/gif" />
      <!-- Scrollbar Custom CSS -->
      <link rel="stylesheet" href="<?=base_url()?>css/jquery.mCustomScrollbar.min.css">
      <!-- Tweaks for older IEs-->
      <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
   
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
      <style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}
.button1 {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 5px 20px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  transition-duration: 0.4s;
  cursor: pointer;
}

.button2 {
  background-color: white; 
  color: black; 
  border: 2px solid #007FFF;
}

.button2:hover {
  background-color: #007FFF;
  color: white;
}
.topnav {
  overflow: hidden;
  background-color: white;
  color:black;
}

.topnav a {
  float: left;
  display: block;
  color: black;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: yellow;
  color: black;
}

.topnav a.active {
  background-color: yellow;
  color: black;
}

.topnav .icon {
  display: none;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child) {display: none;}
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
}




.ourproject{
	padding: 100px 0;
}

.project-single{
	position: relative;
	margin-bottom: 30px;	
}

.project-overlay{
	position: absolute;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	background: rgba(0,0,0,0.33);
	padding: 30px;
}

.project-overlay h3{
	color: #fff;
	font-size: 18px;
	font-weight: 500;
	font-family: 'Montserrat', sans-serif;
}

.project-overlay p{
	color: #fff;
	font-size: 14px;
	font-weight: 300;
	margin-bottom: 8px;
}

.completed-project{
	position: relative;
	background: url(../images/solara.jpg) no-repeat center center;
	background-size: cover;
	padding: 100px 0 80px;
}

.completed-project:before{
	content: '';
	display: block;
	position: absolute;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	background: rgba(15,36,64,0.84);
}

.completed-title{
	margin-bottom: 60px;
	text-align: center;
}

.completed-title h2{
	font-size: 34px;
	color: #fff;
	text-transform: uppercase;
}

.completed-single{
	text-align: center;
}

.completed-single h3{
	color: #fff;
	font-size: 50px;
	font-family: 'Montserrat', sans-serif;
	margin-bottom: 0;
}

.completed-single p{
	color: #fff;
	font-size: 20px;
}

/*  Request Contact Form area css  */

.request-callback{
	padding: 100px 0;
}

.request-form .form-group{
	margin-bottom: 30px;
}

.request-form .form-control{
	border: none;
	box-shadow: none;
	background: #e7e4e4;
	border-radius: 0;
	height: auto;
	padding: 12px 20px;
}

.btn-request{
	display: block;
	background: #0f2440;	
	color: #fff;
	border: none;
	width: 100%;
	text-transform: uppercase;
	font-weight: 300;
	padding: 12px;
	font-size: 14px;
	letter-spacing: 0.1em;
	transition: all 0.3s;
}

.btn-request:hover{
	background: #000;
}

.contact-information{
	background: #223a5a;
	padding: 30px 0;
}

.contact-single{
	text-align: center;
}

.contact-single p{
	color: #fff;
	font-size: 20px;
	font-weight: 300;
	margin-bottom: 0;
}

.contact-single i{
	margin-right: 10px;
}

td{
   width:150px;
   text-align:left;
}



</style>
   </head>
   <!-- body -->
   <body class="main-layout">
      <!-- loader  -->
      
      <!-- end loader --> 
      
     


      <div class="whyschose">
         <div class="container">

            <div class="row">
               <div class="col-md-7 offset-md-3">
                  <div class="title">
                      <?php if($flag==1){ ?>
                      <h5><b>Complaint Status :</b><?php if(($tick->status)==0){ ?><a disabled style="color:red"> Under Consideration </a><?php } ?><?php if(($tick->status)==1){ ?><a disabled style="color:#a63d05"> In-Progress </a><?php } ?><?php if(($tick->status)==2){ ?><a disabled style="color:#bf762c"> Temporarly Closed </a><?php } ?><?php if(($tick->status)==3){ ?><a disabled style="color:green"> Closed </a><?php } ?>  </h5>
                    <p><b style="font-weight:bold">Registered Contact Number: </b> <?php echo $tick->phone ?> </p>
                    <center><table>
                        <tbody>
                            <tr>
                            <td><b>Complaint Id </b></td>
                            <td><b>:</b><?php echo $tick->id ?></td>
                        </tr>  
                       <?php if($tick->staff!='-'){ ?> <tr>
                            <td><b>Assigned Staff  </b></td>
                            <td><b>:</b><?php echo $tick->staff ?></td>
                        </tr>  <?php } ?>
                        
                        <?php if($tick->staff!='-'){ ?> <tr>
                           <td><b>Contact number</b></td>
                            <td><b>:</b><?php echo $tick->staff ?></td>
                        </tr>  <?php } ?
                        
                        <tr>
                            <td><b>Product </b></td>
                            <td><b>:</b><?php echo $tick->item ?></td>
                        </tr>  
                        <tr>
                            <td><b>Brand  </b></td>
                            <td><b>:</b><?php echo $tick->brand ?></td>
                        </tr>  
                        <tr>
                            <td><b>Complaint </b></td>
                            <td><b>:</b><?php echo $tick->rqr ?></td>
                        </tr>
                        <tr><td > <?php if(($tick->status==3)||($tick->status==2)){ ?> <p><a href="<?php echo base_url('Staff/viewcustomerbill/'.$tick->id)?>" type="link" class="button1 buttton2" >View Bill</a></p> <?php }else{ ?><?php if($tick->staffid!=0){ ?> <a class="button1 buttton2" href="<?php echo base_url('Ticketresponse/chat/'.$tick->id)?>" >Chat</a><?php } } ?></td>
                        
                        <td><p><a href="https://oriontechnologies.co.in/" type="link" class="button1 buttton2" >Back to Home</a></p></td></tr>
                        
                        </tbody>
                      
                    </table></center>
                  </div>
                  <?php }if($flag==2){ ?>
                  <?php $count=$tick->num_rows(); if($count!=0){ ?> 
         
       <div style="width:100%; height:70%; ">
       <table class="table" style="width:100%; height:70%;border:1px solid grey" >
           <thead>
               <tr>
                   <th>Id</th>
                   
                   <th>Item</th>
                   <th>Model</th>
                   <th>Brand</th>
                   <th>Complaint</th>
                   <th>Remark</th>
                   <th>Date/Time</th>
                   
                   <th>Status</th>
                    <th>Action</th>
               </tr>
           </thead>
                      <tbody>
                      <?php  
                      foreach ($tick->result() as $row)  
                      {   
                        $d1=new DateTime();
                        $d2 = date_create($row->date);
                        $row->diff=date_diff($d2,$d1);
                        $row->d=(int)$row->diff->format("%R%a");
                        ?><tr>  
                        <td><?php echo $row->id;?></td>
                        
                        <td><?php echo $row->item;?></td>
                        <td><?php echo $row->model;?></td>
                        <td><?php echo $row->brand;?></td>
                        <td><?php echo $row->rqr;?></td>
                        <td><?php echo $row->remark;?></td>
                         <td><?php echo $row->date?> <?php echo $row->time?></td>   
                      
                      <td> <?php if(($row->status)==0){ ?><p style="color:red"> Under Consideration </p><?php } ?><?php if(($row->status)==1){ ?><p style="color:#a63d05"> In-Progress </p><?php } ?><?php if(($row->status)==2){ ?><p style="color:#bf762c"> Temporarly Closed </p><?php } ?><?php if(($row->status)==3){ ?><p style="color:green"> Closed </p><?php } ?></td>
                       <td><form method="post" autocomplete="off"  action="<?=base_url('Ticketresponse/complaintstatus')?>">
            
       <input type="text" name="tickid" value="<?php echo $row->id;?>" hidden  >
        <input type="text" name="phone" value="<?php echo $row->phone;?>" hidden  >
       <button  class="button1 button2" type="submit" >View</button> 
       
          </form></td>
                        </tr> 
                          </tr>  
                      <?php }  
                      ?>  
                    </tbody>
                  </table>
              </div>
              <?php }else{ ?><h5>No Tickets Registered</h5> <?php } }
              if($flag==5){?>
              <h5 style="color:red">Invalid Complaint Id/ Phone Number, Please Try Again</h5>
              <?php } ?>
               </div>
            </div>
         </div>
      </div>
     
     
      
      
      
      
      
      
      

  
      
      



      
      <!-- Javascript files--> 
      <script src="js/jquery.min.js"></script> 
      <script src="js/popper.min.js"></script> 
      <script src="js/bootstrap.bundle.min.js"></script> 
      <script src="js/jquery-3.0.0.min.js"></script> 
      <script src="js/plugin.js"></script> 
      <!-- sidebar --> 
      <script src="js/jquery.mCustomScrollbar.concat.min.js"></script> 
      <script src="js/custom.js"></script>
      <script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
      <script>
         $(document).ready(function(){
         $(".fancybox").fancybox({
         openEffect: "none",
         closeEffect: "none"
         });
         
         $(".zoom").hover(function(){
         
         $(this).addClass('transition');
         }, function(){
         
         $(this).removeClass('transition');
         });
         });
         
      </script> 
      
      <script>
function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}
</script>
   </body>
</html>