<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
	<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"	rel="stylesheet" type="text/css" />
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">

<link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">

<link rel="stylesheet" href="../../plugins/icheck-bootstrap/icheck-bootstrap.min.css">

<link rel="stylesheet" href="../../dist/css/adminlte.min.css">
    <title>Complaint Registration</title>
    <style>
   
      body{
        min-width:350px;
       
            background-image: 
            linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)),
            url('<?=base_url('images/registration.jpg')?>');
       background-size:cover;
-moz-background-size:cover;
-webkit-background-size:cover;
        background-repeat:no-repeat;
        align-content: center;
        }
	.passwordbox{
		background-color: rgba(255,255,255,0.5);
		border-radius:20px;
		border-color:transparent;
	}
	.passwordbox:focus {
		color:#212529;border-color:#86b7fe;outline:0;box-shadow:0 0 0 .25rem rgba(13,110,253,.25)}
}
.center {
  margin: auto;
  width: 60%;
  border: 3px solid #73AD21;
  padding: 10px;
}

      
      </style>
  </head>
  <body >
   <section class="Form my-4 mx-5 center" >
       <div class="container" style=" background-color: rgba(255,255,255,0.5);width:40%;height:50%;border-radius:20px;min-width:270px; ">
           <div class="row">
               <div class="card-header text-center"style="background-color:transparent;border-color:transparent">
						<h3>Register Complaint</h3>
						<br>
					
					  </div>
           <?php
						if($this->session->flashdata('ticketsuccess')) {	?>
						 <p class=" text-center" style="color:white;margin-top: 10px;"> <?=$this->session->flashdata('ticketsuccess')?></p>
						 
						<?php  if($flag==1){ ?>
						 <table>
						     <tbody>
						         <tr>
						             <td style="color:white"><b>Complaint Id </b></td><td style="color:white"><b>: </b><?php echo $tick->id; ?></td>
						         </tr>
						         <tr>
						             <td style="color:white"><b>Registered Contact Number </b></td><td style="color:white"><b>: </b><?php echo $tick->phone; ?></td>
						         </tr>
						     </tbody>
						 </table>
						 
						<?php } } ?>
						<p><button style="border-radius:10px"><a href="https://oriontechnologies.co.in/"><i class="fa fa-arrow-left"></i>Go Back to Homepage </a></button></p>
              <?php
						if($this->session->flashdata('usererror2')) {	?>
						 <p class="text-success text-center" style="color:white;margin-top: 10px;"> <?=$this->session->flashdata('usererror2')?></p>
						<?php } ?>
						<?php if($flag==0){ ?>
              <form method="POST"  autocomplete="off" action="<?=base_url('Customer/complaint')?>">
					
					   
						  
					   	<div class="mb-3">
						  <label for="exampleInputEmail1" class="form-label">Name*</label>
						    <input type="text" placeholder="Your Name" style="border-radius:5px;border-color:black;width:100%;height:37px" name="name" class="form-control" id="name" aria-describedby="name" required> 
						  </div>
						  	<div class="mb-3">
						  <label for="exampleInputEmail1" class="form-label">Email*</label>
						    <input type="text" placeholder="Your Email" style="border-radius:5px;border-color:black;width:100%;height:37px" name="email" class="form-control" id="name" aria-describedby="name" > 
						  </div>
						  	<div class="mb-3">
						  <label for="exampleInputEmail1" class="form-label">Contact Number*</label>
						    <input type="text" placeholder="Your Contact Number" style="border-radius:5px;border-color:black;width:100%;height:37px" name="phone" class="form-control" id="name" aria-describedby="name" required> 
						  </div>
						<div class="mb-3">
						  
						    <label for="exampleInputEmail1" class="form-label">Details of Complaint*</label>
						   <textarea  placeholder="Kindly Explain in detail(100 words)" style="border-radius:5px;border-color:black;width:100%" rows="5" cols="30" name="comdetail" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required></textarea>
						  </div>	
						 <div class="text-center">
						  <button type="submit" class="btn btn-primary">Submit</button>
						  
						</div>

						</form>
         <?php } ?>
</div></div> <br><br> <div class="input-group mb-3">
			
           
        </div>  </section>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->
  </body>
</html>