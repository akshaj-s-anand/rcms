<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Customer Page</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">

  <link rel="stylesheet" href="../dist/css/adminlte.min.css">
<style>
#droplets{
    margin-left:10px;
}
ul, #myUL {
  list-style-type: none;
}

#myUL {
  margin: 0;
  padding: 0;
}

.caret {
  cursor: pointer;
  -webkit-user-select: none; /* Safari 3.1+ */
  -moz-user-select: none; /* Firefox 2+ */
  -ms-user-select: none; /* IE 10+ */
  user-select: none;
}

.caret::before {
  content: "\00BB";
  color: black;
  display: inline-block;
  font-size:30px;
  margin-right: 10px;
  margin-left: 10px;
}

.caret-down::before {
  -ms-transform: rotate(90deg); /* IE 9 */
  -webkit-transform: rotate(90deg); /* Safari */'
  transform: rotate(90deg);  
}

.nested {
  display: none;
}

.active {
  display: block;
}
.button1 {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 5px 20px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  transition-duration: 0.4s;
  cursor: pointer;
}

.button2 {
  background-color: white; 
  color: black; 
  border: 2px solid #007FFF;
}

.button2:hover {
  background-color: #007FFF;
  color: white;
}
</style>
</head>
<body class="hold-transition sidebar-mini" style="width:auto;min-width:174px">
<div class="wrapper">

  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-green navbar-light"style="width:auto;min-width:174px">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
     
    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      <!-- Navbar Search -->
      <li class="nav-item">
        <a class="nav-link" data-widget="navbar-search" href="#" role="button">
          <i class="fas fa-search"></i>
        </a>
        <div class="navbar-search-block">
          <form class="form-inline">
            <div class="input-group input-group-sm">
              <input class="form-control form-control-navbar" type="search" placeholder="Search" aria-label="Search">
              <div class="input-group-append">
                <button class="btn btn-navbar" type="submit">
                  <i class="fas fa-search"></i>
                </button>
                <button class="btn btn-navbar" type="button" data-widget="navbar-search">
                  <i class="fas fa-times"></i>
                </button>
              </div>
            </div>
          </form>
        </div>
      </li>

    </ul>
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
   

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
      <i class="fa fa-user " style="color:white;padding:4.7%"></i>
        <div class="info">
          <a href="#" class="d-block" style="font-size:20px"> <?php 
if($this->session->userdata('UserLoginSession'))
{
    $udata = $this->session->userdata('UserLoginSession');
    echo $udata['username'] ;
}
else
{
    redirect(base_url('Login_Registration/login'));
}



 ?></a>
   <a  href="<?=base_url('Staff/logout')?>"><b class="try" style="font-size:15px;color:#ff4d4d">LogOut</b></a>
  
        </div>
      </div>

     

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
               <li class="nav-item ">
       <a href="<?=base_url('Customer/homepage')?>" class="nav-link ">
         <i class="fas fa-home"></i>
         <p>
          Home
          
         </p>
       </a>
        <li class="nav-item ">
        <a href="<?=base_url('Customer/editprofile')?>" class="nav-link ">
         <i class="fas fa-user"></i>
         <p>
          Edit Profile
          
         </p>
       </a>
       
             <li class="nav-item ">
       <a href="<?=base_url('Customer/bookticket')?>" class="nav-link ">
         <i class="fas fa-folder"></i>
         <p>
          Raise a Complaint
          
         </p>
       </a>
         <li class="nav-item ">
       <a class="nav-link " id="drop"  ><i class="fas fa-image"></i>My Booked Tickets<i id="demo2" class="fa fa-angle-double-right"></i></a></li>
       <div id="droplets" style="display:none">
         <li class="nav-item ">
            
       <a  class="nav-link " data-toggle="modal" data-target="#myModal">
         <i class="fas fa-folder"></i>
         <p>
          Search By Ticket Id
          
         </p>
       </a></li>
        <li class="nav-item ">
       <a active href="<?=base_url('Customer/viewmytickets')?>" class="nav-link ">
         <i class="fas fa-book"></i>
         <p>
          View All Tickets
          
         </p>
       </a>  </li>

    
       </div>
        
        <li class="nav-item ">
       <a href="<?=base_url('Customer/faq')?>" class="nav-link ">
         <i class="fa fa-question-circle" aria-hidden="true"></i>
         <p>
          FAQs
          
         </p>
       </a>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">FAQs</h1>
          </div><!-- /.col -->
         
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      
     <div class="container-fluid">
    <div class="row">
        <div class="column">
            <div class="accordion" id="faqExample">
               <?php 
                      foreach ($m->result() as $row)  
                      {   
                        ?>
                 <div class="card" style="border-radius:5px;min-height:50px">
               <ul id="myUL">
  <li style="margin-top:15px"><span class="caret" > 
                                 <b><?php echo $row->question;?></b></span>
                               
    <ul class="nested">
         <hr>
      <li><?php echo $row->answer;?></li>
      
    </ul>
  </li>
</ul>
</div>
               <?php } ?>
            </div>

        </div>
    </div>
    <!--/row-->
     
</div>
<!--container-->
 <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
         
          <h4 class="modal-title">Enter The TicketId</h4>
        </div>
        <div class="modal-body">
           <form method="post" autocomplete="off" onsubmit="submitForm(event)" action="<?=base_url('Ticketresponse/cuscomplaint')?>">
         <input value="<?php echo $h->num_rows() ?>" id="count" hidden  >            
       <input type="text" placeholder="Enter The TicketId" name="tickid" class="form-control" id="tickidnum" aria-describedby="emailHelp" style="background-color: rgba(255,255,255,0.5);border-radius: 5px 0px 0px 5px;border-color:transparent;height:35px" ><button class="button1" type="submit" >Submit</button> 
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
   <script type="text/JavaScript">
  function submitForm(event){
       var x=document.getElementById("count").value;
         var y=document.getElementById("tickidnum").value;
       if(x==0){
         alert("No Tickets Found By Id: "+y); 
           event.preventDefault();
       }
    
      
   
  }
</script>
 
  <!-- /.content-wrapper -->
  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
    <div class="p-3">
      <h5>Title</h5>
      <p>Sidebar content</p>
    </div>
  </aside>
  <!-- /.control-sidebar -->

  <!-- Main Footer -->
  
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->

<!-- jQuery -->
<script src="../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="../dist/js/adminlte.min.js"></script>
<script>
var toggler = document.getElementsByClassName("caret");
var i;

for (i = 0; i < toggler.length; i++) {
  toggler[i].addEventListener("click", function() {
    this.parentElement.querySelector(".nested").classList.toggle("active");
    this.classList.toggle("caret-down");
  });
}
</script>
<script>
$(document).ready(function(){
  $("#drop").click(function(){
      var x = document.getElementById("demo2");
     if (x.className.indexOf("fa fa-angle-double-down") == -1) {
       x.className = " fa fa-angle-double-down";   
     }else{
         x.className = " fa fa-angle-double-right";   
     }
    $("#droplets").toggle();
  });
});
</script>
</body>
</html>
