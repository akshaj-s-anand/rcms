<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Get Your Complaint Status</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f2f5;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
        }

        .container {
            max-width: 600px;
            background-color: #ffffff;
            padding: 20px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .form-container {
            text-align: center;
        }

        .form-container h3 {
            margin: 0 0 20px;
            font-size: 24px;
        }

        .form-container input[type="text"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #dddfe2;
            border-radius: 4px;
            margin-bottom: 10px;
            font-size: 14px;
        }

        .form-container button {
            background-color: #1877f2;
            color: #ffffff;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
        }

        .form-container button:hover {
            background-color: #1153b5;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="form-container">
            <h3>Get Your Complaint Status</h3>
            <form method="post" autocomplete="off" action="<?=base_url('Ticketresponse/complaintstatus')?>">
                <input type="text" placeholder="Enter The Complaint ID" name="tickid" required>
                <input type="text" placeholder="Your Registered Mobile Number" name="phone" required>
                <button type="submit">Submit</button>
            </form>
        </div>
    </div>
</body>
</html>
