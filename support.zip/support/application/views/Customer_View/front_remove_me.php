<!DOCTYPE html>
<html lang="en">
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>Marko Series | Best inverter with battery and solar panels in Calicut, Kerala</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- bootstrap css -->
      <link rel="stylesheet" href="<?=base_url()?>css/bootstrap.min.css">
      <!-- style css -->
      <link rel="stylesheet" href="<?=base_url()?>css/style.css">
      <!-- Responsive-->
      <link rel="stylesheet" href="<?=base_url()?>css/responsive.css">
      <!-- fevicon -->
      <link rel="icon" href="<?=base_url()?>images/fevicon.png" type="image/gif" />
      <!-- Scrollbar Custom CSS -->
      <link rel="stylesheet" href="<?=base_url()?>css/jquery.mCustomScrollbar.min.css">
      <!-- Tweaks for older IEs-->
      <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
      <style>#aboutimgcol{
   margin-left:20px;
   margin-bottom:20px;
   max-width:530px; 
}
#aboutimg{
    height:750px;
}




.centered {
  position: absolute;
 
  left: 50%;
  transform: translate(-50%, -110%);
}
.button28 {
  background-color: #f4511e;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;

  cursor: pointer;
  width:100%;
  -webkit-transition-duration: 0.4s; /* Safari */
transition: all 0.5s ease;
}



.row2 {margin: 0 -5px;}

/* Clear floats after the columns */
.row2:after {
  content: "";
  display: table;
  clear: both;
  margin-left:20px;
}
 #servpara{
    
 line-height: 1.7;
 color:white;
 margin:10px;
 font-size:18px;
 font-family: "Times New Roman", Times, serif;
}


.ourproject{
	padding: 100px 0;
}

.project-single{
	position: relative;
	margin-bottom: 30px;	
}

.project-overlay{
	position: absolute;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	background: rgba(0,0,0,0.33);
	padding: 30px;
}

.project-overlay h3{
	color: #fff;
	font-size: 18px;
	font-weight: 500;
	font-family: 'Montserrat', sans-serif;
}

.project-overlay p{
	color: #fff;
	font-size: 14px;
	font-weight: 300;
	margin-bottom: 8px;
}



.completed-project{
	position: relative;
	background: url(../images/cheat.jpg) no-repeat center center;
	background-size: cover;
	padding: 100px 0 100px;
}

.completed-project:before{
	content: '';
	display: block;
	position: absolute;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	opacity:1;
}

.completed-title{
	margin-bottom: 60px;
	text-align: center;
}

.completed-title h2{
	font-size: 34px;
	color: #fff;
	text-transform: uppercase;
}

.completed-single{
	text-align: center;
}

.completed-single h3{
	color: #fff;
	font-size: 50px;
	font-family: 'Montserrat', sans-serif;
	margin-bottom: 0;
}

.completed-single p{
	color: #fff;
	font-size: 20px;
}





.container454{
  width:50%;
  min-width:300px;
  min-height:350px;
  margin:0 auto;
  position:relative;
  padding-bottom:30px;
  overflow:hidden;
    background-color:#ec1c25;
  background-size:cover;
}


input[type="radio"] {
position: absolute;
width: 1px; /* Setting this to 0 make it invisible for VoiceOver */
height: 1px; /* Setting this to 0 make it invisible for VoiceOver */
padding: 0;
margin: -1px;
border: 0;
clip: rect(0 0 0 0);
overflow: hidden;
}
label{
  display:block;
  width:32%;
  border: 4px solid white;
  position:absolute;
  bottom:5px;
  cursor: pointer;
  transition: border-color 0.3s linear;
}

label.second{
  left:34%;
}
label.third{
  left:68%;
}

blockquote{
  margin:0;
  padding:30px;
  width:100%;
  min-height:250px;
  background-color: #ec1c25;
  color:white;
  box-shadow: 0 5px 2px rgba(0,0,0,0.1);
  position:relative;
  transition: background-color 0.6s linear;
}

blockquote:after { 
  content: " "; 
  height: 0; 
  width: 0; 
  position: absolute; 
  top: 100%; 
  border: solid transparent; 
  border-top-color: rgba(255,255,255,0.5);
  border-left-color:rgba(255,255,255,0.5);
  border-width: 10px; 
  left: 10%; 
} 
#second:checked ~ .two blockquote {
  background-color:#ec1c25;
}
.two blockquote:after{
  border: solid transparent; 
  border-top-color: rgba(255,255,255,0.5);
  border-left-color:rgba(255,255,255,0.5);
  border-width: 10px;
}
#third:checked ~ .three blockquote{
 background-color:#ec1c25;
}
.three blockquote:after{
  border: solid transparent; 
  border-top-color: rgba(255,255,255,0.5);
  border-left-color: rgba(255,255,255,0.5);
  border-width: 10px;
}
.quotes{
  position:absolute;
  color:rgba(255,255,255,0.5);
  font-size:5em;
}
.leftq{
  top:-25px;
  left:5px;
}
.rightq{
  bottom:-10px;
  right:5px;
}

.slide1{
  position:absolute;
  left:-100%;
  opacity:0;
  transition: all 0.6s ease-in;
}

#first:checked ~ label.first {
  border-width:6px;
  border-color:white;
}
#second:checked ~ label.second {
  border-width:6px;   border-color:white;
}
#third:checked ~ label.third {
  border:6px solid rgba(255,255,255,0.5);
    border-color:white;
}

#first:checked ~ div.one {
  left:0;
  opacity:1;
}
#second:checked ~ div.two {
  left:0;
  opacity:1;
}
#third:checked ~ div.three {
  left:0;
  opacity:1;
}
#slidebtnright:hover{
   background-color:white; 
}
#slidebtnleft:hover{
   background-color:white; 
}
#slidebtnright:hover{
   background-color:#ec1c25; 
}
#slidebtnleft:hover{
   background-color:#ec1c25; 
}









</style>
   </head>
   <!-- body -->
   <body class="main-layout">
      <!-- loader  -->
     
      <!-- end loader --> 
      <!-- header -->
      <header>
         <!-- header inner -->
         <div class="header">
         <div class="container">
            <div class="row">
               <div class="col-xl-2 col-lg-2 col-md-2 col-sm-2 col logo_section">
                  <div class="full">
                     <div class="center-desk">
                        <div class="logo" > <a href=""><img src="images/logo-2.png" alt="logo"/></a> </div>
                     </div>
                  </div>
               </div>
               <div class="col-xl-10 col-lg-10 col-md-9 col-sm-9" >
                  <div class="menu-area">
                     <div class="limit-box">
                        <nav class="main-menu">
                           <ul class="menu-area-main">
                              <li><a href="<?=base_url('Customer/complaint')?>">Register Complaints</a></li>
                              <li><a href="">Login</a>
                                <ul>
                                    <li><a href="<?=base_url('Login_Registration/login')?>">Customer Login</a></li>
                                    <li><a href="<?=base_url('Login_Registration/login')?>">Service Engineer Login</a></li>
                                    <li><a href="">&nbsp;</a></li>
                                </ul>
                            </li>
                             <li><a href="<?=base_url('Customer/complaintpage')?>">Complaints Status</a></li>
         <!--                     <li> <a href="<?=base_url('Login_Registration/about')?>">About</a> </li>-->
         <!--                     <li> <a href="<?=base_url('Welcome/services')?>">Services</a> </li>-->
         <!--                     <li> <a href="#myModal2"> Products<i class="fa fa-caret-down" aria-hidden="true"></i></a> -->
							  <!--      <ul>-->
							  <!--          <li><a href="">Battery</a></li>-->
							  <!--          <li><a href="">Solar Products</a></li>-->
							  <!--          <li><a href="">UPS/Inverter</a></li>-->
							  <!--          <li><a href="">Solar Water Heater</a></li>-->
							  <!--          <li>&nbsp;</li>-->
							  <!--      </ul>-->
							  <!--</li>-->
         <!--                     <li> <a href="#myModal3">Brands</a></li>-->
         <!--                     <li> <a href="<?=base_url('Login_Registration/contact')?>">Contact</a></li>-->
         <!--                     <li> <a href="#">Complaints & Login<i class="fa fa-caret-down" aria-hidden="true"></i></a>-->
         <!--                           <ul>-->
         <!--                               <li><a href="<?=base_url('Customer/complaint')?>">Register Complaints</a></li>-->
         <!--                               <li><a href="">Login</a>-->
         <!--                                   <ul style="left: 0px;">-->
         <!--                                       <li><a href="<?=base_url('Login_Registration/login')?>">Customer Login</a></li>-->
         <!--                                       <li><a href="<?=base_url('Login_Registration/login')?>">Service Engineer Login</a></li>-->
         <!--                                       <li><a href="">&nbsp;</a></li>-->
         <!--                                   </ul>-->
         <!--                               </li>-->
                                        <!--<li><a href="#" class="dropdown-item" data-toggle="modal" data-target="#myModal">Complaints Status</a></li>-->
         <!--                               <li><a href="<?=base_url('Customer/complaintpage')?>">Complaints Status</a></li>-->
                                         <!--<li class="mean-last"> <a href="<?=base_url('Login_Registration/login')?>">Login</a> </li>-->
         <!--                               <li>&nbsp;</li>-->
         <!--                           </ul>-->
         <!--                     </li>-->
                             
                               
                           </ul>
                        </nav>
                     </div>
                  </div>
               </div>
               
            </div>
         </div>
         <!-- end header inner --> 
         <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
            <h6>Get Your Complaint Status</h6>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          
        </div>
        <div class="modal-body">
        <form method="post" autocomplete="off" onsubmit="submitForm(event)" action="<?=base_url('Ticketresponse/complaintstatus')?>">
         <input value="" id="count" hidden >       
       <input type="text" placeholder="Enter The Complaint Id" name="tickid" class="form-control" id="tickidnum" aria-describedby="emailHelp" style="background-color: rgba(255,255,255,0.5);border-radius: 5px 0px 0px 5px;border-color:transparent;height:35px" >
        <input type="text" placeholder="Your Registered Mobile Number" name="phone" class="form-control"aria-describedby="emailHelp" style="background-color: rgba(255,255,255,0.5);border-radius: 5px 0px 0px 5px;border-color:transparent;height:35px" >
       <button  class="button1" type="submit" >Submit</button> 
       
          </form>
        </div>
        <div class="modal-footer">
             <a style="color:blue" data-toggle="modal" data-target="#myModal1">Forgot Complaint Id?</a>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      <div class="modal fade" id="myModal1" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
            <h6>Get Your Complaint Status</h6>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          
        </div>
        <div class="modal-body">
         <form method="post" autocomplete="off" onsubmit="submitForm(event)" action="<?=base_url('Ticketresponse/viewall')?>">
         <input value="" id="count" hidden >       
       <input type="text" placeholder="Your Registered Mobile Number" name="phone" class="form-control"aria-describedby="emailHelp" style="background-color: rgba(255,255,255,0.5);border-radius: 5px 0px 0px 5px;border-color:transparent;height:35px" >
       <button  class="button1" type="submit" >Submit</button> 
       
          </form>
        </div>
        <div class="modal-footer">
            
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
    
  </div>
      
    </div>
    
  </div>
      </header>
      <!-- end header -->
      <section class="slider_section">
         <div id="main_slider" class="carousel slide banner-main" data-ride="carousel">

            <div class="carousel-inner">
               <div class="carousel-item active">
                  <img class="first-slide" src="<?php foreach($image1->result() as $row){ echo base_url()."/images/".$row->image; } ?>" alt="First slide">
                  
                
               </div>
               <div class="carousel-item">
                  <img class="second-slide" src="<?php foreach($image1->result() as $row){ echo base_url()."/images/".$row->image2; } ?>" alt="Second slide">
               </div>
               <div class="carousel-item">
                  <img class="third-slide" src="<?php foreach($image1->result() as $row){ echo base_url()."/images/".$row->image3; } ?>" alt="Third slide">
               </div>

            </div>
            <a class="carousel-control-prev" href="#main_slider" role="button" data-slide="prev">
            <i class='fa fa-angle-right'></i>
            </a>
            <a class="carousel-control-next" href="#main_slider" role="button" data-slide="next">
            <i class='fa fa-angle-left'></i>
            </a>
            
         </div>

      </section>

 <!-- Lastestnews -->
    <div class="Lastestnews blog">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="titlepage">
                    <h3> <strong class="black"><b>ORION TECHNOLOGIES SERVICES</b></strong></h3>
                     <span style="font-size:16px">We provide the perfect service for you.</span>   
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 margin">
                    <div class="news-box">
                        <figure><img  src="<?php foreach($image2->result() as $row){ echo base_url()."/images/".$row->image; } ?>" alt="img" /></figure>
                        <h3><?php foreach($b->result() as $row) {?> <?php echo $row->title; ?> <?php  } ?></h3>
                        <p align="justify"><?php foreach($b->result() as $row) {?> <?php echo $row->stitle; ?> <?php  } ?></p>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 margin">
                    <div class="news-box">
                        <figure><img src="<?php foreach($image2->result() as $row){ echo base_url()."/images/".$row->image2; } ?>" alt="img" /></figure>
                        <h3><?php foreach($b->result() as $row) {?> <?php echo $row->title2; ?> <?php  } ?></h3>
                        <p align="justify"><?php foreach($b->result() as $row) {?> <?php echo $row->stitle2; ?> <?php  } ?></p>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 margin">
                    <div class="news-box">
                        <figure><img src="<?php foreach($image2->result() as $row){ echo base_url()."/images/".$row->image3; } ?>" alt="img" /></figure>
                        <h3><?php foreach($b->result() as $row) {?> <?php echo $row->title3; ?> <?php  } ?></h3>
                        <p align="justify"><?php foreach($b->result() as $row) {?> <?php echo $row->stitle3; ?> <?php  } ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- end Lastestnews -->

      <div class="service">
         <div class="container">
            <section class="banner" id="home">
    		<div class="container">
    			<div class="row">
    				<div class="col-md-12">
    					<div class="about-company">
    						<div class="row no-gutters">
    						  	<div class="col-md-5" style="margin-left:0%;">
    							<!-- About Description start -->
    							    <div class="about-description">
    									<div class="row2">
                                          <div class="column2 serv1">
                                            <div class="card2">
                                                <img   src="../images/b1.png">
                                             <h3><b>Inverter Load Calculator</b></h3>
                                            <h6 style="color:#9ba39d;  line-height: 1.6;">How to choose a reliable Inverter and battery or inverter with battery for your home and office?, Calculate your load.</h6>
                                            </div>
                                          </div>
                                        
                                          <div class="column2 serv1" >
                                            <div class="card2">
                                            <img  src="../images/b2.png">
                                               <h3 style="margin-top:10px"  ><b>Dealer Locator</b></h3>
                                             <h6 style="color:#9ba39d;  line-height: 1.6;">Locate the nearest inverter, battery and solar product dealer in your city...! Your nearest car battery dealer, inverter battery dealer, exide battery dealers, find all here. Your one stop dealer hub</h6>
                                            </div>
                                          </div>
                                          
                                          <div class="column2 serv1" >
                                            <div class="card2">
                                            <img   src="../images/b3.png">
                                            <h3><b>Service Support</b></h3>
                                              <h6 style="color:#9ba39d;  line-height: 1.6;">If you have any Product related doubts/queries, just click on the link below and we will be happy to revert back to you. Our help centre is open for 24x7. Dedicated customer service team for live support rescue.</h6>
                                            </div>
                                          </div>
                                          
                                          <div class="column2 serv1">
                                            <div class="card2">
                                            <img  src="../images/b4.png">
                                                 <h3 style="margin-top:10px"  ><b>Enquire Now</b></h3>
                                                <h6 style="color:#9ba39d;  line-height: 1.6;">Dear Customer, welcome to Orion Technologies Customer Care Section!! We value our customer and will be happy to assist you. Enrol now for instant assistance.</h6>
                                            </div>
                                          </div>
                                        </div>
    								</div>
    								<!-- About Description end -->
    							</div>  
    						   
    						 
    							<div class="col-md-6" id="aboutimgcol" >
    								<!-- About image start -->
    								<div class="container12" style="  position: relative;color: white;">
    								    
    								<img id="aboutimg"  src="<?php foreach($image3->result() as $row){ echo base_url()."/images/".$row->image; } ?>"	>
    								 <div class="centered" style="position: absolute;top: 6%;left: 6%;transform: translate(-2%, -4%);background: rgba(0, 0, 0, 0.6)">
    						
                     
                        <div style="display:flex;flex-direction:row"><div style="height:16px;width:50px; border-bottom: 4px solid red;margin-right:15px"  ></div> <h6 style="color:white">ABOUT ORION TECHNOLOGIES</h6></div>
                        <h4 style="color:white"><b>Orion Technologies Is The Leading Power Backup Solution Company In Kerala.</b></h4> 
                        <p id="servpara"  >Orion technologies is a company established in the year 1999. We are the main dealers of Inverter, UPS and Batteries, 
                        power backup systems and solar system, different types of solar panels, solar on grid system and off grid system etc., across Calicut (Kozhikode), 
                        Wayanad, Malappuram, Palakkad. Orion is the authorised dealers of best class quality automobile batteries, best inverter battery, inverter with battery, best water heater, 
                        solar system, and ups dealers. Available automobile batteries for all vehicles. The best car battery dealers near you, we have dealers and service support all over Kerala.
                        For solar panel installation and services, choosing best types of solar panels for your home. Years of successful experience in installation of solar panels and in solar system projects.
                        Orion technologies head-quartered at Calicut, India. Presently we have a team of 30+ skilled professionals. We are specialized and mastered in installation, 
                        configuration and maintenance of all types of power backup systems (Inverter, UPS, Batteries, Solar Products…) available in the market today.</p>
                   <button class="button28 button24" onclick="location.href='<?=base_url('Login_Registration/about')?>'" >More About</button>
                   
    						
    								</div>
    								<!-- About image end -->
    							</div>
    							
    					
    							
    						
    						</div>
    					</div>
    				</div>
    			</div>
    		</div>
    		</div>
	    </section>
	    </div>
	  </div>
	  
	  <div class="product" style="background:#01005d">
            <div class="row" style="background:#01005d" >
               <div class="col-md-12" style="background:#01005d">
	        <section class="completed-project" >
		<div class="container" style="background: rgba(0, 0, 0, 0.6)">
		    
			<div class="row" >
			
				<div class="col-sm-6" style="margin-left:5%;">
					<div class="progress" style="background-color:white;margin-top:50px;width:100%;height:25px;border-radius:15px">
                        <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:70%;background-color:#ec1c25">
                            <div style="display:flex;flex-direction:row"><b style="margin-left:10px">Solar Products</b><b style="margin-left:68%">70%</b></div>
                            </div>
                        </div>
				 
	                <div class="progress" style="background-color:white;margin-top:50px;width:100%;height:25px;border-radius:15px">
                        <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:85%;background-color:#ec1c25">
                            <div style="display:flex;flex-direction:row"><b style="margin-left:10px">UPS/Inverters</b><b style="margin-left:75%">85%</b></div>
                            </div>
                        </div>
                    <div class="progress" style="background-color:white;margin-top:50px;width:100%;height:25px;border-radius:15px">
                        <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:80%;background-color:#ec1c25">
                            <div style="display:flex;flex-direction:row"><b style="margin-left:10px">Batteries</b><b style="margin-left:78%">80%</b></div>
                            </div>
                        </div>
				</div>
				
					<div class="col-sm-4">
					<div class="completed-title">
					    <div style="display:flex;flex-direction:row"><div style="height:16px;width:50px; border-bottom: 4px solid orange;margin-right:15px"  ></div> <h6 style="color:white">Experience</h6></div>

						<h1 style="font-weight:700;color:white">Installation & Project Development</h1>
						</div>
							<div class="completed-single">
							    
						<h5 class="counter" style="color:white" ><b style="font-size:45px" >+150 </b>Projects</h5>
					<h5 class="counter" style="color:white"><b style="font-size:45px">+5 </b> Cities</h5>
					</div>
					
					
				</div>
			</div>
		</div>
	</section>
	            </div>
	  </div></div>



         </div>
         
         
         
         <!-- testimonial section starts-->
         <div class="whyschose">
 <div class="container">

            <div class="row">
               <div class="col-md-7 offset-md-3">
                  <div class="title">
                     <h2> <strong class="black"  style="font-weight:900">Testimonials</strong></h2>
                     <span>Some kind words from clients about Orion Technologies.</span>
                  </div>
               </div>
            </div>
         </div>


	</div>
	
	
	
	
	
	
	 <div class="Lastestnews blog" >
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                   
                </div>
            </div>
            <div class="row">
                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 margin"  >
                    <div class="news-box" style="background-color: #ec1c25;">
                        <figure><span style='font-size:100px;color:white;margin-left:30%;'>&#8706;</span><span style='font-size:100px;color:white;'>&#8706;</span></figure>
                        <p style="color:white;">Orion is taking care of power backup solutions in our company. They are providing the best products at an effective cost. Thanks to the whole team.</p>
                         <h3 style="color:white;">Shanidh Ramsan</h3>
                        <p style="color:white;">ORTEL SOFTWARE TECHNOLOGIES</p>
                       
                    </div>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 margin">
                    <div class="news-box" style="background-color: #ec1c25;">
                        <figure><span style='font-size:100px;color:white;margin-left:30%;'>&#8706;</span><span style='font-size:100px;color:white;'>&#8706;</span></figure>
                        <p style="color:white;">It was an excellent service from this Orion Technologies , when I approached them for purchasing an UPS. They have quoted nominal amount for it. Their delivery and installation was good.</p>
                        <h3 style="color:white;">Aneesh v v</h3>
                        <p style="color:white;">ORTEL SOFTWARE TECHNOLOGIES</p>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 margin">
                    <div class="news-box" style="background-color: #ec1c25;">
                       <figure><span style='font-size:100px;color:white;margin-left:30%;'>&#8706;</span><span style='font-size:100px;color:white;'>&#8706;</span></figure>
                       <p style="color:white;">Best solution for the solar home grid, off grid, solar water heater, inverter battery's In Calicut. Good planning work & Good service provider.</p>
                         <h3 style="color:white;">Shimjith P M</h3>
                        <p style="color:white;">CUSTOMER</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
	
	
	
	
	
	
	
	
	
	
	
	
         <!-- testimonial section ends-->

      <!-- end our product -->
      <!-- map -->
      	<section id="newletter" >
		<div class="container" >
		    
			<div class="row">
				<div class="col">
				
						
					<div class="completed-title">
					    
						<h4 style="color:black;">Subscribe to our newsletter</h4>
						<hr style="background-color:black;height:2px;margin-top:-20px;width:300px">
						<p style="color:white;font-size:16px">Welcome to our Newsletter Subscription Center. Sign up in the newsletter form below to receive the latest news and updates from our company.</p>
						</div>
							<div class="completed-single">
							    
					<form class="form" action="/action_page.php">
					 <div class="flexss">  
					 <h6  class="hlabel"  for="fname" >First name:</h6>  
					               
					              
					                   <input class="form-control" type="text" id="fname" name="fname"   ></div>
					              
					              
					          <div class="flexss" >
					              
					                <h6 class="hlabel"   for="email" >Email:  <span title="Nb: We will send you an email describing how to activate your newsletter subscription"><i class="fa fa-info-circle"></i></span> </h6>  
					                 
					            
					               
					                  <input class="form-control" type="text" id="femail" name="email" >
					          </div>
					             
					            
					   
 
  <input class="btn btn-primary" id="subbtn" type="submit" value="Subscribe">
</form> 
					</div>
				</div>
			</div>
			</div>
		</section>
      <!-- end map --> 
      <!--  footer --> 

<hr>


           
    
            <div style="background-image:url(<?php foreach($image3->result() as $row){ echo base_url()."/images/".$row->image; } ?>);background-repeat:no-repeat;background-size:cover;width:100%;"  >
             
            <div class="row" style="background: rgba(255,255, 255, 0.96);width:100%;height:100%;margin-left:1px" >
                 <div class="col-sm" id="footer1"  >
                  <div class="contact" >
                     <h3 style="color:black">    <a href=""><img src="images/logo-2.png" alt="logo"/></a></h3>
                     <span style="color:#878787;font-size:14px;">Do you have any queries or comments about our website, our products or any of our services.?</span>
                       <ul class="sociel">
                         <li> <a style="color:black" href="#"><i class="fa fa-facebook"></i></a></li>
                         <li style="margin-left:-30px"> <a style="color:black" href="#"><i class="fa fa-twitter"></i></a></li>
                         <li style="margin-left:-30px"> <a style="color:black" href="#"><i class="fa fa-instagram"></i></a></li>
                             <li style="margin-left:-30px"> <a style="color:black" href="#"><i class="fa fa-pinterest"></i></a></li>
                              <li style="margin-left:-30px"> <a style="color:black" href="#"><i class="fa fa-linkedin"></i></a></li>
                     </ul>
                     
                  </div>
               </div>
              
                 <div class="col-sm" id="footer2" >
                  <div class="contact">
                     <h3 style="color:#ec1c25;font-weight:700">QUICK LINKS</h3>
                       <ul class="lik">
                         <li> <a style="color:#ec1c25" href="<?=base_url()?>"><i class="fa fa-home"></i>Home</a></li>
                         <li> <a style="color:#ec1c25" href="<?=base_url('Login_Registration/about')?>"><i class="fa fa-tags"></i>About</a></li>
                         <li> <a style="color:#ec1c25" href="<?=base_url('Welcome/services')?>"><i class="material-icons" style="font-size:18px"></i>Services</a></li>
                         <li> <a style="color:#ec1c25" href="<?=base_url('Welcome/selectpro')?>"><i class="fa fa-shopping-cart"></i>Products</a></li>
                       
                     </ul>
                  </div>
                   
               </div>
               <div class="col-sm" id="footer3" >
                  <div class="contact">
                      <h3 style="color:#ec1c25;font-weight:700">Contact Us</h3>
                      
                    <div class="row">
                         <div class="col"> <table>
                             <tbody>
                                 <tr>
                                     <td><i class="fa fa-address-book" style="color:red"></i></td>
                                     <td style="color:#878787">Building No. 44/3014, Kuniyilkave Road Ashokapuram, Calicut-673006 </td>
                                 </tr>
                                  <tr>
                                     <td><i class="fa fa-mobile-phone" style="color:red"></i></td>
                                     <td style="color:#878787">9447385870 </td>
                                 </tr>
                                  <tr>
                                     <td><i class="fa fa-phone" style="color:red"></i></td>
                                     <td style="color:#878787">0495-2771502</td>
                                 </tr>
                                  <tr>
                                     <td><i class="fa fa-envelope-open" style="color:red"></i></td>
                                     <td style="color:#878787">admin@oriontechnologies.co.in</td>
                                 </tr>
                                  <tr>
                                     <td><i class="fa fa-clock-o" style="color:red"></i></td>
                                     <td style="color:#878787">Open hours: Mon-Sat 9 AM to 7PM</td>
                                 </tr>
                                  <tr>
                                     <td ><i class="material-icons" style="color:red;font-size:18px">watch</i></td>
                                     <td style="color:#878787" >aHappy hours: sat: 2 pm to 4 pm</td>
                                 </tr>
                             </tbody>
                         </table></div>
                     </div>
                        
                   
                        
                  </div>
               </div>
               
                
            </div>
                        <div class="row" style="background: rgba(255,255, 255, 0.96);width:100%;height:100%;margin-left:1px" >
                 <div class="col-sm"  >
                  <div class="contact" >
                    
                     <span style="color:#878787;font-size:14px;">Orion Technologies Copyright ©2022 All rights reserved.</span>
                       
                     
                  </div>
               </div>
              
                  <div class="col-sm"  >
                  <div class="contact" >
                    
                     <span style="color:#878787;font-size:14px;margin-left:50%">Designed by Cpool Digital Learning</span>
                       
                     
                  </div>
               </div>
  
               
                
            </div>
         </div>
      <!-- end footer -->
      <!-- Javascript files--> 
      <script src="<?=base_url()?>js/jquery.min.js"></script> 
      <script src="<?=base_url()?>js/popper.min.js"></script> 
      <script src="<?=base_url()?>js/bootstrap.bundle.min.js"></script> 
      <script src="<?=base_url()?>js/jquery-3.0.0.min.js"></script> 
      <script src="<?=base_url()?>js/plugin.js"></script> 
      <!-- sidebar --> 
      <script src="<?=base_url()?>js/jquery.mCustomScrollbar.concat.min.js"></script> 
      <script src="<?=base_url()?>js/custom.js"></script>
      <script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
      <script>
         $(document).ready(function(){
         $(".fancybox").fancybox({
         openEffect: "none",
         closeEffect: "none"
         });
         
         $(".zoom").hover(function(){
         
         $(this).addClass('transition');
         }, function(){
         
         $(this).removeClass('transition');
         });
         });
         
      </script> 
   </body>
</html>