<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Complaint Registration</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f0f2f5;
      margin: 0;
      padding: 0;
    }

    .container {
      max-width: 600px;
      margin: 20px auto;
      background-color: #fff;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }

    .form-control {
      width: 100%;
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 4px;
      margin-bottom: 10px;
      box-sizing: border-box;
    }

    .form-control:focus {
      border-color: #3b5998;
      outline: none;
    }

    .btn-primary {
      background-color: #3b5998;
      color: #fff;
      padding: 10px 20px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    .btn-primary:hover {
      background-color: #1d3a7a;
    }

    .text-center {
      text-align: center;
    }

    .alert {
      padding: 10px;
      margin-bottom: 10px;
      border-radius: 4px;
    }

    .alert-success {
      background-color: #d4edda;
      color: #155724;
      border: 1px solid #c3e6cb;
    }

    .alert-danger {
      background-color: #f8d7da;
      color: #721c24;
      border: 1px solid #f5c6cb;
    }
  </style>
</head>
<body>
  <div class="container">
    <?php if($this->session->flashdata('ticketsuccess')) { ?>
      <div class="alert alert-success">
        <?= $this->session->flashdata('ticketsuccess') ?>
      </div>
    <?php } ?>

    <?php if($this->session->flashdata('usererror2')) { ?>
      <div class="alert alert-danger">
        <?= $this->session->flashdata('usererror2') ?>
      </div>
    <?php } ?>

    <h2 class="text-center">Register Complaint</h2>

    <?php if($flag == 0) { ?>
      <form method="POST" autocomplete="on" action="<?= base_url('Customer/complaint') ?>">
        <input type="text" placeholder="Your Name" name="name" class="form-control" required>
        <input type="text" placeholder="Your Email" name="email" class="form-control">
        <input type="text" placeholder="Your Contact Number" name="phone" class="form-control" maxlength="10" required>
        <textarea placeholder="Kindly Explain in detail (100 words)" rows="5" name="comdetail" class="form-control" required></textarea>
        <div class="text-center">
          <button type="submit" class="btn btn-primary">Submit</button>
        </div>
      </form>
    <?php } else { ?>
      <table>
        <tbody>
          <tr>
            <td><b>Complaint Id</b></td>
            <td>: <?php echo $tick->id; ?></td>
          </tr>
          <tr>
            <td><b>Registered Contact Number</b></td>
            <td>: <?php echo $tick->phone; ?></td>
          </tr>
        </tbody>
      </table>
    <?php } ?>

    <p class="text-center">
      <a href="https://markoseries.com/">Go Back to Homepage</a>
    </p>
  </div>
</body>
</html>
