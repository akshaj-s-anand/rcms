<style>



body {
 background-image: url("https://enviragallery.com/wp-content/uploads/2020/01/How-to-make-a-background-white.png");
 background-color: #cccccc;
 background-size:cover;
}
    
    
    
</style>
      
      <div class="w3-container w3-light-grey" style="padding:128px 16px" id="login">
          
          
          
          
          
          
          
  <h3 class="w3-center" style="margin-left:40%;margin-top:5%;">Get Your Complaint Status</h3>
  <div style="margin-top:-50px">
      	    <br><br>
   <form method="post" autocomplete="off" action="<?=base_url('Ticketresponse/complaintstatus')?>" style="margin-left:40%;">
      <p><input type="text" placeholder="Enter The Complaint Id" name="tickid" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" style="background-color: rgba(255,255,255,0.5);border-radius: 5px 0px 0px 5px;border-color:black;width:50%;height:35px" required></p>
      <p><input type="text" placeholder="Your Registered Mobile Number" name="phone" class="form-control"  aria-describedby="emailHelp" style="background-color: rgba(255,255,255,0.5);border-radius: 5px 0px 0px 5px;border-color:black;width:50%;height:35px" required>
</p>
      
        <button class="w3-button w3-black" type="submit">
          Submit
        </button>
      </p>
    </form>
    
   
  </div>
</div>
      
      
      