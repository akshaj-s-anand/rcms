<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Super Admin Page</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">

  <link rel="stylesheet" href="../dist/css/adminlte.min.css">
<style>
    * {
  box-sizing: border-box;
}
/* Float four columns side by side */
.column1 {
  float: left;
  width: 110px;
  padding: 0 5px;
}

/* Remove extra left and right margins, due to padding */
.row1 {margin: 0 -5px;}

/* Clear floats after the columns */
.row1:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive columns */
@media screen and (max-width: 600px) {
  .column1 {
  
    display: block;
    margin-bottom: 10px;
  }
}

/* Style the counter cards */
.card1 {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  padding: 5px;
  text-align: center;
  margin-top:15px
 
}
  table {
        background-color:#f2f2f2;;
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}
thead,th{
   border: 1px solid #ddd;
  padding: 8px;  
  background-color:#f2f2f2;
}
td {
  border: 1px solid #ddd;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2;}

tr:hover {background-color: #ddd;}

th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #04AA6D;
  color: white;
}
</style>
</head>
<body class="hold-transition sidebar-mini" >
<div class="wrapper" >

  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-green navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
   
    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      <!-- Navbar Search -->
      <li class="nav-item">
        <a class="nav-link" data-widget="navbar-search" href="#" role="button">
          <i class="fas fa-search"></i>
        </a>
        <div class="navbar-search-block">
          <form class="form-inline">
            <div class="input-group input-group-sm">
              <input class="form-control form-control-navbar" type="search" placeholder="Search" aria-label="Search">
              <div class="input-group-append">
                <button class="btn btn-navbar" type="submit">
                  <i class="fas fa-search"></i>
                </button>
                <button class="btn btn-navbar" type="button" data-widget="navbar-search">
                  <i class="fas fa-times"></i>
                </button>
              </div>
            </div>
          </form>
        </div>
      </li>

     
    </ul>
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="index3.html" class="brand-link">
      <img src="../dist/img/AdminLTELogo.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
      <span class="brand-text font-weight-light"><?php  $udata = $this->session->userdata('UserLoginSession');
    echo $udata['role'] ;?></span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
      <i class="fa fa-user " style="color:white;padding:4.7%"></i>
        <div class="info">
          <a href="#" class="d-block" style="font-size:20px"> <?php 
if($this->session->userdata('UserLoginSession'))
{
    $udata = $this->session->userdata('UserLoginSession');
    echo $udata['username'] ;
}
else
{
    redirect(base_url('Login_Registration/login'));
}



 ?></a>
   <a  href="<?=base_url('Superadmin/logout')?>"><b class="try" style="font-size:15px;color:#ff4d4d">LogOut</b></a>
  
        </div>
      </div>

     

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
               <li class="nav-item ">
       <a href="<?=base_url('Superadmin/ticketview')?>" class="nav-link ">
         <i class="fas fa-home"></i>
         <p>
          Home
          
         </p>
       </a>
         <li class="nav-item ">
       <a href="<?=base_url('Superadmin/registercomplaint')?>" class="nav-link ">
         <i class="fas fa-envelope"></i>
         <p>
          Complaint Registration
          
         </p>
       </a>
       <li class="nav-item ">
       <a href="<?=base_url('Superadmin/userrecords')?>" class="nav-link ">
         <i class="fas fa-users"></i>
         <p>
          User Records
          
         </p>
       </a>
       <li class="nav-item ">
       <a class="nav-link " id="drop"  ><i class="fas fa-users"></i>Engineer Records  <i id="demo2" class="fa fa-angle-double-right"></i></a></li>
       <div id="droplets" style="display:none; margin-left:10px;">
              <li class="nav-item ">
       <a href="<?=base_url('Admin/registerstaff')?>" class="nav-link ">
         <i class="fas fa-folder"></i>
         <p>
          Register Engineer
          
         </p>
       </a></li>
        <li class="nav-item ">
       <a href="<?=base_url('Admin/removestaff')?>" class="nav-link ">
         <i class="fas fa-folder"></i>
         <p>
          View/Remove Engineer
          
         </p>
       </a></li>
    <hr>
       </div>
       <li class="nav-item ">
       <a class="nav-link " id="drop5"  ><i class="fas fa-users"></i>Dealer Records  <i id="demo5" class="fa fa-angle-double-right"></i></a></li>
       <div id="droplets5" style="display:none; margin-left:10px;">
              <li class="nav-item ">
       <a href="<?=base_url('Admin/dealerstaff')?>" class="nav-link ">
         <i class="fas fa-folder"></i>
         <p>
          Register Dealer
          
         </p>
       </a></li>
        <li class="nav-item ">
       <a href="<?=base_url('Admin/removedealer')?>" class="nav-link ">
         <i class="fas fa-folder"></i>
         <p>
          View/Remove Dealer
          
         </p>
       </a></li>
       </div>
   
         <li class="nav-item ">
       <a class="nav-link " id="drop4"  ><i class='fas fa-ticket-alt'></i>Complaints  <i id="demo4" class="fa fa-angle-double-right"></i></a></li>
       <div id="droplets4" style="display:none; margin-left:10px;">
              <li class="nav-item ">
       <a href="<?=base_url('Admin/allticketview')?>" class="nav-link ">
         <i class="fas fa-folder"></i>
         <p>
         All Complaints
          
         </p>
       </a>
       
        <li class="nav-item ">
       <a href="<?=base_url('Admin/assignstaff')?>" class="nav-link ">
         <i class="fas fa-folder"></i>
         <p>
          Assign Engineer 
          
         </p>
       </a>
     <li class="nav-item">
       <a href="<?=base_url('Admin/viewopentickets')?>" class="nav-link">
         <i class="fas fa-folder"></i>
         <p>
          Open Complaints
          
         </p>
       </a>  
     </li>
     <li class="nav-item">
       <a href="<?=base_url('Admin/viewmyduetoday')?>" class="nav-link">
         <i class="fas fa-folder"></i>
         <p>
           Due Today Complaints
         </p>
       </a>
           </li>
    
   
     <li class="nav-item">
       <a href="<?=base_url('Admin/viewoverduetickets')?>" class="nav-link">
         <i class="fas fa-folder"></i>
         <p>
          Overdue Complaints
          
         </p>
       </a>  
     </li>
     <li class="nav-item">
       <a href="<?=base_url('Admin/viewunassigned')?>" class="nav-link">
         <i class="fas fa-folder"></i>
         <p>
          Unassigned Complaints
        
         </p>
       </a>  
     </li>
      <li class="nav-item">
       <a href="<?=base_url('Admin/viewassigned')?>" class="nav-link">
         <i class="fas fa-folder"></i>
         <p>
          Assigned Complaints
        
         </p>
       </a>  
     </li>
      <li class="nav-item">
       <a href="<?=base_url('Superadmin/resolvedtickets')?>" class="nav-link">
         <i class="fas fa-folder"></i>
         <p>
          Resolved Complaints
        
         </p>
       </a>  
     </li>
    <hr>
       </div>
                
       
      
     
     
      <!--li class="nav-item ">
       <a href="<?=base_url()?>Welcome/addHhomeSlider" target="_blank" rel="noopener noreferrer" class="nav-link ">
        <i class="fas fa-link"></i>
         <p>
          Add Home Slider
          
         </p>
       </a>
        </li>
        
        
        
         <li class="nav-item ">
       <a href="<?=base_url()?>Welcome/addHhomeSlider2" target="_blank" rel="noopener noreferrer" class="nav-link ">
        <i class="fas fa-link"></i>
         <p>
          Add Services Section
          
         </p>
       </a>
        </li>
        
        
         <li class="nav-item ">
       <a href="<?=base_url()?>Welcome/addHhomeSlider3" target="_blank" rel="noopener noreferrer" class="nav-link ">
        <i class="fas fa-link"></i>
         <p>
          Add About us Section
          
         </p>
       </a>
        </li>
        
        
         <li class="nav-item ">
       <a href="<?=base_url()?>Welcome/addHhomeSlider4" target="_blank" rel="noopener noreferrer" class="nav-link ">
        <i class="fas fa-link"></i>
         <p>
          Add Testimonial Section
          
         </p>
       </a>
        </li>
        
        
        <p style="color:white;">Add or update Product Section</p>
        
        <li class="nav-item ">
       <a href="<?=base_url()?>Welcome/addHhomeSlider5" target="_blank" rel="noopener noreferrer" class="nav-link ">
        <i class="fas fa-link"></i>
         <p>
          Update Battery Page1
          
         </p>
       </a>
        </li>
        
        
        <li class="nav-item ">
       <a href="<?=base_url()?>Welcome/addHhomeSlider6" target="_blank" rel="noopener noreferrer" class="nav-link ">
        <i class="fas fa-link"></i>
         <p>
          Update Battery Page2
          
         </p>
       </a>
        </li>
        
        
         <li class="nav-item ">
       <a href="<?=base_url()?>Welcome/addHhomeSlider7" target="_blank" rel="noopener noreferrer" class="nav-link ">
        <i class="fas fa-link"></i>
         <p>
          Update Solar Product Section
          
         </p>
       </a>
        </li>
        
        
        
        <li class="nav-item ">
       <a href="<?=base_url()?>Welcome/addHhomeSlider8" target="_blank" rel="noopener noreferrer" class="nav-link ">
        <i class="fas fa-link"></i>
         <p>
          Update Solar Product page2 Section
          
         </p>
       </a>
        </li>
        
        
         <li class="nav-item ">
       <a href="<?=base_url()?>Welcome/addHhomeSlider9" target="_blank" rel="noopener noreferrer" class="nav-link ">
        <i class="fas fa-link"></i>
         <p>
          Update UPS/INVERTER Section
          
         </p>
       </a>
        </li>
        
        
         <li class="nav-item ">
       <a href="<?=base_url()?>Welcome/addHhomeSlider10" target="_blank" rel="noopener noreferrer" class="nav-link ">
        <i class="fas fa-link"></i>
         <p>
          Update Solar Water Heater Section
          
         </p>
       </a>
        </li-->
     
     
     
     
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper" >
    <!-- Content Header (Page header) -->
   
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
        <div class="row1" style="margin-top:20px;" >
  <div class="column1">
    <button type="button" onclick="location.href='<?=base_url('Admin/allticketview')?>'" class="card1" style="border-radius: 5px;width: 100px;height: 80px;background-color:green;color:white;border-color:transparent"><em class="fa fa-folder"style="font-size: 20px;"></em><br><a style="font-size: 12px;">All complaints</a> <br><br></button>
    </div>
 <div class="column1">
      <button type="button" onclick="location.href='<?=base_url('Admin/viewopentickets')?>'" class="card1" style="border-radius: 5px;width: 100px;height: 80px;background-color:green;color:white;border-color:transparent"><em class="fa fa-folder"style="font-size: 20px;"></em><br><a style="font-size: 12px;">Open complaints</a> <br><br></button>
  </div>
   <div class="column1">
 <button type="button" onclick="location.href='<?=base_url('Admin/viewmyduetoday')?>'" class="card1" style="border-radius: 5px;width: 100px;height: 80px;background-color:green;color:white;border-color:transparent"><em class="fa fa-folder"style="font-size: 20px;"></em><br><a style="font-size: 12px;">Due Today complaints </a> <br><br></button>
  </div>
   <div class="column1">
<button type="button" onclick="location.href='<?=base_url('Admin/viewunassigned')?>'" class="card1" style="border-radius: 5px;width: 100px;height: 80px;background-color:green;color:white;border-color:transparent"><em class="fa fa-folder"style="font-size: 20px;"></em><br><a style="font-size: 12px;">Unassigned complaints</a> <br><br></button>
  </div>
 <div class="column1">
      <button type="button" onclick="location.href='<?=base_url('Admin/viewassigned')?>'" class="card1" style="border-radius: 5px;width: 100px;height: 80px;background-color:green;color:white;border-color:transparent"><em class="fa fa-folder"style="font-size: 20px;"></em><br><a style="font-size: 12px;">Assigned Complaints</a> <br><br></button>
  </div>
   <div class="column1">
           <button type="button" onclick="location.href='<?=base_url('Admin/viewoverduetickets')?>'" class="card1" style="border-radius: 5px;width: 100px;height: 80px;background-color:green;color:white;border-color:transparent"><em class="fa fa-folder"style="font-size: 20px;"></em><br><a style="font-size: 12px;">Overdue complaints</a> <br><br></button>
  </div>
  <div class="column1">
    <button type="button" onclick="location.href='<?=base_url('Admin/assignstaff')?>'" class="card1" style="border-radius: 5px;width: 100px;height: 80px;background-color:green;color:white;border-color:transparent"><em class="fa fa-folder"style="font-size: 20px;"></em><br><a style="font-size: 12px;">Assign Engineer</a> <br><br></button>
  </div>
   <div class="column1">
    <button type="button" onclick="location.href='<?=base_url('Admin/registerstaff')?>'" class="card1" style="border-radius: 5px;width: 100px;height: 80px;background-color:green;color:white;border-color:transparent"><em class="fa fa-folder"style="font-size: 20px;"></em><br><a style="font-size: 12px;">Register Engineer</a> <br><br></button>
  </div>
   <div class="column1">
    <button type="button" onclick="location.href='<?=base_url('Admin/removestaff')?>'" class="card1" style="border-radius: 5px;width: 100px;height: 80px;background-color:green;color:white;border-color:transparent"><em class="fa fa-folder"style="font-size: 20px;"></em><br><a style="font-size: 12px;">View Engineer</a> <br><br></button>
  </div>
   <div class="column1">
    <button type="button" onclick="location.href='<?=base_url('Superadmin/userrecords')?>'" class="card1" style="border-radius: 5px;width: 100px;height: 80px;background-color:green;color:white;border-color:transparent"><em class="fa fa-folder"style="font-size: 20px;"></em><br><a style="font-size: 12px;">User Records</a> <br><br></button>
  </div>
  <div class="column1">
    <button type="button" onclick="location.href='<?=base_url('Superadmin/registercomplaint')?>'" class="card1" style="border-radius: 5px;width: 100px;height: 80px;background-color:green;color:white;border-color:transparent"><em class="fa fa-folder"style="font-size: 20px;"></em><br><a style="font-size: 12px;">Complaint Registration</a> <br><br></button>
  </div>
</div>
 
  
      
         <div class="row" style="margin-top:15px">
            
      
                      <div class="col">
           
            <div class="card"style="background-color: rgb(224, 210, 170);min-width:300px">
            
              <div class="card-body">
         <div style="width:100%; height:400px; overflow:auto;">
       <table style="height:400px; overflow:auto;">
           <thead>
               <tr>
                    <th>T.Id</th>
                   <th>Customer</th>
                   <th>Item</th>
                    <th>Complaint</th>
                     <th>Overdue</th>
                      <th>Date-Time</th>
                     <th>Assign Status</th>
                      <th>Status</th>
               </tr>
           </thead>
                      <tbody>
                      <?php  
                      foreach ($h->result() as $row)  
                      {  if($row->assign_status==0){ 
                        $d1=new DateTime();
                        $d2 = date_create($row->date);
                        $row->diff=date_diff($d2,$d1);
                        $row->d=(int)$row->diff->format("%R%a");
                        ?><tr> 
                         <td><?php echo $row->id;?></td>  
                        <td><a href="https://support.oriontechnologies.co.in/Admin/assignstaff"><?php echo $row->customername;?></a></td>  
                         <td><?php echo $row->item;?></td>  
                        <td><?php echo $row->rqr;?></td>
                       <td> <form style="color:red"><?php if(($row->d)>8){ echo "Overdue";}else{echo ' ';} ?></form></td>
                        <td>Due Time:<?php echo $row->date?> <?php echo $row->time?></td>   
                        <td> <?php if(($row->assign_status)==0){ ?><p style="color:red"> Unassigned </p><?php } ?><?php if(($row->assign_status)==1){ ?><p style="color:green"> Assigned </p><?php } ?></td>
                          <td> <?php if(($row->status)==0){ ?><p style="color:red"> Open </p><?php } ?><?php if(($row->status)==1){ ?><p style="color:#a63d05"> Working </p><?php } ?><?php if(($row->status)==2){ ?><p style="color:#bf762c"> Temporarly Closed </p><?php } ?><?php if(($row->status)==3){ ?><p style="color:green"> Closed </p><?php } ?></td>
                        </tr> 
                          </tr>  
                      <?php }  }
                      ?>  
                    </tbody>
                  </table>
              </div>
            </div><!-- /.card -->
            </div>
          </div>
          <!-- /.col-md-6 -->
     
            
            
            
        
       
          <!-- /.col-md-6 -->
        
        </div>
        <!-- /.row -->
        
      </div><!-- /.container-fluid -->
     

    </div>
    <!-- /.content -->
  </div> <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
    <div class="p-3">
      <h5>Title</h5>
      <p>Sidebar content</p>
    </div>
  </aside>
  <!-- /.control-sidebar -->

</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->

<!-- jQuery -->
<script src="../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="../dist/js/adminlte.min.js"></script>
 <script>
$(document).ready(function(){
  $("#drop").click(function(){
      var x = document.getElementById("demo2");
     if (x.className.indexOf("fa fa-angle-double-down") == -1) {
       x.className = " fa fa-angle-double-down";   
     }else{
         x.className = " fa fa-angle-double-right";   
     }
    $("#droplets").toggle();
  });
});
</script>
<script>
$(document).ready(function(){
  $("#drop3").click(function(){
      var x = document.getElementById("demo3");
     if (x.className.indexOf("fa fa-angle-double-down") == -1) {
       x.className = " fa fa-angle-double-down";   
     }else{
         x.className = " fa fa-angle-double-right";   
     }
    $("#droplets3").toggle();
  });
});
</script>
<script>
$(document).ready(function(){
  $("#drop4").click(function(){
      var x = document.getElementById("demo4");
     if (x.className.indexOf("fa fa-angle-double-down") == -1) {
       x.className = " fa fa-angle-double-down";   
     }else{
         x.className = " fa fa-angle-double-right";   
     }
    $("#droplets4").toggle();
  });
});
$(document).ready(function(){
  $("#drop5").click(function(){
      var x = document.getElementById("demo5");
     if (x.className.indexOf("fa fa-angle-double-down") == -1) {
       x.className = " fa fa-angle-double-down";   
     }else{
         x.className = " fa fa-angle-double-right";   
     }
    $("#droplets5").toggle();
  });
});
</script>
</body>
</html>
