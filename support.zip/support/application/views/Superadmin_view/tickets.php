<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Super Admin Page</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">

  <link rel="stylesheet" href="../dist/css/adminlte.min.css">
<style>
    * {
  box-sizing: border-box;
}
/* Float four columns side by side */
.column1 {
  float: left;
  width: 110px;
  padding: 0 5px;
}

/* Remove extra left and right margins, due to padding */
.row1 {margin: 0 -5px;}

/* Clear floats after the columns */
.row1:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive columns */
@media screen and (max-width: 600px) {
  .column1 {
  
    display: block;
    margin-bottom: 10px;
  }
}

/* Style the counter cards */
.card1 {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  padding: 5px;
  text-align: center;
  margin-top:15px
 
}
  table {
        background-color:#f2f2f2;;
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}
thead,th{
   border: 1px solid #ddd;
  padding: 8px;  
  background-color:#f2f2f2;
}
td {
  border: 1px solid #ddd;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2;}

tr:hover {background-color: #ddd;}

th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #04AA6D;
  color: white;
}
</style>
</head>
<body class="hold-transition sidebar-mini" >
<div class="wrapper" >

<?php include_once('admin_header.php'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper" >
    <!-- Content Header (Page header) -->
   
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
        <div class="row1" style="margin-top:20px;" >
  <div class="column1">
    <button type="button" onclick="location.href='<?=base_url('Admin/allticketview')?>'" class="card1" style="border-radius: 5px;width: 100px;height: 80px;background-color:green;color:white;border-color:transparent"><em class="fa fa-folder"style="font-size: 20px;"></em><br><a style="font-size: 12px;">All complaints</a> <br><br></button>
    </div>
 <div class="column1">
      <button type="button" onclick="location.href='<?=base_url('Admin/viewopentickets')?>'" class="card1" style="border-radius: 5px;width: 100px;height: 80px;background-color:green;color:white;border-color:transparent"><em class="fa fa-folder"style="font-size: 20px;"></em><br><a style="font-size: 12px;">Open complaints</a> <br><br></button>
  </div>
   <div class="column1">
 <button type="button" onclick="location.href='<?=base_url('Admin/viewmyduetoday')?>'" class="card1" style="border-radius: 5px;width: 100px;height: 80px;background-color:green;color:white;border-color:transparent"><em class="fa fa-folder"style="font-size: 20px;"></em><br><a style="font-size: 12px;">Due Today complaints </a> <br><br></button>
  </div>
   <div class="column1">
<button type="button" onclick="location.href='<?=base_url('Admin/viewunassigned')?>'" class="card1" style="border-radius: 5px;width: 100px;height: 80px;background-color:green;color:white;border-color:transparent"><em class="fa fa-folder"style="font-size: 20px;"></em><br><a style="font-size: 12px;">Unassigned complaints</a> <br><br></button>
  </div>
 <div class="column1">
      <button type="button" onclick="location.href='<?=base_url('Admin/viewassigned')?>'" class="card1" style="border-radius: 5px;width: 100px;height: 80px;background-color:green;color:white;border-color:transparent"><em class="fa fa-folder"style="font-size: 20px;"></em><br><a style="font-size: 12px;">Assigned Complaints</a> <br><br></button>
  </div>
   <div class="column1">
           <button type="button" onclick="location.href='<?=base_url('Admin/viewoverduetickets')?>'" class="card1" style="border-radius: 5px;width: 100px;height: 80px;background-color:green;color:white;border-color:transparent"><em class="fa fa-folder"style="font-size: 20px;"></em><br><a style="font-size: 12px;">Overdue complaints</a> <br><br></button>
  </div>
  <div class="column1">
    <button type="button" onclick="location.href='<?=base_url('Admin/assignstaff')?>'" class="card1" style="border-radius: 5px;width: 100px;height: 80px;background-color:green;color:white;border-color:transparent"><em class="fa fa-folder"style="font-size: 20px;"></em><br><a style="font-size: 12px;">Assign Engineer</a> <br><br></button>
  </div>
   <div class="column1">
    <button type="button" onclick="location.href='<?=base_url('Admin/registerstaff')?>'" class="card1" style="border-radius: 5px;width: 100px;height: 80px;background-color:green;color:white;border-color:transparent"><em class="fa fa-folder"style="font-size: 20px;"></em><br><a style="font-size: 12px;">Register Engineer</a> <br><br></button>
  </div>
   <div class="column1">
    <button type="button" onclick="location.href='<?=base_url('Admin/removestaff')?>'" class="card1" style="border-radius: 5px;width: 100px;height: 80px;background-color:green;color:white;border-color:transparent"><em class="fa fa-folder"style="font-size: 20px;"></em><br><a style="font-size: 12px;">View Engineer</a> <br><br></button>
  </div>
   <div class="column1">
    <button type="button" onclick="location.href='<?=base_url('Superadmin/userrecords')?>'" class="card1" style="border-radius: 5px;width: 100px;height: 80px;background-color:green;color:white;border-color:transparent"><em class="fa fa-folder"style="font-size: 20px;"></em><br><a style="font-size: 12px;">User Records</a> <br><br></button>
  </div>
  <div class="column1">
    <button type="button" onclick="location.href='<?=base_url('Superadmin/registercomplaint')?>'" class="card1" style="border-radius: 5px;width: 100px;height: 80px;background-color:green;color:white;border-color:transparent"><em class="fa fa-folder"style="font-size: 20px;"></em><br><a style="font-size: 12px;">Complaint Registration</a> <br><br></button>
  </div>
</div>
 
  
      
         <div class="row" style="margin-top:15px">
            
      
                      <div class="col">
           
            <div class="card"style="background-color: rgb(224, 210, 170);min-width:300px">
            
              <div class="card-body">
         <div style="width:100%; height:400px; overflow:auto;">
       <table style="height:400px; overflow:auto;">
           <thead>
               <tr>
                    <th>T.Id</th>
                   <th>Customer</th>
                   <th>Item</th>
                    <th>Complaint</th>
                     <th>Overdue</th>
                      <th>Date-Time</th>
                     <th>Assign Status</th>
                      <th>Status</th>
               </tr>
           </thead>
                      <tbody>
                      <?php  
                      foreach ($h->result() as $row)  
                      {  if($row->assign_status==0){ 
                        $d1=new DateTime();
                        $d2 = date_create($row->date);
                        $row->diff=date_diff($d2,$d1);
                        $row->d=(int)$row->diff->format("%R%a");
                        ?><tr> 
                         <td><?php echo $row->id;?></td>  
                        <td><a href=<?=base_url('/Admin/assignstaff')?>><?php echo $row->customername;?></a></td>  
                         <td><?php echo $row->item;?></td>  
                        <td><?php echo $row->rqr;?></td>
                       <td> <form style="color:red"><?php if(($row->d)>8){ echo "Overdue";}else{echo ' ';} ?></form></td>
                        <td>Due Time:<?php echo $row->date?> <?php echo $row->time?></td>   
                        <td> <?php if(($row->assign_status)==0){ ?><p style="color:red"> Unassigned </p><?php } ?><?php if(($row->assign_status)==1){ ?><p style="color:green"> Assigned </p><?php } ?></td>
                          <td> <?php if(($row->status)==0){ ?><p style="color:red"> Open </p><?php } ?><?php if(($row->status)==1){ ?><p style="color:#a63d05"> Working </p><?php } ?><?php if(($row->status)==2){ ?><p style="color:#bf762c"> Temporarly Closed </p><?php } ?><?php if(($row->status)==3){ ?><p style="color:green"> Closed </p><?php } ?></td>
                        </tr> 
                          </tr>  
                      <?php }  }
                      ?>  
                    </tbody>
                  </table>
              </div>
            </div><!-- /.card -->
            </div>
          </div>
          <!-- /.col-md-6 -->
     
            
            
            
        
       
          <!-- /.col-md-6 -->
        
        </div>
        <!-- /.row -->
        
      </div><!-- /.container-fluid -->
     

    </div>
    <!-- /.content -->
  </div> <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
    <div class="p-3">
      <h5>Title</h5>
      <p>Sidebar content</p>
    </div>
  </aside>
  <!-- /.control-sidebar -->

</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->

<!-- jQuery -->
 
<!-- Bootstrap 4 -->
<script src="../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="../dist/js/adminlte.min.js"></script>
 
 
</body>
</html>
