<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Engineer Page</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <link rel="stylesheet" href="<?=base_url('plugins/fontawesome-free/css/all.min.css')?>">

  <link rel="stylesheet" href="<?=base_url('dist/css/adminlte.min.css')?>">
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
 
<style>
    table {
        background-color:white;
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}
thead,th{
   border: 1px solid #ddd;
  padding: 8px;  
  background-color:#27a143;
}
td {
  border: 1px solid #ddd;
  padding: 8px;
}





th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #04AA6D;
  color: white;
}
.button1 {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 5px 20px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  transition-duration: 0.4s;
  cursor: pointer;
}

.button2 {
  background-color: white; 
  color: black; 
  border: 2px solid #007FFF;
}

.button2:hover {
  background-color: #007FFF;
  color: white;
}
.container1 {
  border: 2px solid #dedede;
  background-color: #f1f1f1;
  border-radius: 5px;
  padding: 10px;
  margin: 10px 0;
}

.darker {
  border-color: #ccc;
  background-color: #ddd;
}

.container1::after {
  content: "";
  clear: both;
  display: table;
}

.container1 label {
  float: left;
  max-width: 60px;
  width: 100%;
  margin-right: 20px;
  border-radius: 50%;
}

.container1 label.right {
  float: right;
  margin-left: 20px;
  margin-right:0;
}

.time-right {
  float: right;
  color: #aaa;
}

.time-left {
  float: left;
  color: #999;
}
#overflowC {
 
  padding: 15px;
 
  height: 300px;
  overflow: auto;
  border: 1px solid #ccc;
}
</style>
</head>
<body  style="width:auto;min-width:174px">
    
<div class="wrapper">
<?php if($flag==1){ ?>
     <a href="<?php echo base_url('Superadmin/userrecords')?>" type="link" class="link button1 button2" >Go Back</a>
<?php } ?>
<?php if($flag==2){ ?>
     <a href="<?php echo base_url('Superadmin/userrecords')?>" type="link" class="link button1 button2" >Go Back</a>
<?php } ?>

  

  
  <div class="content-wrapper">
   
  

    <!-- Main content -->
    <div class="content">
      
      <div class="container-fluid">
      
          <h5>Work Details</h5>
         <table>
             <tbody>
                 <tr><td><b>Ticket Id</b></td>
                 <td><?php echo $tick->tickid ?></td></tr>
             <tr><td><b>Item</b></td>
                 <td><?php echo $tick->item ?></td></tr>
             <tr><td><b>Model</b></td>
                 <td><?php echo $tick->model ?></td></tr>
              <tr><td><b>Brand</b></td>
                 <td> <?php echo $tick->brand ?></td></tr>
              <tr><td><b>Customer Complaint</b></td>
                 <td> <?php echo $tick->rqr ?></td></tr>
             <tr><td><b>Actual Complaint</b></td>
                 <td><?php echo $tick->complaint ?></td></tr>
              <tr><td><b>Work Done</b></td>
                 <td> <?php echo $tick->work ?></td></tr>
              <tr><td><b>Additional Note</b></td>
                 <td><?php echo $tick->note ?></td></tr>
      </tbody>
         </table> 
            <h5>Payment Details</h5>
         <table>
             <tbody>
                        <tr><td><b>Payment Done By</b></td>
                 <td>  <?php echo $tick->paymentby ?></td></tr>
          <tr><td><b>Payment Status</b></td>
                 <td>  <?php echo $tick->paystatus ?></td></tr>
                
             </tbody>
         </table>
              <h5>Contact Details</h5>
         <table>
             <tbody>
                 <tr><td><b>Customer Name</b></td>
                 <td><?php echo $tick->customername ?></td></tr>
             <tr><td><b>Customer Contact</b></td>
                 <td> <?php echo $tick->cphone ?></td></tr>
              <tr><td><b>Engineer Name</b></td>
                 <td><?php echo $tick->engineer ?></td></tr>
              <tr><td><b>Engineer Contact</b></td>
                 <td> <?php echo $tick->ephone ?></td></tr>
             </tbody>
         </table>           
         
          </div>

        </div>
        <!-- /.row -->
        
      </div><!-- /.container-fluid -->
 
  <!-- /.content-wrapper -->

 

</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->

<!-- jQuery -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.3/jquery.min.js"></script>
  <!-- Bootstrap 3.3.6 -->
 
  <!-- AdminLTE App -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/admin-lte/2.3.11/js/app.min.js"></script>
<script src="<?base_url()?>plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?base_url()?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="<?base_url()?>dist/js/adminlte.min.js"></script>
</body>
</html>
