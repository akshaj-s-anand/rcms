<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Super Admin Page</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <link rel="stylesheet" href="<?php echo base_url();?>/plugins/fontawesome-free/css/all.min.css">

  <link rel="stylesheet" href="<?php echo base_url();?>/dist/css/adminlte.min.css">
<style>
    * {
  box-sizing: border-box;
}
/* Float four columns side by side */
.column1 {
  float: left;
  width: 110px;
  padding: 0 5px;
}

  table {
        background-color:#f2f2f2;;
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}
thead,th{
   border: 1px solid #ddd;
  padding: 8px;  
  background-color:#f2f2f2;
}
td {
  border: 1px solid #ddd;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2;}

tr:hover {background-color: #ddd;}

th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #04AA6D;
  color: white;
}
</style>
</head>
<body class="hold-transition sidebar-mini" >
<div class="wrapper" >

<?php include_once('admin_header.php'); ?>
  <!-- Content Wrapper. Contains page content -->
   <section class="Form my-4 mx-5 center" >
       <div class="container" style=" background-color: rgba(255,255,255,0.5);width:40%;height:50%;border-radius:20px;min-width:270px; ">
           <div class="row">
               <div class="card-header text-center"style="background-color:transparent;border-color:transparent">
						<h3>Edit Complaint For Customer</h3>
						<br>
					
					  </div>
           
					
              <form method="POST"  autocomplete="off" action="<?=base_url('Superadmin/editedComplaintUpdt')?>">
					
					   
						  <input type="hidden" name="cid" value="<?php echo $tick[0]->id;?>"/>
						  <input type="hidden" name="cusid" value="<?php echo $tick[0]->customerid;?>"/>
					   	<div class="mb-3">
						  <label for="exampleInputEmail1" class="form-label">Name*</label>
						    <input type="text" placeholder="Customer Name" style="border-radius:5px;border-color:black;width:100%;height:37px" name="name" value="<?php echo $tick[0]->customername;?>" class="form-control" id="name" aria-describedby="name" required> 
						  </div>
						  	<div class="mb-3">
						  <label for="exampleInputEmail1" class="form-label">Email*</label>
						    <input type="text" placeholder="Customer Email" style="border-radius:5px;border-color:black;width:100%;height:37px" name="email" value="<?php echo $tick[0]->email;?>" class="form-control" id="name" aria-describedby="name" required> 
						  </div>
						  	<div class="mb-3">
						  <label for="exampleInputEmail1" class="form-label">Contact Number*</label>
						    <input type="text" placeholder="Customer Contact Number" style="border-radius:5px;border-color:black;width:100%;height:37px" name="phone" value="<?php echo $tick[0]->phone;?>" class="form-control" id="name" aria-describedby="name" required> 
						  </div>
						  <div class="mb-3">
						    <label for="exampleInputEmail1" class="form-label">Address*</label>
						    <textarea  placeholder="Customer Address" style="border-radius:5px;border-color:black;width:100%" rows="5" cols="30" name="address" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required><?php echo $tick[0]->address;?></textarea></div>
						  		
						  		<div class="mb-3">
						  <label for="exampleInputEmail1" class="form-label">Organization Name</label>
						    <input type="text" placeholder="Organization Name" style="border-radius:5px;border-color:black;width:100%;height:37px" name="orgname" value="<?php echo $tick[0]->orgname;?>" class="form-control" id="name" aria-describedby="name" > 
						  </div>
						  		
						  		<div class="mb-3">
						  
						    <label for="exampleInputEmail1" class="form-label">Item*</label>
						    <input type="text" placeholder="Item" style="border-radius:5px;border-color:black;width:100%;height:37px" name="item" value="<?php echo $tick[0]->item;?>" class="form-control" id="name" aria-describedby="name" > 
						  </div>
						  	<div class="mb-3">
						  
						    <label for="exampleInputEmail1" class="form-label">Model*</label>
						    <input type="text" placeholder="Model" style="border-radius:5px;border-color:black;width:100%;height:37px" name="model" value="<?php echo $tick[0]->model;?>" class="form-control" id="name" aria-describedby="name" > 
						  </div>
						  	<div class="mb-3">
						  
						    <label for="exampleInputEmail1" class="form-label">Brand*</label>
						    <input type="text" placeholder="Brand" style="border-radius:5px;border-color:black;width:100%;height:37px" name="brand" value="<?php echo $tick[0]->brand;?>" class="form-control" id="name" aria-describedby="name" > 
						  </div>
						  <div class="mb-3">
						    <label for="exampleInputEmail1" class="form-label">Product Detail</label>
						    <textarea  placeholder="Kindly Explain the Product Details" style="border-radius:5px;border-color:black;width:100%" rows="5" cols="30" name="prodetail" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" ><?php echo $tick[0]->prodetail;?></textarea></div>
						<div class="mb-3">
						  
						    <label for="exampleInputEmail1" class="form-label">Details of Complaint*</label>
						   <textarea  placeholder="Kindly Explain in detail(100 words)" style="border-radius:5px;border-color:black;width:100%" rows="5" cols="30" name="comdetail" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" ><?php echo $tick[0]->rqr;?></textarea>
						  </div>	<div class="mb-3">
						  
						    <label for="exampleInputEmail1" class="form-label">Remarks</label>
						   <textarea  placeholder="Give  Remarks." style="border-radius:5px;border-color:black;width:100%" rows="5" cols="30" name="remark" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" ><?php echo $tick[0]->remark;?></textarea>
						  </div>
						 <div class="text-center">
						  <button type="submit" class="btn btn-primary">Submit</button>
						  
						</div>

						</form>
        
</div></div> <br><br>  </section>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
    <div class="p-3">
      <h5>Title</h5>
      <p>Sidebar content</p>
    </div>
  </aside>
  <!-- /.control-sidebar -->

</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->

<!-- jQuery -->
<script src="<?php echo base_url();?>/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo base_url();?>/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url();?>/dist/js/adminlte.min.js"></script>
  
</body>
</html>
