<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Super Admin Page</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <link rel="stylesheet" href="<?php echo base_url()?>plugins/fontawesome-free/css/all.min.css">

  <link rel="stylesheet" href="<?php echo base_url()?>dist/css/adminlte.min.css">
<style>
    table {
        background-color:white;
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td,th {
  border: 1px solid #ddd;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2;}

tr:hover {background-color: #ddd;}

th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #04AA6D;
  color: white;
}
</style>
</head>
<body class="hold-transition sidebar-mini" style="width:auto;min-width:174px">
<div class="wrapper">
<?php include_once('admin_header.php'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-4">
            <h1 class="m-0" style="float:left">Manage Items</h1>  
          </div>
           <div class="col-sm-4">
           <?php
						if($this->session->flashdata('success') !="") {	?>
						 <p class=" text-center" style="color:#04AA6D;margin-top: 10px; font-weight:bold;"> <?=$this->session->flashdata('success')?></p>
						 
						<?php  } 
                        ?>	
              <p class="text-success text-center" style="color:#04AA6D;margin-top: 10px; font-weight:bold; display:none;"></p>
						 
              <?php
						if($this->session->flashdata('usererror2') !="") {	?>
						 <p class="text-center" style="color:red;margin-top: 10px;font-weight:bold;"> <?=$this->session->flashdata('usererror2')?></p>
						<?php } ?>
            <p class="text-error text-center" style="color:red;margin-top: 10px;font-weight:bold; display:none;"> </p>
          </div>
          <div class="col-sm-4">
             <span style="float:right;"><a href="<?php echo base_url()?>Superadmin/addItem/"><b>Add Item</b></a></span>
          </div>
          
        </div><!-- /.row -->
        
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      
      <div class="container-fluid">
      
     
           
            <div class="card card-primary card-outline"style="width:100%;min-width:374px; background-color: rgb(224, 210, 170)">
           
    
             
             
       <div style="width:100%; height:70%; overflow:auto;">
       <table id="datatable-buttons">
           <thead>
               <tr>
                    <th>Sl Num</th>
                    <th>Item</th>
                   <th>Status</th>
                   <th>Action</th>
               </tr>
           </thead>
                      
                  </table>
              </div>
            </div><!-- /.card -->
          </div>
          <!-- /.col-md-6 -->
        
        </div>
        <!-- /.row -->
        
      </div><!-- /.container-fluid -->
 
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
    <div class="p-3">
      <h5>Title</h5>
      <p>Sidebar content</p>
    </div>
  </aside>
  <!-- /.control-sidebar -->

  <!-- Main Footer -->
  
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->

<!-- jQuery -->

<!-- Bootstrap 4 -->
<script src="<?php echo base_url()?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url()?>dist/js/adminlte.min.js"></script>
 </body>
</html>

<script>
var table ;  
$(document).ready(function() { 
 
table = $('#datatable-buttons').DataTable({
        dom: 'Bfrtip',
        "ordering": false,
        "ajax": {
            url : "<?php echo base_url()?>superadmin/getitemlist/",
            type : 'POST',
        
            error: function(){  
                $("#datatable-buttons tbody tr").css("display","none");
                $("#datatable-buttons").append('<tr><td colspan="9" style="margin:10px auto;">No results.</td></tr>');
            }
        },
    });
 

} );
function deleteItem(itm_id){
  var result = confirm("Want to delete?");
  if (result==true) {
    $.ajax({
            url: '<?php echo base_url()?>superadmin/deleteItem/',
            type: "POST",
            data:{'itm_id':itm_id},
            dataType: "json",
            success: function(response)
            {	
                if(parseInt(response) == 1){
                   $('.text-success').show('slow');
                    $('.text-success').html('Successfully Deleted');
                   $('#datatable-buttons').DataTable().ajax.reload();
                }else{
                  $('.text-error').show('slow');
                    $('.text-error').html('Successfully Deleted');
                    <?php echo $this->session->set_flashdata('usererror2','Error in Deletion.'); ?>
                }

                 $('#deleteAsset').modal('hide'); 
            }
            
        });
      }
}
</script>
