<script src="<?php echo base_url()?>plugins/jquery/jquery.min.js"></script>
  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-green navbar-light"style="width:auto;min-width:174px">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
     
    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      <!-- Navbar Search -->
      <li class="nav-item">
        <a class="nav-link" data-widget="navbar-search" href="#" role="button">
          <i class="fas fa-search"></i>
        </a>
        <div class="navbar-search-block">
          <form class="form-inline">
            <div class="input-group input-group-sm">
              <input class="form-control form-control-navbar" type="search" placeholder="Search" aria-label="Search">
              <div class="input-group-append">
                <button class="btn btn-navbar" type="submit">
                  <i class="fas fa-search"></i>
                </button>
                <button class="btn btn-navbar" type="button" data-widget="navbar-search">
                  <i class="fas fa-times"></i>
                </button>
              </div>
            </div>
          </form>
        </div>
      </li>

    </ul>
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4" style="position:fixed !important; overflow: scroll; height:100% !important;">
    <!-- Brand Logo -->
    <a href="index3.html" class="brand-link">
      <img src="<?php echo base_url()?>dist/img/AdminLTELogo.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
      <span class="brand-text font-weight-light"><?php  $udata = $this->session->userdata('UserLoginSession');
    echo $udata['role'] ;?></span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar" style="overflow-y: hidden !important;">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
      <i class="fa fa-user " style="color:white;padding:4.7%"></i>
        <div class="info">
          <a href="#" class="d-block" style="font-size:20px"> <?php 
if($this->session->userdata('UserLoginSession'))
{
    $udata = $this->session->userdata('UserLoginSession');
    echo $udata['username'] ;
}
else
{
    redirect(base_url('Login_Registration/login'));
}



 ?></a>
   <a  href="https://markoseries.com/"><b class="try" style="font-size:15px;color:#ff4d4d">LogOut</b></a>
  
        </div>
      </div>

     

      <!-- Sidebar Menu -->
      <ul class="navbar-nav  sidebar sidebar-dark accordion" id="accordionSidebar">

<!-- Sidebar - Brand -->
 

<!-- Divider -->
 

<!-- Nav Item - Dashboard -->
<li class="nav-item">
    <a class="nav-link" href="<?=base_url('Superadmin/ticketview')?>">
        <i class="fas fa-fw fa-tachometer-alt"></i>
        <span>Home</span></a>
</li>
<li class="nav-item">
    <a class="nav-link" href="<?=base_url('Superadmin/registercomplaint')?>">
        <i class="fas fa-envelope"></i>
        <span>Complaint Registration</span></a>
</li>
<li class="nav-item">
    <a class="nav-link" href="<?=base_url('Superadmin/userrecords')?>">
        <i class="fas fa-users"></i>
        <span>User Records</span></a>
</li>


<!-- Divider -->
<!-- <hr class="sidebar-divider"> -->

<!-- Heading -->
 

<!-- Nav Item - Pages Collapse Menu -->
<li class="nav-item">
<?php $menu= array("registerstaff","removestaff"); ?>
    <a class="nav-link <?php if(isset($active)) { if(!in_array($active,$menu) ){ echo 'collapsed';}}?>" href="#" data-toggle="collapse" data-target="#collapseTwo"
    <?php if(isset($active)) { if(in_array($active,$menu)){ echo 'aria-expanded="true"';}else{ echo 'aria-expanded="false"';}}?> aria-controls="collapseTwo">
        <i class="fas fa-fw fa-cog"></i>
        <span>Engineer Records</span>
    </a>
    <div id="collapseTwo" class="collapse <?php if(isset($active)) { if(in_array($active,$menu)){ echo 'show';}}?>" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
        <div class=" py-2 collapse-inner rounded">
            
            <a class="collapse-item" href="<?=base_url('Admin/registerstaff')?>">Register Engineer</a>
            <a class="collapse-item" href="<?=base_url('Admin/removestaff')?>">View/Remove Engineer</a>
        </div>
    </div>
</li>

<!-- Nav Item - Utilities Collapse Menu -->
<li class="nav-item">
<?php $menu= array("dealerstaff","removedealer"); ?>

    <a class="nav-link <?php if(isset($active)) { if(!in_array($active,$menu) ){ echo 'collapsed';}}?>" href="#" data-toggle="collapse" data-target="#collapseUtilities"
    <?php if(isset($active)) { if(in_array($active,$menu)){ echo 'aria-expanded="true"';}else{ echo 'aria-expanded="false"';}}?> aria-controls="collapseUtilities">
        <i class="fas fa-fw fa-user"></i>
        <span>Dealer Records</span>
    </a>
    <div id="collapseUtilities" class="collapse <?php if(isset($active)) { if(in_array($active,$menu)){ echo 'show';}}?>" aria-labelledby="headingUtilities"
        data-parent="#accordionSidebar">
        <div class=" py-2 collapse-inner rounded">
            
            <a class="collapse-item" href="<?=base_url('Admin/dealerstaff')?>">Register Dealer</a>
            <a class="collapse-item" href="<?=base_url('Admin/removedealer')?>">View/Remove Dealer</a>
          </div>
    </div>
</li>

 
 

<!-- Nav Item - Pages Collapse Menu -->
<li class="nav-item">
<?php $menu= array("allticketview","assignstaff","viewopentickets","viewmyduetoday",
"viewoverduetickets","viewunassigned","viewassigned","resolvedtickets"); ?>
    <a class="nav-link <?php if(isset($active)) { if(!in_array($active,$menu) ){ echo 'collapsed';}}?>" href="#" data-toggle="collapse" 
    data-target="#collapsePages" <?php if(isset($active)) { if(in_array($active,$menu)){ echo 'aria-expanded="true"';}else{ echo 'aria-expanded="false"';}}?>
        aria-controls="collapsePages">
        <i class="fas fa-fw fa-wrench"></i>
        <span>Complaints</span>
    </a>
    <div id="collapsePages" class="collapse <?php if(isset($active)) { if(in_array($active,$menu)){ echo 'show';}}?>" aria-labelledby="headingPages"
        data-parent="#accordionSidebar">
        <div class=" py-2 collapse-inner rounded">
             
            <a class="collapse-item" href="<?=base_url('Admin/allticketview')?>">All Complaints</a>
            <a class="collapse-item" href="<?=base_url('Admin/assignstaff')?>">Assign Engineer</a>
            <a class="collapse-item" href="<?=base_url('Admin/viewopentickets')?>">Open Complaints</a>
            <a class="collapse-item" href="<?=base_url('Admin/viewmyduetoday')?>">Due Today Complaints</a>
             <a class="collapse-item" href="<?=base_url('Admin/viewoverduetickets')?>">Overdue Complaints</a>
             <a class="collapse-item" href="<?=base_url('Admin/viewunassigned')?>">Unassigned Complaints</a>
            <a class="collapse-item" href="<?=base_url('Admin/viewassigned')?>"> Assigned Complaints</a>
            <a class="collapse-item" href="<?=base_url('Superadmin/resolvedtickets')?>">Resolved Complaints</a>
            
            
        </div>
    </div>
</li>
<li class="nav-item ">
    <?php $menu= array("dailyReport","MonthlyReport"); ?>
    <a class="nav-link <?php if(isset($active)) { if(!in_array($active,$menu) ){ echo 'collapsed';}}?>" href="#" data-toggle="collapse" data-target="#collapseReport"
    <?php if(isset($active)) { if(in_array($active,$menu)){ echo 'aria-expanded="true"';}else{ echo 'aria-expanded="false"';}}?> aria-controls="collapseReport">
        <i class="fas fa-fw fa-search"></i>
        <span>Reports</span>
    </a>
    <div id="collapseReport" class="collapse <?php if(isset($active)) { if(in_array($active,$menu)){ echo 'show';}}?>" aria-labelledby="headingReport"
        data-parent="#accordionSidebar">
        <div class=" py-2 collapse-inner rounded">
            
            <a class="collapse-item" href="<?=base_url('Admin/dailyReport')?>">Daily Report</a>
            <a class="collapse-item" href="<?=base_url('Admin/MonthlyReport')?>">Monthly Report</a>
          </div>
    </div>
</li>
  
<li class="nav-item">
    <a class="nav-link" href="<?=base_url('Superadmin/changePassword')?>">
        <i class="fas fa-fw fa-wrench"></i>
        <span>Change Password</span></a>
</li> 
<li class="nav-item">
 
    <a class="nav-link <?php if(isset($active)) { if(!in_array($active,$menu) ){ echo 'collapsed';}}?>" href="#" data-toggle="collapse" data-target="#collapsemaster"
    <?php if(isset($active)) { if(in_array($active,$menu)){ echo 'aria-expanded="true"';}else{ echo 'aria-expanded="false"';}}?> aria-controls="collapsemaster">
        <i class="fas fa-fw fa-cog"></i>
        <span>Master</span>
    </a>
    <div id="collapsemaster" class="collapse <?php if(isset($active)) { if(in_array($active,$menu)){ echo 'show';}}?>" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
        <div class=" py-2 collapse-inner rounded">
            
            <a class="collapse-item" href="<?=base_url('Superadmin/listitem')?>">Manage Item</a>
            <a class="collapse-item" href="<?=base_url('Superadmin/listmodel')?>">Manage Model</a>
            <a class="collapse-item" href="<?=base_url('Superadmin/listbrand')?>">Manage Brand</a>
        </div>
    </div>


</li>
<!-- Divider -->
 

<!-- Sidebar Toggler (Sidebar) -->
<!-- <div class="text-center d-none d-md-inline">
    <button class="rounded-circle border-0" id="sidebarToggle"></button>
</div> -->

</ul>
      
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>
  
  
  <script>
(function($) {
  "use strict"; // Start of use strict

  // Toggle the side navigation
  $("#sidebarToggle, #sidebarToggleTop").on('click', function(e) {
    $("body").toggleClass("sidebar-toggled");
    $(".sidebar").toggleClass("toggled");
    if ($(".sidebar").hasClass("toggled")) {
      $('.sidebar .collapse').collapse('hide');
    };
  });

  // Close any open menu accordions when window is resized below 768px
  $(window).resize(function() {
    if ($(window).width() < 768) {
      $('.sidebar .collapse').collapse('hide');
    };
    
    // Toggle the side navigation when window is resized below 480px
    if ($(window).width() < 480 && !$(".sidebar").hasClass("toggled")) {
      $("body").addClass("sidebar-toggled");
      $(".sidebar").addClass("toggled");
      $('.sidebar .collapse').collapse('hide');
    };
  });

  // Prevent the content wrapper from scrolling when the fixed side navigation hovered over
  $('body.fixed-nav .sidebar').on('mousewheel DOMMouseScroll wheel', function(e) {
    if ($(window).width() > 768) {
      var e0 = e.originalEvent,
        delta = e0.wheelDelta || -e0.detail;
      this.scrollTop += (delta < 0 ? 1 : -1) * 30;
      e.preventDefault();
    }
  });

  // Scroll to top button appear
  $(document).on('scroll', function() {
    var scrollDistance = $(this).scrollTop();
    if (scrollDistance > 100) {
      $('.scroll-to-top').fadeIn();
    } else {
      $('.scroll-to-top').fadeOut();
    }
  });

  // Smooth scrolling using jQuery easing
  $(document).on('click', 'a.scroll-to-top', function(e) {
    var $anchor = $(this);
    $('html, body').stop().animate({
      scrollTop: ($($anchor.attr('href')).offset().top)
    }, 1000, 'easeInOutExpo');
    e.preventDefault();
  });

})(jQuery); // End of use strict

</script>
<style>
  .sidebar {
    /* width: 6.5rem; */
    min-height: 100vh
}

.sidebar .nav-item {
    position: relative
}

.sidebar .nav-item:last-child {
    margin-bottom: 1rem
}

.sidebar .nav-item .nav-link {
    text-align: center;
    padding: .35rem 1rem;
    width: 6.5rem
}

.sidebar .nav-item .nav-link span {
    /* font-size: .65rem; */
    display: block
}

.sidebar .nav-item.active .nav-link {
    font-weight: 700
}

.sidebar .nav-item .collapse {
    position: absolute;
    left: calc(6.5rem + 1.5rem / 2);
    z-index: 1;
    top: 2px
}

.sidebar .nav-item .collapse .collapse-inner {
    border-radius: .35rem;
    box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.15)
}

.sidebar .nav-item .collapsing {
    display: none;
    transition: none
}

.sidebar .nav-item .collapse .collapse-inner,.sidebar .nav-item .collapsing .collapse-inner {
    padding: .5rem 0;
    min-width: 10rem;
    /* font-size: .85rem; */
    margin: 0 0 1rem 0
}

.sidebar .nav-item .collapse .collapse-inner .collapse-header,.sidebar .nav-item .collapsing .collapse-inner .collapse-header {
    margin: 0;
    white-space: nowrap;
    padding: .5rem 1.5rem;
    text-transform: uppercase;
    font-weight: 800;
    font-size: .65rem;
    color: #b7b9cc
}

.sidebar .nav-item .collapse .collapse-inner .collapse-item,.sidebar .nav-item .collapsing .collapse-inner .collapse-item {
    padding: .5rem 1rem;
    margin: 0 .5rem;
    display: block;
    /* color: #3a3b45; */
    text-decoration: none;
    border-radius: .35rem;
    white-space: nowrap
}

.sidebar .nav-item .collapse .collapse-inner .collapse-item:hover,.sidebar .nav-item .collapsing .collapse-inner .collapse-item:hover {
    /* background-color: #eaecf4 */
    color:#fff;
}

.sidebar .nav-item .collapse .collapse-inner .collapse-item:active,.sidebar .nav-item .collapsing .collapse-inner .collapse-item:active {
    background-color: #dddfeb
}

.sidebar .nav-item .collapse .collapse-inner .collapse-item.active,.sidebar .nav-item .collapsing .collapse-inner .collapse-item.active {
    color: #4e73df;
    font-weight: 700
}

.sidebar #sidebarToggle {
    width: 2.5rem;
    height: 2.5rem;
    text-align: center;
    margin-bottom: 1rem;
    cursor: pointer
}

.sidebar #sidebarToggle::after {
    font-weight: 900;
    content: '\f104';
    font-family: 'Font Awesome 5 Free';
    margin-right: .1rem
}

.sidebar #sidebarToggle:hover {
    text-decoration: none
}

.sidebar #sidebarToggle:focus {
    outline: 0
}

.sidebar.toggled {
    width: 0!important;
    overflow: hidden
}

.sidebar.toggled #sidebarToggle::after {
    content: '\f105';
    font-family: 'Font Awesome 5 Free';
    margin-left: .25rem
}

.sidebar.toggled .sidebar-card {
    display: none
}

.sidebar .sidebar-brand {
    height: 4.375rem;
    text-decoration: none;
    font-size: 1rem;
    font-weight: 800;
    padding: 1.5rem 1rem;
    text-align: center;
    text-transform: uppercase;
    letter-spacing: .05rem;
    z-index: 1
}

.sidebar .sidebar-brand .sidebar-brand-icon i {
    font-size: 2rem
}

.sidebar .sidebar-brand .sidebar-brand-text {
    display: none
}

.sidebar hr.sidebar-divider {
    margin: 0 1rem 1rem
}

.sidebar .sidebar-heading {
    text-align: center;
    padding: 0 1rem;
    font-weight: 800;
    font-size: .65rem
}

.sidebar .sidebar-card {
    display: flex;
    flex-direction: column;
    align-items: center;
    font-size: .875rem;
    border-radius: .35rem;
    color: rgba(255,255,255,.8);
    margin-left: 1rem;
    margin-right: 1rem;
    margin-bottom: 1rem;
    padding: 1rem;
    background-color: rgba(0,0,0,.1)
}

.sidebar .sidebar-card .sidebar-card-illustration {
    height: 3rem;
    display: block
}

.sidebar .sidebar-card .sidebar-card-title {
    font-weight: 700
}

.sidebar .sidebar-card p {
    font-size: .75rem;
    color: rgba(255,255,255,.5)
}

@media (min-width: 768px) {
    .sidebar {
        width:14rem!important
    }

    .sidebar .nav-item .collapse {
        position: relative;
        left: 0;
        z-index: 1;
        top: 0;
        -webkit-animation: none;
        animation: none
    }

    .sidebar .nav-item .collapse .collapse-inner {
        border-radius: 0;
        box-shadow: none
    }

    .sidebar .nav-item .collapsing {
        display: block;
        transition: height .15s ease
    }

    .sidebar .nav-item .collapse,.sidebar .nav-item .collapsing {
        margin: 0 1rem
    }

    .sidebar .nav-item .nav-link {
        display: block;
        width: 100%;
        text-align: left;
        /* padding: 1rem; */
        width: 14rem
    }

    .sidebar .nav-item .nav-link i {
        /* font-size: .85rem; */
        margin-right: .25rem
    }

    .sidebar .nav-item .nav-link span {
        /* font-size: .85rem; */
        display: inline
    }

    .sidebar .nav-item .nav-link[data-toggle=collapse]::after {
        width: 1rem;
        text-align: center;
        float: right;
        vertical-align: 0;
        border: 0;
        font-weight: 900;
        content: '\f107';
        font-family: 'Font Awesome 5 Free'
    }

    .sidebar .nav-item .nav-link[data-toggle=collapse].collapsed::after {
        content: '\f105'
    }

    .sidebar .sidebar-brand .sidebar-brand-icon i {
        font-size: 2rem
    }

    .sidebar .sidebar-brand .sidebar-brand-text {
        display: inline
    }

    .sidebar .sidebar-heading {
        text-align: left
    }

    .sidebar.toggled {
        overflow: visible;
        width: 6.5rem!important
    }

    .sidebar.toggled .nav-item .collapse {
        position: absolute;
        left: calc(6.5rem + 1.5rem / 2);
        z-index: 1;
        top: 2px;
        -webkit-animation-name: growIn;
        animation-name: growIn;
        -webkit-animation-duration: .2s;
        animation-duration: .2s;
        -webkit-animation-timing-function: transform cubic-bezier(.18,1.25,.4,1),opacity cubic-bezier(0,1,.4,1);
        animation-timing-function: transform cubic-bezier(.18,1.25,.4,1),opacity cubic-bezier(0,1,.4,1)
    }

    .sidebar.toggled .nav-item .collapse .collapse-inner {
        box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.15);
        border-radius: .35rem
    }

    .sidebar.toggled .nav-item .collapsing {
        display: none;
        transition: none
    }

    .sidebar.toggled .nav-item .collapse,.sidebar.toggled .nav-item .collapsing {
        margin: 0
    }

    .sidebar.toggled .nav-item:last-child {
        margin-bottom: 1rem
    }

    .sidebar.toggled .nav-item .nav-link {
        text-align: center;
        padding: .75rem 1rem;
        width: 6.5rem
    }

    .sidebar.toggled .nav-item .nav-link span {
        font-size: .65rem;
        display: block
    }

    .sidebar.toggled .nav-item .nav-link i {
        margin-right: 0
    }

    .sidebar.toggled .nav-item .nav-link[data-toggle=collapse]::after {
        display: none
    }

    .sidebar.toggled .sidebar-brand .sidebar-brand-icon i {
        font-size: 2rem
    }

    .sidebar.toggled .sidebar-brand .sidebar-brand-text {
        display: none
    }

    .sidebar.toggled .sidebar-heading {
        text-align: center
    }
}

.sidebar-light .sidebar-brand {
    color: #6e707e
}

.sidebar-light hr.sidebar-divider {
    border-top: 1px solid #eaecf4
}

.sidebar-light .sidebar-heading {
    color: #b7b9cc
}

.sidebar-light .nav-item .nav-link {
    color: #858796
}

.sidebar-light .nav-item .nav-link i {
    color: #d1d3e2
}

.sidebar-light .nav-item .nav-link:active,.sidebar-light .nav-item .nav-link:focus,.sidebar-light .nav-item .nav-link:hover {
    color: #6e707e
}

.sidebar-light .nav-item .nav-link:active i,.sidebar-light .nav-item .nav-link:focus i,.sidebar-light .nav-item .nav-link:hover i {
    color: #6e707e
}

.sidebar-light .nav-item .nav-link[data-toggle=collapse]::after {
    color: #b7b9cc
}

.sidebar-light .nav-item.active .nav-link {
    color: #6e707e
}

.sidebar-light .nav-item.active .nav-link i {
    color: #6e707e
}

.sidebar-light #sidebarToggle {
    background-color: #eaecf4
}

.sidebar-light #sidebarToggle::after {
    color: #b7b9cc
}

.sidebar-light #sidebarToggle:hover {
    background-color: #dddfeb
}

.sidebar-dark .sidebar-brand {
    color: #fff
}

.sidebar-dark hr.sidebar-divider {
    border-top: 1px solid rgba(255,255,255,.15)
}

.sidebar-dark .sidebar-heading {
    color: rgba(255,255,255,.4)
}

.sidebar-dark .nav-item .nav-link {
    color: rgba(255,255,255,.8)
}

.sidebar-dark .nav-item .nav-link i {
    color: rgba(255,255,255,.3)
}

.sidebar-dark .nav-item .nav-link:active,.sidebar-dark .nav-item .nav-link:focus,.sidebar-dark .nav-item .nav-link:hover {
    color: #fff
}

.sidebar-dark .nav-item .nav-link:active i,.sidebar-dark .nav-item .nav-link:focus i,.sidebar-dark .nav-item .nav-link:hover i {
    color: #fff
}

.sidebar-dark .nav-item .nav-link[data-toggle=collapse]::after {
    color: rgba(255,255,255,.5)
}

.sidebar-dark .nav-item.active .nav-link {
    color: #fff
}

.sidebar-dark .nav-item.active .nav-link i {
    color: #fff
}

.sidebar-dark #sidebarToggle {
    background-color: rgba(255,255,255,.2)
}

.sidebar-dark #sidebarToggle::after {
    color: rgba(255,255,255,.5)
}

.sidebar-dark #sidebarToggle:hover {
    background-color: rgba(255,255,255,.25)
}

.sidebar-dark.toggled #sidebarToggle::after {
    color: rgba(255,255,255,.5)
}
</style>
<script src="../plugins/jquery/jquery.min.js"></script>

<link href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.css"  rel="stylesheet" />
<script src="<?php echo base_url()?>assets/libs/datatables.net/js/jquery.dataTables.min.js"></script>
        <script src="<?php echo base_url()?>assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
        <!-- Buttons examples -->
        <script src="<?php echo base_url()?>assets/libs/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
        <script src="<?php echo base_url()?>assets/libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
        <script src="<?php echo base_url()?>assets/libs/datatables.net/js/jquery.dataTables.min.js"></script>
        <script src="<?php echo base_url()?>assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
        <!-- Buttons examples -->
        <script src="<?php echo base_url()?>assets/libs/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
        <script src="<?php echo base_url()?>assets/libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
        <script src="<?php echo base_url()?>assets/libs/jszip/jszip.min.js"></script>
        <script src="<?php echo base_url()?>assets/libs/pdfmake/build/pdfmake.min.js"></script>
        <script src="<?php echo base_url()?>assets/libs/pdfmake/build/vfs_fonts.js"></script>
        <script src="<?php echo base_url()?>assets/libs/datatables.net-buttons/js/buttons.html5.min.js"></script>
        <script src="<?php echo base_url()?>assets/libs/datatables.net-buttons/js/buttons.print.min.js"></script>
        <script src="<?php echo base_url()?>assets/libs/datatables.net-buttons/js/buttons.colVis.min.js"></script>
        
        <!-- Responsive examples -->
        <script src="<?php echo base_url()?>assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
        <script src="<?php echo base_url()?>assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script>

  <!


 