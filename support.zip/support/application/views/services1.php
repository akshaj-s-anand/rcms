<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">





      <!-- style css -->
      <link rel="stylesheet" href="<?=base_url()?>css/style.css">
 <link rel="stylesheet" href="<?=base_url()?>css/responsive.css">
      <!-- fevicon -->
      <link rel="icon" href="<?=base_url()?>images/fevicon.png" type="image/gif" />
      <!-- Scrollbar Custom CSS -->
      <link rel="stylesheet" href="<?=base_url()?>css/jquery.mCustomScrollbar.min.css">

 <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">

 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">




<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  min-width:auto;

}

.navbar {
  overflow: hidden;
  background-color: #333;
}

.navbar a {
  float: left;
  font-size: 16px;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

.dropdown {
  float: left;
  overflow: hidden;
}

.dropdown .dropbtn {
  font-size: 16px;  
  border: none;
  outline: none;
  color: white;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.navbar a:hover, .dropdown:hover .dropbtn {
  background-color: red;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  float: none;
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {
  background-color: #ddd;
}

.dropdown:hover .dropdown-content {
  display: block;
}
.button1 {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 5px 20px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  transition-duration: 0.4s;
  cursor: pointer;
}

.button2 {
  background-color: white; 
  color: black; 
  border: 2px solid #007FFF;
}

.button2:hover {
  background-color: #007FFF;
  color: white;
}
.topnav {
  overflow: hidden;
  background-color: white;
  color:black;
  width:800px;
 
}

.topnav a {
  float: left;
  display: block;
  color: #B10003;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
 
  color: #DD0004 ;
}

.topnav a.active {
 
  color: black;
}

.topnav .icon {
  display: none;
}
#servpara{
    
 line-height: 1.7;
 color:white;
 margin:10px;
 font-size:18px;
 font-family: "Times New Roman", Times, serif;
}
.logoloc{
    margin-left:-55%;
}
#logoa{
    display:none;
}
#headerclass{
height:80px; 
z-index:9999;
}
.servleft{
   margin-left:30px;
}
#aboutimgcol{
   margin-left:20px;
   margin-bottom:20px;
   max-width:530px; 
}
#aboutimg{
    height:750px;
}
#footer1{
    margin-left:100px;
 
}
#footer2{
    margin-left:50px;
 
}
#newletter{
   background-color:#ec1c25;
   background-image: linear-gradient(#f7d2d0,#fab2ac,#ed857e,#f55549 ,#ec1c25);
   margin-top:100px  
}
#femail{
    margin-left:80px;
   width:70%;
}
#fname{
    margin-left:80px;
   width:70%;
}
.flexss{
  display:flex;
  flex-direction:row; 
}
.hlabel{
   width:120px;
   color:white;
}

@media screen and (max-width: 600px) {
     .hlabel{
  margin-left:-20px;
}
    .flexss{
  display:block;
 
}
    #femail{
    margin-left:0px;
   width:100%;
}
   #fname{
    margin-left:0px;
   width:100%;
}
    #newletter{
  
   margin-top:40px  
}
#footer1{
    margin-left:0px;
 
}
#footer2{
    margin-left:0px;

}
#footer3{
    margin-left:0px;
  
}
    .servleft{
   margin-left:1px;
}
  .column2 {
    width: 100%;
    display: block;
    margin-bottom: 40px;
    margin-left:0px;

  }
  #servpara{
      font-size:15px;
       line-height: 1.6;
     height: 600px;
     text-align:justify;
  overflow: hidden ;
}
.logoloc{
   display: none;
}
#logoa{
    margin-top:-25px;
   display: block;  
}
#logodiv{
    display:none;
}
#headerclass{
 margin-top:-40px;
height:110px;
z-index:9999;
}
#aboutimgcol{
   margin-left:0px;
   margin-bottom:20px;
   max-width:530px; 
}
#aboutimg{
    height:900px;
}


    .topnav {
width:100%;
margin-top:20px;
}
  .topnav a:not(:first-child) {display: none;}
  .topnav a.icon {
    float: right;
    display: block;
  }
 a.complaintbar{
      display:block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative; height:550px;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
}




.ourproject{
	padding: 100px 0;
}

.project-single{
	position: relative;
	margin-bottom: 30px;	
}

.project-overlay{
	position: absolute;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	background: rgba(0,0,0,0.33);
	padding: 30px;
}

.project-overlay h3{
	color: #fff;
	font-size: 18px;
	font-weight: 500;
	font-family: 'Montserrat', sans-serif;
}

.project-overlay p{
	color: #fff;
	font-size: 14px;
	font-weight: 300;
	margin-bottom: 8px;
}

.completed-project{
	position: relative;
	background: url(../images/solara.jpg) no-repeat center center;
	background-size: cover;
	padding: 100px 0 80px;
}

.completed-project:before{
	content: '';
	display: block;
	position: absolute;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	background: rgba(15,36,64,0.84);
}

.completed-title{
	margin-bottom: 60px;
	text-align: center;
}

.completed-title h2{
	font-size: 34px;
	color: #fff;
	text-transform: uppercase;
}

.completed-single{
	text-align: center;
}

.completed-single h3{
	color: #fff;
	font-size: 50px;
	font-family: 'Montserrat', sans-serif;
	margin-bottom: 0;
}

.completed-single p{
	color: #fff;
	font-size: 20px;
}

/*  Request Contact Form area css  */

.request-callback{
	padding: 100px 0;
}

.request-form .form-group{
	margin-bottom: 30px;
}

.request-form .form-control{
	border: none;
	box-shadow: none;
	background: #e7e4e4;
	border-radius: 0;
	height: auto;
	padding: 12px 20px;
}

.btn-request{
	display: block;
	background: #0f2440;	
	color: #fff;
	border: none;
	width: 100%;
	text-transform: uppercase;
	font-weight: 300;
	padding: 12px;
	font-size: 14px;
	letter-spacing: 0.1em;
	transition: all 0.3s;
}

.btn-request:hover{
	background: #000;
}

.contact-information{
	background: #223a5a;
	padding: 30px 0;
}

.contact-single{
	text-align: center;
}

.contact-single p{
	color: #fff;
	font-size: 20px;
	font-weight: 300;
	margin-bottom: 0;
}

.contact-single i{
	margin-right: 10px;
}



.container1 {
  position: relative;
  text-align: center;
  color: white;
}


.centered {
  position: absolute;
 
  left: 50%;
  transform: translate(-50%, -110%);
}
.button28 {
  background-color: #f4511e;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;

  cursor: pointer;
  width:100%;
  -webkit-transition-duration: 0.4s; /* Safari */
transition: all 0.5s ease;
}



.button24:hover {
  box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24),0 17px 50px 0 rgba(0,0,0,0.19);
  margin-left:10px;
 
}
.serv {
 
  border: none;
  color: white;
  padding: 15px 32px;
   text-align: justify;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;

  cursor: pointer;
 
  -webkit-transition-duration: 0.4s; /* Safari */
transition: all 0.5s ease;
}



.serv:hover {
  box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24),0 17px 50px 0 rgba(0,0,0,0.19);
 
 
}
.column2 {
  float: left;
  width: 50%;
  padding: 0 10px;
    margin-bottom: 40px;
}


/* Remove extra left and right margins, due to padding */
.row2 {margin: 0 -5px;}

/* Clear floats after the columns */
.row2:after {
  content: "";
  display: table;
  clear: both;
  margin-left:20px;
}
 #servpara{
    
 line-height: 1.7;
 color:white;
 margin:10px;
 font-size:18px;
 font-family: "Times New Roman", Times, serif;
}
#abouttext{
    min-width:320px;
}
#aboutimage{
    margin-left:50px;
}
#imgdiv{
    
     animation-name: example5;
  animation-duration: 2s;
}
@keyframes example5 {
  from {margin-left:100%;}
  to {margin-left:0%;}
}

#img1{
    margin-top:250px;
      margin-left:10px;
    width:170px;
    height:170px;
     animation-name: example1;
  animation-duration: 2s;
}
@keyframes example1 {
  from {opacity:0;}
  to {opacity:1;}
}
#img2{
    margin-top:150px;
      margin-left:10px;
 width:170px;
   height:170px;
     animation-name: example2;
  animation-duration: 4s;
}
@keyframes example2 {
  from {opacity:0;}
  to {opacity:1;}
}
#img3{
    margin-top:50px;
     margin-left:10px;
 width:170px;
   height:170px;
     animation-name: example3;
  animation-duration: 6s;
}
@keyframes example3 {
  from {opacity:0;}
  to {opacity:1;}
}



/* Responsive columns */
@media screen and (max-width: 600px) {
    #img1{
margin-top:20px;
    width:100%;
    height:auto;
}
#img2{
 margin-top:20px;
    width:100%;
    height:auto;
}
#img3{
margin-top:20px;
    width:100%;
    height:auto;
}
    #aboutimage{
    margin-left:0px;
}
#abouttext{
    min-width:320px;
    text-align:center;
}
  .column2 {
    width: 100%;
    display: block;
    margin-bottom: 40px;

  }
  #servpara{
      font-size:15px;
       line-height: 1.6;
     height: 600px;
     text-align:justify;
  overflow: hidden ;
}
}

/* Style the counter cards */
.card2 {
 
  padding: 16px;
  text-align: center;
   margin-bottom: 20px;
margin-left:5px;
}
@import url(https://fonts.googleapis.com/css?family=Open+Sans);




.container454{
  width:50%;
  min-width:300px;
  min-height:350px;
  margin:0 auto;
  position:relative;
  padding-bottom:30px;
  overflow:hidden;
    background-color:#ec1c25;
  background-size:cover;
}


input[type="radio"] {
position: absolute;
width: 1px; /* Setting this to 0 make it invisible for VoiceOver */
height: 1px; /* Setting this to 0 make it invisible for VoiceOver */
padding: 0;
margin: -1px;
border: 0;
clip: rect(0 0 0 0);
overflow: hidden;
}
label{
  display:block;
  width:32%;
  border: 4px solid white;
  position:absolute;
  bottom:5px;
  cursor: pointer;
  transition: border-color 0.3s linear;
}

label.second{
  left:34%;
}
label.third{
  left:68%;
}

blockquote{
  margin:0;
  padding:30px;
  width:100%;
  min-height:250px;
  background-color: #ec1c25;
  color:white;
  box-shadow: 0 5px 2px rgba(0,0,0,0.1);
  position:relative;
  transition: background-color 0.6s linear;
}

blockquote:after { 
  content: " "; 
  height: 0; 
  width: 0; 
  position: absolute; 
  top: 100%; 
  border: solid transparent; 
  border-top-color: rgba(255,255,255,0.5);
  border-left-color:rgba(255,255,255,0.5);
  border-width: 10px; 
  left: 10%; 
} 
#second:checked ~ .two blockquote {
  background-color:#ec1c25;
}
.two blockquote:after{
  border: solid transparent; 
  border-top-color: rgba(255,255,255,0.5);
  border-left-color:rgba(255,255,255,0.5);
  border-width: 10px;
}
#third:checked ~ .three blockquote{
 background-color:#ec1c25;
}
.three blockquote:after{
  border: solid transparent; 
  border-top-color: rgba(255,255,255,0.5);
  border-left-color: rgba(255,255,255,0.5);
  border-width: 10px;
}
.quotes{
  position:absolute;
  color:rgba(255,255,255,0.5);
  font-size:5em;
}
.leftq{
  top:-25px;
  left:5px;
}
.rightq{
  bottom:-10px;
  right:5px;
}

.slide1{
  position:absolute;
  left:-100%;
  opacity:0;
  transition: all 0.6s ease-in;
}

#first:checked ~ label.first {
  border-width:6px;
  border-color:white;
}
#second:checked ~ label.second {
  border-width:6px;   border-color:white;
}
#third:checked ~ label.third {
  border:6px solid rgba(255,255,255,0.5);
    border-color:white;
}

#first:checked ~ div.one {
  left:0;
  opacity:1;
}
#second:checked ~ div.two {
  left:0;
  opacity:1;
}
#third:checked ~ div.three {
  left:0;
  opacity:1;
}

</style>
</head>
<body>

<div class="navbar">
  <a href="#home">Home</a>
  <a href="#news">News</a>
  <div class="dropdown">
    <button class="dropbtn">Dropdown 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="#">Link 1</a>
      <a href="#">Link 2</a>
      <a href="#">Link 3</a>
    </div>
  </div> 
    <div class="dropdown">
    <button class="dropbtn">Dropdown 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="#">Link 4</a>
      <a href="#">Link 5</a>
      <a href="#">Link 6</a>
    </div>
  </div> 
</div>

<div class="service"  style="margin-top:20px" >
         <div class="container">
            <div class="row">
             
            </div>
           	<section class="banner" id="home">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="about-company">
						<div class="row no-gutters">
						    
						   
							
							<div class="col-md-3" id="abouttext"  >
						
                     <p  style="font-size:50px;font-weight:400;  line-height: 1.2;" id=:servicehead ><b>OUR SERVICES</b></p>
                    
                  
								<!-- About Description start -->
								<div class="about-description">
									
									<p style="text-align:justify;line-height: 1.17;">We provide a wide range of products and services, let it be a small scale inverter for your home, 
									or a huge power backup system for your IT firms, industries, hospitals, educational institutions or any other establishment. 
									We distribute the best quality inverter and battery, best water heater and also provides solar panel installation services. 
									A wide variety of automobile batteries for all your favourite automobiles. Customers are our asset, 
									our team ensures guaranteed customer support and service assistance. Contact us for any related services, deals and queries, 
									we have the right solution suggestion for your requirements.</p>
								<table>
								    <tbody>
								        <tr>
								            <td>
								             <i class="fa fa-check" style="font-size:18px; color:#ec1c25;"></i>   
								            </td>
								            <td style="line-height: 1.4">
								                Telephone assistance is available from 9.00am – 7.30 pm (except holidays)  
								            </td>
								        </tr>
							
								    </tbody>
								</table>
								
									<table style="margin-top:30px">
								    <tbody>
								      
								         <tr >
								            <td>
								             <i class="fa fa-check" style="font-size:18px; color:#ec1c25;"></i>   
								            </td>
								            <td style="line-height: 1.4">
								                For customer care helpline assistance: 8086995284, 0495 - 2771502
								            </td>
								        </tr>
								        
								    </tbody>
								</table>
								
									<table style="margin-top:30px">
								    <tbody>
								        <tr>
								      
								         <tr>
								            <td>
								             <i class="fa fa-check" style="font-size:18px; color:#ec1c25;"></i>   
								            </td>
								            <td style="line-height: 1.4">
								            Mail us: orionupsclt@gmail.com
								            </td>
								        </tr>
								    </tbody>
								</table>
								
								 
               <div class="col-md-12" style="margin-top:30px">
                  <button  onclick="location.href='<?=base_url('Login_Registration/contact')?>'" style="background-color:red;color:white;border-radius:30px;width:200px;height:30px">Contact Us</button>
               </div>
								
								
								</div>
								<!-- About Description end -->
							</div>
							
							<div class="col-md-7" id="aboutimage">
							    <div class="container" id="imgdiv">
  <div class="row">
    
    	<img id="img1" style="margin-bottom:20px" src="<?php foreach($image2->result() as $row){ echo base_url()."/images/".$row->image; } ?>"/>
  
    	<img id="img2" style="margin-bottom:20px" src="<?php foreach($image2->result() as $row){ echo base_url()."/images/".$row->image2; } ?>"/>
   
    	<img id="img3" style="margin-bottom:20px" src="<?php foreach($image2->result() as $row){ echo base_url()."/images/".$row->image3; } ?>"/>
   
  </div>
</div>
							
							</div>
						
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
         </div>
      </div>

  
   
       
          
            <div class="row" style="margin-top:50px;margin-left:20px;margin-right:20px">
               <dir class="col-xl-4 col-lg-3 col-md-6 col-sm-12">
                  <div class="for_box">
                      <table>
                          <tbody>
                              <tr>
                                  <td style="width:100px"><img style="width:80px;height:80px" src="../images/serv1.jpg"/></td>
                                  <td>
                                     <h3 style="color:red">MANUFACTURING</h3> 
                                  </td>
                              </tr>
                          </tbody>
                      </table>
                
                    
                     <p style="text-align:justify">We understand the need of the customer and focus on innovation to produce products having high-end technology at affordable
                     prices and constantly evolving features. What inspires us the most to deliver high quality products is our quality
                     in manufacturing the best solar water heater, inverter and battery, best solar inverter with battery for your happy place.
                     For any product from our home, even if its solar panel installation or other Orion products, you will get the best possible
                     solution and that is 100% guaranteed. Specialized manufacturing units in different spheres of the Electrical Industry, have made 
                     it possible for us to harness the world’s latest technology, refining it, bringing in the perfection and incorporating the same in our
                     product range for the benefit of our consumers. It is our dedication to quality practices and adherence to strict processes, controls and
                     checks, which has resulted in ‘ORION’ products acquiring the distinction of being proven, reliable and truly the best in terms of technology 
                     & innovation. Through its commitment to product quality and consumer satisfaction, ‘ORION’, today the brand of choice for hundreds of consumers. 
                     In search of quality, finding is rare. That’s why we exist.</p>
                  </div>
               </dir>
               <dir class="col-xl-4 col-lg-3 col-md-6 col-sm-12 " >
                  <div class="for_box">
                      <table>
                          <tbody>
                              <tr>
                                  <td style="width:100px"><img style="width:80px;height:80px" src="../images/serv2.jpg"/></td>
                                  <td>
                                     <h3 style="color:red">INSTALLATION</h3> 
                                  </td>
                              </tr>
                          </tbody>
                      </table>
                
<p style="text-align:justify">Advanced Solar Products is a New Jersey based, full-service installer/integrator of photovoltaic (PV) systems.
Our experience and expertise is in harvesting solar energy by means of solar panel installation for commercial and industrial organizations, educational institutions,
municipalities, farming and agricultural businesses, major utilities, and other large applications. Connect us, the best dealers of solar installation near you. 
Find your suitable solution in solar on grid system or solar off grid system installations for extra money saving.</p>                  </div>
               </dir>
               <dir class="col-xl-4 col-lg-3 col-md-6 col-sm-12">
                  <div class="for_box">
                     <table>
                          <tbody>
                              <tr>
                                  <td style="width:100px"><img style="width:80px;height:80px" src="../images/serv3.jpg"/></td>
                                  <td>
                                     <h3 style="color:red">MAINTENANCE AND CUSTOMER SUPPORT</h3> 
                                  </td>
                              </tr>
                          </tbody>
                      </table>
                     
<p style="text-align:justify">We provide excellent maintenance facilities to even customers who have installed solar systems from other companies and are facing problems.
We have strong technical team in our service department to serve this purpose. Excellent customer support for solar panel installation and for other products.</p>                  </div>
               </dir>
             
            </div>
       
     
      
      <!-- end service -->

      
      <!--  footer --> 
  <div style="background-image:url(<?php foreach($image3->result() as $row){ echo base_url()."/images/".$row->image; } ?>);background-repeat:no-repeat;background-size:cover;width:100%;"  >
             
            <div class="row" style="background: rgba(255,255, 255, 0.96);width:100%;height:100%;margin-left:1px" >
                 <div class="col-sm" id="footer1"  >
                  <div class="contact" >
                     <h3 style="color:black">    <a href=""><img src="../images/logo-2.png" alt="logo"/></a></h3>
                     <span style="color:#878787;font-size:14px;">Do you have any queries or comments about our website, our products or any of our services.?</span>
                       <ul class="sociel">
                         <li> <a style="color:black" href="#"><i class="fa fa-facebook"></i></a></li>
                         <li style="margin-left:-30px"> <a style="color:black" href="#"><i class="fa fa-twitter"></i></a></li>
                         <li style="margin-left:-30px"> <a style="color:black" href="#"><i class="fa fa-instagram"></i></a></li>
                             <li style="margin-left:-30px"> <a style="color:black" href="#"><i class="fa fa-pinterest"></i></a></li>
                              <li style="margin-left:-30px"> <a style="color:black" href="#"><i class="fa fa-linkedin"></i></a></li>
                     </ul>
                     
                  </div>
               </div>
              
                 <div class="col-sm" id="footer2" >
                  <div class="contact">
                     <h3 style="color:#ec1c25;font-weight:700">QUICK LINKS</h3>
                     <ul class="lik">
                         <li> <a style="color:#ec1c25" href="#"><i class="fa fa-home"></i>Home</a></li>
                         <li> <a style="color:#ec1c25" href="#"><i class="fa fa-tags"></i>About</a></li>
                         <li> <a style="color:#ec1c25" href="#"><i class="material-icons" style="font-size:18px">terrain</i>Services</a></li>
                         <li> <a style="color:#ec1c25" href="#"><i class="fa fa-shopping-cart"></i>Products</a></li>
                       
                     </ul>
                  </div>
                   <div class="row" style="margin-top:-10px">
                         <div class="col"> <p><a href="#"><h5 style="color:#c7c1c1"><i class="fa fa-handshake-o" style="color:red"></i>Orion Power House</h5></a></p></div>
                     </div>
               </div>
               <div class="col-sm" id="footer3" >
                  <div class="contact">
                      <h3 style="color:#ec1c25;font-weight:700">Contact Us</h3>
                      
                    <div class="row">
                         <div class="col"> <table>
                             <tbody>
                                 <tr>
                                     <td><i class="fa fa-address-book" style="color:red"></i></td>
                                     <td style="color:#878787">Building No. 44/3014, Kuniyilkave Road Ashokapuram, Calicut-673006 </td>
                                 </tr>
                                  <tr>
                                     <td><i class="fa fa-mobile-phone" style="color:red"></i></td>
                                     <td style="color:#878787">9447385870 </td>
                                 </tr>
                                  <tr>
                                     <td><i class="fa fa-phone" style="color:red"></i></td>
                                     <td style="color:#878787">0495-2771502</td>
                                 </tr>
                                  <tr>
                                     <td><i class="fa fa-envelope-open" style="color:red"></i></td>
                                     <td style="color:#878787">admin@oriontechnologies.co.in</td>
                                 </tr>
                                  <tr>
                                     <td><i class="fa fa-clock-o" style="color:red"></i></td>
                                     <td style="color:#878787">Open hours: Mon-Sat 9 AM to 7PM</td>
                                 </tr>
                                  <tr>
                                     <td ><i class="material-icons" style="color:red;font-size:18px">watch</i></td>
                                     <td style="color:#878787" >aHappy hours: sat: 2 pm to 4 pm</td>
                                 </tr>
                             </tbody>
                         </table></div>
                     </div>
                        
                   
                        
                  </div>
               </div>
               
                
            </div>
                        <div class="row" style="background: rgba(255,255, 255, 0.96);width:100%;height:100%;margin-left:1px" >
                 <div class="col-sm"  >
                  <div class="contact" >
                    
                     <span style="color:#878787;font-size:14px;">Orion Technologies Copyright ©2022 All rights reserved.</span>
                       
                     
                  </div>
               </div>
              
                  <div class="col-sm"  >
                  <div class="contact" >
                    
                     <span style="color:#878787;font-size:14px;margin-left:50%">Designed by Cpool Digital Learning</span>
                       
                     
                  </div>
               </div>
  
               
                
            </div>
         </div>
      <!-- end footer -->
      <!-- Javascript files--> 
      <script src="js/jquery.min.js"></script> 
      <script src="js/popper.min.js"></script> 
      <script src="js/bootstrap.bundle.min.js"></script> 
      <script src="js/jquery-3.0.0.min.js"></script> 
      <script src="js/plugin.js"></script> 
      <!-- sidebar --> 
      <script src="js/jquery.mCustomScrollbar.concat.min.js"></script> 
      <script src="js/custom.js"></script>
      <script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
      <script>
         $(document).ready(function(){
         $(".fancybox").fancybox({
         openEffect: "none",
         closeEffect: "none"
         });
         
         $(".zoom").hover(function(){
         
         $(this).addClass('transition');
         }, function(){
         
         $(this).removeClass('transition');
         });
         });
         
      </script> 
      
      <script>
function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}
</script>

      <!-- end footer -->
      <!-- Javascript files--> 
      <script src="js/jquery.min.js"></script> 
      <script src="js/popper.min.js"></script> 
      <script src="js/bootstrap.bundle.min.js"></script> 
      <script src="js/jquery-3.0.0.min.js"></script> 
      <script src="js/plugin.js"></script> 
      <!-- sidebar --> 
      <script src="js/jquery.mCustomScrollbar.concat.min.js"></script> 
      <script src="js/custom.js"></script>
      <script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
      <script>
         $(document).ready(function(){
         $(".fancybox").fancybox({
         openEffect: "none",
         closeEffect: "none"
         });
         
         $(".zoom").hover(function(){
         
         $(this).addClass('transition');
         }, function(){
         
         $(this).removeClass('transition');
         });
         });
         
      </script> 

</body>
</html>
